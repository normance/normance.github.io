<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2019 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */
namespace Expedipro\Module\Action;

class Delivery // extends \ModuleAdminController
{
    protected
        $products,
        $employee,
        $statusMapping;


    public function __construct()
    {
        $this->employee = new \Employee( (int) \Configuration::get('EXPEDIPRO_EMPLOYEE') );
        $this->statusMapping =
            ( new Mapper() )->deliveryState(
                \Configuration::get('EXPEDIPRO_DELIVERYBEFORE'),
                \Configuration::get('EXPEDIPRO_DELIVERYSTART'),
                \Configuration::get('EXPEDIPRO_DELIVERYDONE') );
    }


    /**
     * Handle the get or post request before main action
     *
     * @param array $data
     *
     * @return array
     */
    public function process( array $data ) :array
    {
//		parent::processRequest('import');	// return a ready to use $this->container
        if ( ! isset ($data['delivery']) )
            return [];

        // product is the effective supplier along its product used for the expedition
        $this->products = $data['product'] ?? [];

        return $this->setDelivery( $data['delivery'] );
    }



    /**
     * Extract orders and output them (to file AND to html)
     * Note: the result page is like a log where every orderId should appears once and no more.
     *
     * @param array $delivery
     *
     * @return array
     */
    protected function setDelivery( array $delivery ) :array
    {
        /* error https://github.com/PrestaShop/PrestaShop/issues/15503
        src/Adapter/ContainerFinder.php:77 Kernel Container is not available
        classes/Tools.php(796): PrestaShop\\PrestaShop\\Adapter\\ContainerFinder->getContainer()
        classes/Tools.php(773): ToolsCore::getContextLocale(Object(Context))
        classes/order/OrderHistory.php(513): ToolsCore::displayPrice(139, Object(Currency), false)
        classes/order/OrderHistory.php(468): OrderHistoryCore->sendEmail(Object(Order), false)
        classes/order/Order.php(1681): OrderHistoryCore->addWithemail()
        modules/expedipro/src/action/Delivery.php(167): OrderCore->setCurrentState(4, '5')
        modules/expedipro/src/action/Delivery.php(50): Expedipro\\Module\\Action\\Delivery->setDelivery(Array)
        modules/expedipro/controller.php(84): Expedipro\\Module\\Action\\Delivery->process(Array)
        modules/expedipro/controller.php(224): controller->processRequest()
        */
        global $kernel;
        if( ! $kernel){
            try { // redondant with file_exists()
                if ( file_exists(_PS_ROOT_DIR_.'/app/AppKernel.php' ) ) {
                    require_once _PS_ROOT_DIR_.'/app/AppKernel.php';    // not catchable, unlike @include_once()
                    $kernel = new \AppKernel('prod', false); // required when Prestashop 1.7*
                    $kernel->boot();
                }
            }
            catch ( \Exception $e ){
                // fine when Prestashop 1.6*
            }
        }


        $result = [
            'stepNew'		=> null,
            'stepSame'		=> null,
            'stepIgnored'   => null,
            'trackingNew'	=> null,
            'trackingSame'	=> null,
            'trackingGrouped'=> null,
            'unknown'		=> null,
            'exception'		=> null
        ];

        //		$allCarrier = $adapter->getCarrierList( );
        //echo '<br> $allCarrier =';
        //		$allCarrier = array_column($adapter->getCarrierList( ), 'name', 'id_carrier');
        //var_dump($allCarrier );
        /*
        echo '<br> data products =';
        var_dump($this->products );

        echo '<br> data deliveries =';
        var_dump($data['delivery'] );
        echo '<br>________________________';
        var_dump(_PS_VERSION_ );
        */
        /*
            array(	'product' =>
                    array(	'R00' => 'Colissimo Access France',
                            'R01' => 'Colissimo Expert France',
                         ),
                    'distribution' =>
                    array(	'AVX' => 'Votre colis ....',
                            'REN' => 'Livraison effective',
                         ),
                    'carrier' =>		// not implemented
                    array(	0 => 'MyCarrier',
                            1 => 'Colissimo',
                         ),
                    'delivery' =>
                    array(	0 => array('order'=> '1', 'track'=> 'ABCDEF12', 'step' => '60', 'stepLib' => 'AVX', 'carrier' => '0', 'product' => 'R01', 'insurance' => 234, 'cost' => 15.99),
                            1 => array('order'=> '2', 'track'=> 'ZDF543A2', 'step' => '100','stepLib' => 'REN', 'carrier' => '1', 'product' => 'R00','insurance' => 0, 'cost' => 8.22),
                         )
                )
        */
        foreach( $delivery as $one )
        {
            try {
                $one['order'] = (int) $one['order'];

                // better to rely on native methods because of hook::updateOrderStatus and hook::postUpdateOrderStatus
                $orderObject = new \Order( $one['order'], $this->employee->id_lang );
                if (! \Validate::isLoadedObject($orderObject) ) {
                    $result['unknown'][] = $one['order'];
                    $orderObject = null;
                    continue;
                }

                $primaryOrder = true;
                // if shipping number is already there, then we have nothing to do
                // either this is not the first feedback for this order, either employee has forced an tracking number
                // this also avoid spamming message for every feedback

                // TODO use OrderCarrier->tracking_number starting 1.8 ? note : setTrackingNumber() already create one
                if ( ! $orderObject->shipping_number ) {
                    $this->setTrackingNumber( $one, $orderObject );
                    $this->setMessage( $one, $orderObject );
                    $result['trackingNew'][] = $one['order'];
                }
                elseif ( $orderObject->shipping_number != $one['track']  )
                {
                    $primaryOrder = false; 			// UseCase : splitted order
                    if ( (int) $one['step'] <= 11 ) // not efficient, but at least limit spamming message for splitted order until this stage
                    {
                        $this->setMessage( $one, $orderObject );
                        $result['trackingGrouped'][] = $one['order'];
                    }
                } else {
                    $result['trackingSame'][] = $one['order'];
                }

                if ( $primaryOrder )
                {
                    $state = $this->getShippingStatus( intval( $one['step'] ) );

                    // UC: no synchro selected in module configuration (or wrong data from Expedipro)
                    if ( null === $state ) {
                        $result['stepIgnored'][] = $one['order'];
                        continue;
                    }

                    // Avoid creating order history events when state does not change
                    if ( $state == (int) $orderObject->getCurrentState() ) { // prefer loose comparaison rather than strict
                        $result['stepSame'][] = $one['order'];
                        continue;
                    }

                    // abstract ObjectModelCore  __construct($id = null, $id_lang = null, $id_shop = null, $translator = null)
                    $history = new \OrderHistory( $orderObject->id, $this->employee->id_lang);
                    $history->id_order = $orderObject->id;
                    $history->id_employee = $this->employee->id;
                    $history->id_order_state = $state;
                    $history->changeIdOrderState( $state, $orderObject->id);
                    // case 1: fatal just before, so done in catch()
                    // case 2: fine, so do it here
                    $history->add(); // perform $orderObject->update();
                    $result['stepNew'][] = $one['order'];
                }

                /*
                            if ( $one['carrier'] )
                            {
                                // ensure that carrier effectively used in Expedipro was the one chose in the order
                                $carrierObject = new CarrierCore( $orderObject->id_carrier );
                                if ( $carrierObject->name == $one['carrier']) continue;
                                $carrierObject = $message = null;
                            }
                */
            } catch ( \RuntimeException $e ) {
                /*
                Determining the active language requires a contextual employee instance.
                src/PrestaShopBundle/Entity/Repository/StockManagementRepository.php:130
                #0 src/PrestaShopBundle/Entity/Repository/StockMovementRepository.php(58): PrestaShopBundle\Entity\Repository\StockManagementRepository->__construct(Object(ContainerFm705o4\appProdProjectContainer), Object(Doctrine\DBAL\Connection), Object(Doctrine\ORM\EntityManager), Object(PrestaShop\PrestaShop\Adapter\LegacyContext), Object(PrestaShop\PrestaShop\Adapter\ImageManager), 'ps_')
                #4 src/Core/Stock/StockManager.php(356): Symfony\Component\DependencyInjection\Container->get('prestashop.core...')
                #5 classes/order/OrderHistory.php(336): PrestaShop\PrestaShop\Core\Stock\StockManager->saveMovement(10, 25, -1, Array)
                #6 classes/order/Order.php(1670): OrderHistoryCore->changeIdOrderState(4, Object(Order))
                */
                // we land here when Order->setCurrentState() | OrderHistory->changeIdOrderState() fail
                $history->add(); // perform $orderObject->update();
                /*
                                $orderObject->setCurrentState( $state, $this->employee->id );
                                // copy from OrderHistoryCore
                                $orderObject->current_state = $this->id_order_state;
                                $orderObject->valid = $new_os->logable;
                                $orderObject->update();
                */
                $result['stepNew'][] = $one['order'];
            }
            catch ( \Exception $e) {
                $result['exception'][] = $e->getFile() . ':' . $e->getLine() . ' ' . $e->getMessage() . ' ' . $e->getTraceAsString() . ' for ' . json_encode($one);
            }

            // reset limit for each iteration
            set_time_limit(20);
        }


        // feedback to Expedipro
        echo json_encode( $result, JSON_NUMERIC_CHECK | JSON_PARTIAL_OUTPUT_ON_ERROR );
        return $result;
    }


    /**
     * Add a private message for this Order to display parcel details on the order back office page
     *
     * @param array $orderDetail
     * @param \Order $orderObject
     *
     * @return bool
     */
    private function setMessage( array $orderDetail, \Order $orderObject ) :bool
    {
        if ( ! isset($this->products[ $orderDetail['product'] ]) )
            return false;

        if ( ! intval( \Configuration::get('EXPEDIPRO_DELIVERYMESSAGE') ) )
            return true;

        $messageObject = new \Message();	// OrderMessage if for predefined messages
        $messageObject->message = $this->products[ $orderDetail['product'] ] .
            ( $orderDetail['insurance'] ? ', assuré pour ' . str_replace('.', ',',$orderDetail['insurance']) . '€' : '') .
            ( $orderDetail['cost'] ? ', coût ht = ' . str_replace('.', ',',$orderDetail['cost']) : '') .
            PHP_EOL .
            'Suivi sur ' . \Configuration::get('EXPEDIPRO_DELIVERYTRACKING') . $orderDetail['track'];
        $messageObject->id_order 	= $orderDetail['order'];
        $messageObject->id_cart		= $orderObject->id_cart;
        $messageObject->id_customer	= $orderObject->id_customer;
        $messageObject->id_employee	= $this->employee->id;
        $messageObject->private		= 1;

        return (bool) $messageObject->add();
//		$messageObject = null; // reduce mem footprint
    }


    /**
     * Update the Order object with tracking number and Object orderCarrier (PS > 1.5)
     *
     * @param array	$orderDetail
     * @param Order $orderObject
     *
     * @return boolean
     */
    private function setTrackingNumber( array $orderDetail, \Order $orderObject ) :bool
    {
        if ( ! $orderDetail['track'] )
            return false;

        // shipping_number 1.6 type isTrackingNumber, supposed to becomes deprecated in 1.6 but still used
        $orderObject->shipping_number = $orderDetail['track'];
        $orderObject->update();

//    	if ( method_exists($orderObject,'getIdOrderCarrier') ) {
        if ( ! $idOrderCarrier = $orderObject->getIdOrderCarrier() )
            return false;

        $orderCarrierObject = new \OrderCarrier( $idOrderCarrier );
        $orderCarrierObject->tracking_number = $orderDetail['track'];
        $orderCarrierObject->weight = $orderDetail['weight'];
        if ( intval( \Configuration::get('EXPEDIPRO_DELIVERYCOST') ) ) {
            $orderCarrierObject->shipping_cost_tax_excl = $orderDetail['cost'];
            $orderCarrierObject->shipping_cost_tax_incl = $orderDetail['costWt'] ?: $orderDetail['cost'];
        }
        $orderCarrierObject->update();
//		print_r( $orderCarrierObject->getFields() );
        $orderCarrierObject = null;	// reduce mem footprint

        return true;
    }


    /**
     * @param int|null $expediproStatus
     *
     * @return int|null
     */
    private function getShippingStatus( int $expediproStatus = null)
    {
        if ( ! $expediproStatus )
            return null;

        $previous = null;
        foreach ($this->statusMapping AS $expedipro => $prestashop )
        {
            if ( (int) $expediproStatus === $expedipro )
                return $prestashop;
            if ( (int) $expediproStatus <  $expedipro )
                return $previous;	// if expedipro send a unknown code, don't break and send the closest one
            $previous = $prestashop;
        }
        return null;
    }
}
?>
