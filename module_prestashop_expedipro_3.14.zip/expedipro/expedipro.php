<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014-2019 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

if (!defined('_PS_VERSION_'))
    exit;
// Prestashop 1.6 classes/modules/Module.php does an eval() approx line 1361 which does not support namespace
//use Expedipro\Module\Action;    // for Mapper

class Expedipro extends Module
{
    public function __construct()
    {
        $this->name = 'expedipro';
        $this->tab  = 'shipping_logistics';
        $this->author  = 'Expedipro (officiel)';
        $this->version = '3.14';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '1.6', 'max' => '99'];
/*
        if (version_compare(_PS_VERSION_,'1.7','>')) {
            $this->ps_versions_compliancy = array('min' => '1.4', 'max' => '99');
            $this->dependencies = ['ps_shoppingcart'];
        }
        elseif (version_compare(_PS_VERSION_,'1.6','>')) {
            $this->ps_versions_compliancy = array('min' => '1.4', 'max' => '99');
            $this->dependencies = ['blockcart'];
        }
*/
//		$this->limited_countries = 'fr';
        $this->context = Context::getContext(); // defined in ModuleCore


        parent::__construct();
        $this->displayName = ' Expedipro.com : simplifiez-vous l\'expédition';
        $this->description = 'L\'expédition de vos colis aux tarifs pro, en quelques clics, avec synchronisation automatique de l\'état de livraison.';
//        $this->description = 'L\'expédition de vos colis aux tarifs pro, en quelques clics, avec synchronisation automatique de l\'état de livraison.<span class="module-badge-popular help-tooltip text-primary"><i class="icon-group"></i> <small>Populaire</small></span>';

        // done here rather during install, since update does not required uninstall/install process
        // so even droping new files will update version at the next instanciation
        Configuration::updateValue('EXPEDIPRO_VERSION', $this->version);
        Configuration::updateValue('EXPEDIPRO_TITLE',	$this->displayName);

        // upgrade from previous 3.6 bring functional regressions
        if ( ! Configuration::hasKey( 'EXPEDIPRO_DELIVERYMESSAGE') ) {
            Configuration::updateValue('EXPEDIPRO_DELIVERYCOST', 1 );
            Configuration::updateValue('EXPEDIPRO_DELIVERYMESSAGE', 1 );
        }

        $this->confirmUninstall = 'Voulez-vous désinstaller le module Expedipro ?';

        // provide content to caller and also by dependency injection (config)
        return $this->context;
    }


    /*
     * class AdminModulesControllerCore define the list of possible callback for the module :
     * protected $map = array(
        'check' => 'check',
        'install' => 'install',
        'uninstall' => 'uninstall',
        'configure' => 'getContent',
        'update' => 'update',
        'delete' => 'delete',
        'checkAndUpdate' => 'checkAndUpdate',
        'updateAll' => 'updateAll',
    );
     */


    public function install()
    {
        $this->cleanup25();

        // because of AdminModulesController->postProcessCallback()
        require_once( dirname(__FILE__) . '/vendor/autoload.php');

        $mapper = new Expedipro\Module\Action\Mapper($this->context);
        // we defined a UNACTIVE employee for updating status order
        // note that password is random and not compliant with ps, so no possible login
        if ( $oldEmployee = $mapper->getExpediproEmployee('support@expedipro.com') )
        {	// in case of delete/reinstall, employee still exists
            Configuration::updateValue('EXPEDIPRO_EMPLOYEE', $oldEmployee ) ;
        } else {
            if ( ! $newEmployee = $mapper->setExpediproEmployee('support@expedipro.com') )
                $newEmployee = 1; // for sure this one exist
            Configuration::updateValue('EXPEDIPRO_EMPLOYEE', $newEmployee ) ;
        }

        require_once( dirname(__FILE__) . '/Config.php');
        return parent::install() 													AND
//			$this->registerHook('displayAdminOrder') 								AND
//			$this->psOverride('install') 											AND
//			$this->installModuleTab('export', array(1=>'Expedipro', 2=>'Expedipro'), 3) AND
            Configuration::updateValue('EXPEDIPRO_TOKEN', ( new Config( $this->context) )->randomString(32) ) AND	// this is not url?token= from prestashop
            Configuration::updateValue('EXPEDIPRO_SEPARATOR', '|')					AND
            Configuration::updateValue('EXPEDIPRO_ORDERSTATE', '2|3')   			AND // paid and preparation
            Configuration::updateValue('EXPEDIPRO_ORDERCARRIER', '')   				AND // all carriers by default
            Configuration::updateValue('EXPEDIPRO_DELIVERYBEFORE', '3')   			AND	// en cours de préparation
            Configuration::updateValue('EXPEDIPRO_DELIVERYSTART', '4')   			AND	// transport
            Configuration::updateValue('EXPEDIPRO_DELIVERYDONE', '5' )              AND // livré
            Configuration::updateValue('EXPEDIPRO_DELIVERYCOST', '1' )              AND // update shipping cost at first delivery synchronization
            Configuration::updateValue('EXPEDIPRO_DELIVERYMESSAGE', '1' )           AND // create private message at first delivery synchronization
            Configuration::updateValue('EXPEDIPRO_DELIVERYTRACKING', 'www.expedipro.com/support/suivi?id=');
    }


    public function uninstall()
    {
//		if ( ! parent::uninstall()) {
//			Db::getInstance()->Execute('DELETE FROM `'._DB_PREFIX_.'mymodule`');
//			Db::getInstance()->Execute('DELETE FROM `'._DB_PREFIX_.'authorization_role` WHERE slug LIKE ("ROLE_MOD_MODULE_EXPEDIPRO_%")' );
//      }
        // not sure we must delete EXPEDIPRO employee in case it is just an delete/reinstall of the module
        // we would lost employee name in history status of orders

        return parent::uninstall()								AND
//			$this->registerHook('displayAdminOrder') 			AND
//			$this->psOverride('uninstall') 						AND
//			$this->uninstallModuleTab('export')					AND
            Configuration::deleteByName('EXPEDIPRO_TITLE')			AND
            Configuration::deleteByName('EXPEDIPRO_VERSION')		AND
            Configuration::deleteByName('EXPEDIPRO_TOKEN')			AND
            Configuration::deleteByName('EXPEDIPRO_SEPARATOR')		AND
            Configuration::deleteByName('EXPEDIPRO_ORDERSTATE')  	AND
            Configuration::deleteByName('EXPEDIPRO_ORDERCARRIER') 	AND
            Configuration::deleteByName('EXPEDIPRO_DELIVERYTRACKING') AND
            Configuration::deleteByName('EXPEDIPRO_DELIVERYCOST' )  AND
            Configuration::deleteByName('EXPEDIPRO_DELIVERYMESSAGE') AND
            Configuration::deleteByName('EXPEDIPRO_DELIVERYBEFORE') AND
            Configuration::deleteByName('EXPEDIPRO_DELIVERYSTART') 	AND
            Configuration::deleteByName('EXPEDIPRO_DELIVERYDONE' )  AND
            Configuration::deleteByName('EXPEDIPRO_EMPLOYEE')       AND
            /* obsolete keys that might still exist */
            Configuration::deleteByName('EXPEDIPRO_ORDERTRACKING')	AND
            Configuration::deleteByName('EXPEDIPRO_ORDERFROM')	    AND
            Configuration::deleteByName('EXPEDIPRO_ORDERWEIGHT')
            ;
    }

    /**
     * Prestashop magic: if exists, display the "configure" link
     * AdminModulesControllerCore() class look for getContent() in this class when doing ?controller=AdminModules&configure=expedipro
     *
     * @return string form
     */
    public function getContent()
    {
        // because of AdminModulesController->postProcessCallback()
        require_once( dirname(__FILE__) . '/Config.php');
        $config = new Config( $this->context ); // from __construct()

        // Important getContent() is called TWO times :
        // to get the configuration page
        // after POST of configuration change
        $output = $config->configPost(); // first step : save change if we are in submit mode

//		global $smarty;
        $this->context->smarty->assign('config',[
            'expediproToken'=> Configuration::get('EXPEDIPRO_TOKEN'),
            'expediproUrl'	=> _PS_BASE_URL_SSL_. __PS_BASE_URI__. 'modules/expedipro/controller.php',
            'expediproCanal'=> str_replace(' ', '', Configuration::get('PS_SHOP_NAME') ) ,	// removing spaces help using this as an id
            'expediproTitle'=> Configuration::get('EXPEDIPRO_TITLE'),
            'expediproVersion'=> round( Configuration::get('EXPEDIPRO_VERSION'), 1, PHP_ROUND_HALF_DOWN),
            'deliveryCost'	=> ['selected' => intval( Configuration::get('EXPEDIPRO_DELIVERYCOST') ) ],
            'deliveryMessage'=>['selected' => intval( Configuration::get('EXPEDIPRO_DELIVERYMESSAGE') ) ],
            'orderState'	=> $config->getStateList( Configuration::get('EXPEDIPRO_ORDERSTATE'), 'sendable' ),
            'deliveryBefore'=> $config->getStateList( Configuration::get('EXPEDIPRO_DELIVERYBEFORE'), 'deliveryBefore' ),
            'deliveryStart'	=> $config->getStateList( Configuration::get('EXPEDIPRO_DELIVERYSTART'), 'deliveryStart' ),
            'deliveryDone'	=> $config->getStateList( Configuration::get('EXPEDIPRO_DELIVERYDONE'), 'deliveryDone' ),
            'orderCarrier'	=> $config->getCarrierList( Configuration::get('EXPEDIPRO_ORDERCARRIER') ),
            'diagnoseOrder' => $config->diagnoseOrder(),
            'diagnoseUrl'   => $config->diagnoseUrl( _PS_BASE_URL_SSL_. '/modules/expedipro/controller.php' )
            ]
        );

        // PHP_VERSION (chaîne de caractères) => "major.minor.release[extra]"
        $output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configHeader_14.tpl');
        $output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configConnection_14.tpl');
        $output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configCarrier_14.tpl');
        $output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configOrder_14.tpl');
        $output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configDelivery_14.tpl');
        $output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configDiagnose_14.tpl');
        //$output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configFooter_14.tpl');

        return $output;
    }


    /**
     * Remove previous 2.5 files if previous module had not been removed first
     * Note: does not manage discrepancies under tpl/
     */
    public function cleanup25( ) :bool
    {
        $currentDir = dirname(__FILE__);
        if (! $handle = opendir($currentDir) )
            return false;

        while ( false !== ( $entry = readdir($handle)) )
        {
            switch ( $entry ) {
                case 'config_.xml':
                case 'expediproAction.php':
                case 'expediproConfig.php':
                case 'expediproDelivery.php':
                case 'expediproFunctions.php':
                case 'expediproMapper.php':
                case 'expediproOrder.php':
                    unlink($currentDir . '/' . $entry);
                    break;
                default: // including ($entry === "." OR $entry === "..")
                    continue;
            }
        }
        closedir($handle);
        return true;
    }
}
?>