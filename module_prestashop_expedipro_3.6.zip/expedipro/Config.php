<?php
/**
* 2014 Expedipro
*
*  @author Expedipro SAS <contact@expedipro.com>
*  @copyright  2014 Expedipro SAS
*  International Registered Trademark & Property of Expedipro SAS
*/

use PrestaShop\PrestaShop\Core;
use Expedipro\Module\Action;    // for diagnoseOrder


class Config extends Module
{
	protected	$carrierList = [];	// avoid several db access
    protected   $carrierDbName;     // since db change given version
    protected	$stateList = [];	// avoid several db access

	// DI of context
	public function __construct( $context = null)
	{
	    // required only by 1.6 because thre is no composer at PrestaShop level
        require_once( dirname(__FILE__) . '/vendor/autoload.php');

        $this->languageId = intval( $context->language->id ?? 1);
	}


	/**
	 * Handle the validation of config <form>
	 *
	 * @return	string	error messages
	 */
	public function configPost()
	{
		$output = ''; // local avoid confusion with caller $this->_output
		/**
		 *Do not named submit button "configure" otherwise submit would trigger "module not found"
		 */

		// POST processing using submit name
		if( \Tools::isSubmit('submitConfigUrl') ) {
            \Configuration::updateValue('EXPEDIPRO_TOKEN', $this->randomString(32) );
		}


		if ( \Tools::isSubmit('submitConfigCarrier') )
		{
/*
			if( $orderWeight = Tools::getValue('orderWeight') )	// in grammes
			{
//				$orderWeight = (float) str_replace ( ',', '.', $orderWeight );	// Allows decimal separator comma or dot
//				Configuration::updateValue('EXPEDIPRO_ORDERWEIGHT', ( Validate::isOptFloat($orderWeight) ? $orderWeight : 0 ) );
				Configuration::updateValue('EXPEDIPRO_ORDERWEIGHT', (int) $orderWeight );
			}
*/
//ppp($_POST);
//ppp( Tools::getValue('orderCarrier') );
			// Because of html constraints, orderCarrier must always be handled
			if ( ! $orderCarrier = \Tools::getValue('orderCarrier') ) {													// unchecked box need to be delete
                \Configuration::updateValue('EXPEDIPRO_ORDERCARRIER', null );
			} else {
				//ppp( var_dump(Validate::isUnsignedInt($orderCarrier)) );
                \Configuration::updateValue('EXPEDIPRO_ORDERCARRIER', $this->transformCheckbox('carrier', $orderCarrier ) );
			}
		}


		if ( \Tools::isSubmit('submitConfigOrder') ) {
//ppp( Tools::getValue('orderState') );
            // Because of html constraints, orderState must always be handled
            if ( ! $state = \Tools::getValue('orderState') ) {
                \Configuration::updateValue('EXPEDIPRO_ORDERSTATE', null);                           // unchecked box (multi choice) need to be delete
            } else {
                //ppp( var_dump(Validate::isUnsignedInt($orderState)) );
                \Configuration::updateValue('EXPEDIPRO_ORDERSTATE', $this->transformCheckbox('state', $state));
            }
        }



        if ( \Tools::isSubmit('submitConfigDelivery') )
        {
            $state = \Tools::getValue('deliveryBefore') ?: 3; // En cours de préparation
            \Configuration::updateValue('EXPEDIPRO_DELIVERYBEFORE', $this->transformCheckbox('state', $state ) );

            $state = \Tools::getValue('deliveryStart') ?: 4; // transport
            \Configuration::updateValue('EXPEDIPRO_DELIVERYSTART', $this->transformCheckbox('state', $state ) );

            $state = \Tools::getValue('deliveryDone') ?: 5; // livré
            \Configuration::updateValue('EXPEDIPRO_DELIVERYDONE', $this->transformCheckbox('state', $state ) );

            \Configuration::updateValue('EXPEDIPRO_DELIVERYMESSAGE', intval(Tools::getValue('deliveryMessage') ) );
            \Configuration::updateValue('EXPEDIPRO_DELIVERYCOST', intval( Tools::getValue('deliveryCost') ) );
        }

        return $output;
	}


	/**
	 * Transform int|array POST checkbox|radio into int|string (single or multi values)
	 *
	 * @param string	$scope	'carrier' | 'state'
	 * @param int|array $input
	 *
     * @return null|int|string with int separated by |
     **/
	private function transformCheckbox( $scope= '' , $input= null)
	{
		if ( ! $scope OR ! $input )
            return null;
//ppp( "/debug carrier:" );
//ppp( $input );
        if  ( is_array($input) )										// multi select
		{
			$list ='';
			foreach ( $input as $row )
			{
				if ($scope === 'carrier') {
					if (! $this->isValidCarrierId( $row ) ) continue;
				} else {
					if (! $this->isValidStateId( $row ) ) continue;
				}

				$list .= (int) $row . '|';
			}

			if ( $list ) {
				$list = \Tools::substr($list, 0, -1 );
			}
			//$list = implode( '|' , array_map('intval', $input ) ); // can not check ids existence
//ppp( var_dump($list) );
			return $list;
		}
		elseif ( \Validate::isUnsignedInt( $input ) )                    // singleton
        {
			if ($scope === 'carrier') {
				return ( $this->isValidCarrierId( $input ) ? (int) $input : null );
			} else {
				return ( $this->isValidStateId( $input ) ? (int) $input : null );
			}
		}
	}


    /**
	 * Get order state from Prestashop config (sendable ones) along with expedipro_orderState status
	 * Note : filter only default Prestashop, not the user specifics ones
     *
     * @param string	$currentList of state from db like "<val>|<val>"
	 * @param string	$filter name
	 *
	 * @return array:
	 */
	public function getStateList( $currentList = "", $filter= '' )
	{
		/**
		 * 9		reappro
		 * 1,10,11	attente chèque,virement,paypal
		 * 8  erreur paiement
		 * 12 paiement ok
		 * 2 payé
		 * 3 prépa
		 * 4 transport
		 * 5 Livré
		 * 6, 7	annulé , remboursé
		 */
        $currentArray = explode( '|', $currentList );
		switch ( $filter ) {
			case 'sendable':
                // 9: reappro allows sending half of the order
				$filterState = [ 1,        5, 6, 7, 8, 10, 11 ];
				break;
            case 'deliveryStart':
                $filterState = [ 1, 2,        6, 7, 8, 10, 11, 12 ];
                break;
            case 'deliveryDone':
                $filterState = [ 1, 2, 3,     6, 7, 8, 10, 11, 12 ];
                break;
/*
            case 'deliveryFail':
                $filterState = array( 1, 2, 3,  5, 6, 7, 8, 10, 11 );
                $currentlySelected = explode( '|', Configuration::get('EXPEDIPRO_DELIVERYFAIL') );
                break;
*/
            default:
                $filterState = array();
		}

//        if ( ! $filteredState = $this->filterStateList( $filterState ) )
//            return array();

		$result = [];
		foreach( $this->filterStateList( $filterState ) AS $id => $name)
        {
			$result[ $id ] = [
                'name'		=> $name,
				'selected'	=> ( in_array( $id, $currentArray ) ? 1 : 0 )
			];
		}

		//var_dump($result);
		return $result;
	}


    /**
     * Extract all order states defined in Prestashop
     *  Usage : provide an simple array of keys to remove from the reference list of states
     *
     * @param array		$filter (negative)
     *
     * @return array [ (int) id => (string) name ]
     */
    public function filterStateList( $filter = array() )
    {
        if ( ! $this->stateList )
        {
            $order = new \OrderStateCore();
            if (! $this->stateList = $order->getOrderStates( $this->languageId ) )
                return [];
        }

        $result = [];
        foreach ($this->stateList AS $state)
        {
            if ( $filter AND in_array( $state['id_order_state'], $filter) )
                continue;

            $result[ $state['id_order_state'] ] = $state['name'];
        }

        return $result;
    }


	/**
	 *
	 * @param int		$stateId
	 *
	 * @return boolean:
	 */
	public function isValidStateId( $stateId = null)
	{
        if ( ! $filteredState = $this->filterStateList( ) )
            return false;

        return isset( $filteredState[ (int) $stateId ] );	// for input check
	}


    /**
     * Extract module version table to detect conflict with modules like dpd, mondialrelay, etc
     *
     * @return array|null
     */
    public function getModulesVersionInstalled( )
    {
        try {
            if ( $mod = Db::getInstance()->ExecuteS('SELECT `name`,`active`,`version` FROM ' . _DB_PREFIX_ . 'module ORDER BY `name`') )
                return $mod;
        }catch( Exception $e ) {
            return null;
        }
    }


    /**
     * @param array|null $filter
     * @return array
     */
    public function filterCarrierList(array $filter = null ) :array
    {
        $this->carrierDbName = 'id_reference' ;
        //  only active carriers (2020-07), defined as [] by default
        $this->carrierList = $this->carrierList ?: \Carrier::getCarriers($this->languageId, false, false, false, NULL, ALL_CARRIERS ); // from defines.inc.php

//        var_dump( \Carrier::getCarriers(1, false, false, false, NULL, ALL_CARRIERS ) );
        // TODO  in some case Carrier::getCarriers may fail because it select column from left join, without appropriate group by
        $sql = 'SELECT c.`id_carrier`, c.`id_reference`, c.`name`, c.`position`
		FROM `'._DB_PREFIX_.'carrier` c
		WHERE c.`deleted` = 0
		GROUP BY c.`id_carrier`
        ORDER BY c.`position` ASC';

        /**
         * Any change in carrier deprecated it and duplicate as new one
         * id_reference give a way to chain id_carrier changes
         */
        $result = [];
        foreach ($this->carrierList as $carrier)
        {
            if ( $filter AND in_array($carrier[ $this->carrierDbName ], $filter))
                continue;

            $result[ $carrier[ $this->carrierDbName ] ] = $carrier['name'];
        }

        return $result;
    }


    /**
	 * Get order state from Prestashop config (sendable ones) along with expedipro_orderState status
	 *
     * @param string $currentList
     *
     * @return array
     */
	public function getCarrierList( string $currentList = null ) :array
	{
		$currentArray = explode( '|', $currentList ); // null tolerant
        $result = [];
        foreach ( $this->filterCarrierList() AS $id => $name )
        {
            $result[ $id ] = [
                'name'		=> $name,
                'selected'	=> in_array( $id, $currentArray )
            ];
        }
        return $result;
	}


	/**
	 *
	 * @param int		$carrierId
	 *
	 * @return bool
	 */
	public function isValidCarrierId( $carrierId = null) :bool
	{

        if ( ! $filteredCarrier = $this->filterCarrierList( ) )
            return false;

        return isset( $filteredCarrier[ (int) $carrierId ] );
	}


    /**
     * Generate a random string
     * PHP 7+ random_int() is a PHP core function
     *
     * @param int $length (default is 32 like ebay)
     *
     * @return string
     */
    public function randomString(int $length = 32) :string
    {
        $charSetKey = str_shuffle("0123456789-abcdefghijklmnopqrstuvwxyz_ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        $charSetSize = mb_strlen($charSetKey, 'UTF-8') - 1;

        $result = [];
        for ($i = 0; $i < $length; ++$i) {
            /* safe only when $charSetKey contains single Byte chars */
            $result [] = $charSetKey[random_int(0, $charSetSize)];
        }
        return implode('', $result);
    }


    public function diagnoseUrl( $actionUrl )
    {
//        return 'non testé';
        $url = $actionUrl.'?tellMe='.  hash('sha256', \Configuration::get('EXPEDIPRO_TOKEN') );
//        var_dump( $url );
        // approx 5 when telleMe fail, and 70K when tellMe is ok
        if ( strlen( file_get_contents( $url) ) < 100 )
            return 'A vérifier : '.$actionUrl. ' semble inaccessible';

        return 'OK';
    }

/*
    public function diagnoseCurl( ){
        if ( version_compare(PHP_VERSION, '5.3','<') )
            return 'PHP too old for testing';
        try {
            if ( $assoc = curl_version() AND isset( $assoc['version'] ) )
                return 'OK';
        } catch (Exception $e) {
            return 'RESTRICTION : autoriser la librairie curl dans Apache/PHP';
        }
    }
*/

    public function diagnoseOrder(int $pastDay = 7)
    {
        $mapper = new Action\Mapper();
        if ( ! $orderlist = $mapper->getOrder( \Configuration::get('EXPEDIPRO_ORDERSTATE'),
                                                \Configuration::get('EXPEDIPRO_CARRIER'),
                                                ( new \DateTime() )->modify("-$pastDay day")->format('Y-m-d') ) )
            return "aucune commande trouvée pour ces critères (période $pastDay jours)";
        return count( $orderlist ) . " commandes trouvées pour ces critères (période $pastDay jours)";
    }


}
?>