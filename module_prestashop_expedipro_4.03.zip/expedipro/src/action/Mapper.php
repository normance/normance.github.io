<?php
/**
 * 2026 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

namespace Expedipro\Module\Action;

class Mapper
{
	protected $languageId;
    protected $hookClassName = 'MapperHook';
    protected $hookClassInstance;

	// DI of context
	public function __construct( $context = null)
	{
	    $this->languageId = ($context ? $context->language->id : 1);

	    // Read MapperHook.readme to understand how to implement customer's SQL requests or orders transformations
        try {
            $path = dirname(__FILE__) .'/'. $this->hookClassName . '.php';
            if ( is_file( $path ) )
            {
                include_once( $path );
                // Instanciated once, by above include
                if (class_exists($this->hookClassName, false)) {
                    $this->hookClassInstance = new $this->hookClassName();
                }
            }
        }
        catch ( \Exception $e ) {
            // regular use case
        }
/*
        $this->statusMapping = $this->deliveryState(
            \Configuration::get('EXPEDIPRO_DELIVERYBEFORE'),
            \Configuration::get('EXPEDIPRO_DELIVERYSTART'),
            \Configuration::get('EXPEDIPRO_DELIVERYDONE') );
*/
	}

	public function isHookFunctionExist( string $hookFunction ) :bool
    {
        return ($this->hookClassInstance && method_exists($this->hookClassInstance, $hookFunction));
    }

    /**
     * Get order that has just moved in a state within a time period
     *
     * @param null      $state
     * @param null      $carrier
     * @param string|null $from php DateTime compatible
     * @param string|null $to php DateTime compatible
     * @param bool      $debug to ignore previous parameters
     *
     * @return array
     * @throws \Exception
     */
	public function getOrder($state = null, $carrier = null, ?string $from = null, ?string $to = null, bool $debug = false) :array
    {
        // since even 2014-07-01 99:30:00 trigger a fatal error
        try {
            $pointInTime = new \DateTime($from ?? 'now');
        } catch (\Exception $e) {
            $pointInTime = new \DateTime ();
        }
        $whereFrom = $pointInTime->format('Y-m-d H:i:s');

        try {
            $pointInTime = new \DateTime ( $to ?? 'now');
        } catch (\Exception $e) {
            $pointInTime = new \DateTime ();
        }
        $whereTo = $pointInTime->format('Y-m-d H:i:s');

        if (!$state) {
            $whereOrder = ' ( 1 = 1 )';
        } elseif (is_array($state)) {
            $whereOrder = ' ("' . implode('","', $state) . '")';
        } else {
            $whereOrder = ' (' . $this->quote($state) . ')';
        }

        if (!$carrier) {
            $whereCarrier = ' ( 1 = 1 )';
        } elseif (is_array($carrier)) {
            $whereCarrier = ' ("' . implode('","', $carrier) . '")';
        } else {
            $whereCarrier = ' (' . $this->quote($carrier) . ')';
        }

        if ( version_compare(_PS_VERSION_, '8', '<' ) )
            throw new \Exception( 'Votre version de Prestashop doit être (8) au minima : '._PS_VERSION_ );

        // If you want to write your own sql to extract orders and carts, see methods get[Order|Cart]Request() into MapperHook.readme
        return $this->normalizeOrderFromDb(
            ( $this->isHookFunctionExist( 'getOrderRequest' )
                ? $this->hookClassInstance->getOrderRequest( $whereFrom, $whereTo, $whereOrder, $whereCarrier, $debug )
                : $this->getOrderRequest9($whereFrom, $whereTo, $whereOrder, $whereCarrier, $debug)
            ),
            ( $this->isHookFunctionExist( 'getCartRequest' )
                ? $this->hookClassInstance->getCartRequest( $debug )
                : $this->getCartRequest9( $debug )
            )
        );
    }


    protected function normalizeOrderFromDb( string $orderRequest, string $cartRequest ) :array
    {
        if ( ! $order = \Db::getInstance()->executeS( $orderRequest ) )
            return [];

        $result = [];
        // get pickup info for all carts in once
        // not all carts becomes orders (cancelled before payment)
        $allPickup = ( new MapperPickup() )->getPickupServiceId( array_column($order,'cartId'/*orders.id_cart*/), array_column($order,'reference' /*orders.id_order*/) );

        // PDO::FETCH_ASSOC
        foreach ( $order as $one )
        {
            if ( isset( $allPickup['cartId'][ $one['cartId'] ] ) )
                $one['siteLivraison'] = $allPickup['cartId'][ $one['cartId'] ]; //  (string) | [id: ,type:]
            elseif ( isset( $allPickup['orderId'][ $one['reference'] ] ) )
                $one['siteLivraison'] = $allPickup['orderId'][ $one['reference'] ];
            else
                $one['siteLivraison'] = null;

            // $cartRequest must use %1$s to allow multi usage of the id
            if ( $cart = \Db::getInstance()->executeS( sprintf( $cartRequest, $one['reference'] /*orders.id_order*/ ) ) )
            {
                // sql does a max(), all $item has the same long,larg,haut
                $one['long'] = $cart[0]['long'] ?? 0;
                $one['larg'] = $cart[0]['larg'] ?? 0;
                $one['haut'] = $cart[0]['haut'] ?? 0;

                foreach( $cart as &$item )
                    unset( $item['long'],$item['larg'],$item['haut']);
            }
            $one['panier'] = $cart ?? [];

            // If you want to add an id, replace values, etc. see methods transformOrder() into MapperHook.readme
            if ( $this->isHookFunctionExist( 'transformOrder' ) )
                 $one = $this->hookClassInstance->transformOrder( $one, $allPickup );

            if ( isset( $one[0] )  )
                array_push( $result, ...$one); // hook may create N orders from $one
            else
                $result[] = $one;
        }
        $order = null;
        return $result;
    }


    /**
     * Return sql ready request to get one cart details
     *
     * @param bool $debug
     * @return string
     */
    protected function getCartRequest9( bool $debug ) :string
    {
        /*
            SUM( od.`product_weight`) AS "poids",
            o.`total_products_wt` 	AS "valeurTtc",
            SUM( od.`product_quantity`) AS "quantite",
            o.`total_products_wt` 	AS "valeur",
        */

        $sql= ' SELECT 
                od.`product_reference` AS "id", 
                CONVERT(pl.`name` USING utf8mb4) AS "desc",
				ROUND( od.`product_price`,2)  AS "val",
				od.`product_quantity`         AS "qte",
				ROUND( od.`product_weight`,3) AS "poids",

				MAX( p.`depth`)  		AS "long",
				MAX( p.`width`)  		AS "larg",
				MAX( p.`height`) 		AS "haut"

				FROM `'._DB_PREFIX_.'orders`		AS o
				LEFT JOIN `'._DB_PREFIX_.'order_detail` AS od ON  o.`id_order` = od.`id_order`

				LEFT JOIN `'._DB_PREFIX_.'product`      AS p  ON od.`product_id` =  p.`id_product`

				LEFT JOIN `'._DB_PREFIX_.'product_lang` AS pl ON od.`product_id` = pl.`id_product`
				                         AND  o.`id_shop` = pl.`id_shop` AND  pl.`id_lang`= '. $this->languageId .'
 				
		WHERE od.`id_order` = %1$s
        GROUP BY o.`id_order`, od.`id_order_detail`, p.`id_product`';
        if ( $debug )
            echo json_encode(["getCartRequest" => str_replace(["\t","\r\n"],"",$sql)]);

        return $sql;
    }

    /**
     * Return sql ready request to get all orders to export to Expedipro
     *
     * @param $whereFrom
     * @param $whereTo
     * @param $whereOrder
     * @param $whereCarrier
     * @param $debug
     * @return string
     */
    protected function getOrderRequest9($whereFrom, $whereTo, $whereOrder, $whereCarrier, $debug) :string
    {
        /*
         * contenu could be very long ! while expedipro db is 255 and view should be around 70. watchout commandes drag !
         * get phone AND mobile
         * get autre or message ? into instruction
         * manage company name in adress 3 ?
         *
         * To enable the VAT management you need to install a core module and then set the vat field (in the address page list in BO) as required.
         * dni stands for Documento Nacional de Identidad, for Spanish citizens
         *
         * cartId is used later to look for pickup choice
         *
         * Important: MySQL 8+ required with PrestaShop 9
         */
        $sql = 'SELECT 
                if ( c1.`id_gender` = 1, "M", "F") AS "civilite",
				a1.`lastname` 		AS "nom",
				a1.`firstname` 		AS "prenom",
				if ( LENGTH(c1.`company`) > 1 , 1, 0 ) 	AS "entreprise",
                c1.`company` 							AS "entrepriseNom",
				a1.`vat_number`		AS "entrepriseTva",
				a1.`address1` 		AS "adresse1",
				a1.`address2` 		AS "adresse2",
				IF ( LENGTH(a1.`company`) > 1 , UPPER( a1.`company` ), "" )	  AS "adresse3",
				a1.`postcode` 		AS "codePostal",
				a1.`city` 			AS "ville",
				n.`iso_code` 		AS "pays",
				a1.`phone`			AS "telephoneF",
				a1.`phone_mobile` 	AS "telephoneM",
				c1.`email` 			AS "email",
                IF( a1.`other` > "", a1.other, IF( m1.`message` > "", m1.`message`, null) ) AS "instruction",
				c1.`optin`			AS "optin",
				a1.`id_address` 	AS "codeClient",

				o.`id_order` 		AS "reference",
				o.`id_cart` 		AS "cartId",
				o.`date_add` 		AS "date",
				REPLACE(s.`name`, " ", "") AS "canal",

				null				AS "consigne",
				osl.`name` AS "state",  /* DO NOT CHANGE, see debug */
				c.`name` 				AS "transport"

				FROM `'._DB_PREFIX_.'orders`		AS o
				LEFT JOIN `'._DB_PREFIX_.'address`		AS a1	ON  o.`id_address_delivery` = a1.`id_address`
				LEFT JOIN `'._DB_PREFIX_.'customer`		AS c1	ON a1.`id_customer`			= c1.`id_customer`
/*				LEFT JOIN `'._DB_PREFIX_.'country_lang`	AS y1	ON a1.`id_country` 			= y1.`id_country`
				                            AND y1.`id_lang`= '.  $this->languageId .'  */
				LEFT JOIN `'._DB_PREFIX_.'country` 		AS n	ON a1.`id_country` 			=  n.`id_country`
                
                LEFT JOIN (SELECT `id_order`, `id_customer`, `message`
					 		FROM `'._DB_PREFIX_.'message`
					 		WHERE `private` =  0
							    AND ( `id_employee` =  0 OR `id_employee` IS NULL )
							    ORDER BY `date_add` DESC limit 1) AS m1 
					ON o.`id_order` = m1.`id_order` AND  o.`id_customer` =  m1.`id_customer`
                LEFT JOIN `'._DB_PREFIX_.'carrier` 	AS c 	ON o.`id_carrier` = c.`id_carrier`
                
                JOIN `'._DB_PREFIX_.'shop` 	AS s	ON  o.`id_shop` 	=  s.`id_shop`
                JOIN `'._DB_PREFIX_.'order_history` AS oh ON o.`id_order` = oh.`id_order`  ';

        if ( $debug ) {
            $sql = str_replace( 'osl.`name` AS "state"',  // KEEP IT aligned with above request
                'CONCAT_WS(",",oh.`date_add`,  "id_order_state:", oh.`id_order_state`, "id_carrier:", o.`id_carrier` ) AS "debugCriteria"',
                $sql );
            $sql .= ' 
                GROUP BY o.`id_order`, oh.`id_order_state`, m1.`message` /* required by sql_mode=only_full_group_by */
           		ORDER BY o.`id_order` DESC, oh.`id_order_state` ASC
				LIMIT 0, 500';
            // this allows to see all orders states, but limit to avoid having full dump of orders * order_history !
            echo json_encode(["getOrderRequest" => str_replace(["\t","\r\n"],"",$sql)]);
        }
        else
        {
            $sql .= ' 
                JOIN (SELECT `id_order`, MAX(`id_order_history`) AS "maxOrderHistory"
					FROM `'._DB_PREFIX_.'order_history`
					WHERE  `date_add` >= "'.$whereFrom.'" AND `date_add` <= "'.$whereTo.'"
					GROUP BY `id_order` ) AS oh2  
				  ON o.`id_order` = oh2.`id_order` AND oh.`id_order_history` = oh2.`maxOrderHistory`
				
                LEFT JOIN `'._DB_PREFIX_.'order_state_lang` AS osl ON oh.`id_order_state` = osl.`id_order_state` AND  osl.`id_lang`= '.  $this->languageId .' 

                WHERE oh.`id_order_state` IN '. $whereOrder .'
					 AND o.`id_carrier` IN ( SELECT `id_carrier` FROM `'._DB_PREFIX_.'carrier` WHERE `id_reference` IN '. $whereCarrier .' )
                GROUP BY o.`id_order`, m1.`message` /* sql_mode=only_full_group_by and more than 1 state into id_order_state IN() */
				ORDER BY o.`id_order` ASC';
        }

        return $sql;
    }

/*
    public function transformOrder( array $oneOrderWithCart, array $allPickup = null ) :array
    {
        $manyOrdersWithCart= []; //Initialise un tableau vide pour le retour si jamais et nous avions une erreur 500 l'autre fois pour régler le souci.

        if( ! $id_order = (int) $oneOrderWithCart['orderId'] ) // gére aussi les cas tous aussi bizarre 0 et null
        {
            $sql = 'SELECT * FROM '._DB_PREFIX_.'seller_order WHERE id_order = '. $id_order; //Requète pour récupérer les ID vendeur
            $order_seller = \Db::getInstance()->executeS($sql); //Exécute la requete.

            $ite = 0; // Puis on enregistre //Itinérance plus blabla.

            foreach ( $order_seller as $os )
            {
                $oneOrderWithCart['specific'] = $os['id_seller']; // later use for matching with expedipro sub-accounts
                $oneOrderWithCart['iteration']= $ite; // expedipro make a unique check over reference+iteration
//note: panier remains the same for all sellers
                $ite++;

                $manyOrdersWithCart[] = $oneOrderWithCart;
            }
        }
        return $manyOrdersWithCart; // note: no longer the original parameter
    }
*/

    /**
	 * Circumvent EmployeeCore->add() or save() which fail for unknown reasons
	 * Note the fake password that would never allow login
     *
     * @param string $email
     * @return mixed
     */
	public function setExpediproEmployee( string $email =''  )
	{
		$allProfile = array_column( (new \Profile() )->getProfiles( $this->languageId ), 'name', 'id_profile') ?? [];
		if ( ! $logisticien = array_search('logisticien',array_map('strtolower',$allProfile)) )
			$logisticien = 2;

		$sql =  'INSERT INTO `'._DB_PREFIX_.'employee`
				(`lastname`,`firstname`,`id_profile`,`id_lang`,`email`,`passwd`,`active`)
				VALUES 	(
					"EXPEDIPRO",
					"",'.
					$logisticien .','.
                    $this->languageId .',"'.
					$email .'",
					"_____________________________",
					0)';

		\Db::getInstance()->execute($sql);
		return \Db::getInstance()->Insert_ID();
	}


    /**
	 * Circumvent EmployeeCore->getByEmail() which required employee to be active
     *
     * @param string $email
     *
     * @return int
     */
	public  function getExpediproEmployee( string $email ='') :int
	{
		$sql = 'SELECT `id_employee`
				FROM `'._DB_PREFIX_.'employee`
				WHERE `email` = "'. $this->quote( $email ) .'"';

		if ( ! $result = \Db::getInstance()->executeS($sql) )
			return 0;

		$result = array_pop( $result );
		return $result['id_employee'];
	}


    protected function quote($value)
    {
        if (is_int($value)) {
            return $value;
        } elseif (is_float($value)) {
            return sprintf('%F', $value);
        } elseif (is_array($value)) {
            foreach ($value as &$val) {
                $val = $this->quote($val);
            }
            return implode(', ', $value);
        }
        return "'" . addcslashes($value, "\000\n\r\\'\"\032") . "'";
    }


    /**
     * Map expedipro generic status with ones chosen in back office
     * Note: int values came here typed as string (from db)
     *
     * @param string|int|null $before
     * @param string|int|null $start
     * @param string|int|null $done
     *
     * @return array
     */
    public function deliveryState( $before = null, $start = null, $done = null) :array
    {
        /**
        Expedipro steps
        1	dépôt
        10	Chargé
        11	Chargé
        20	Transport
        30	Douane
        40	Problème
        50	Transport
        60	Imminent
        70	Attente
        80	Relivraison
        90	Retour
        100	Livré
         */
        return [
            1 => $before ?: null, // Configuration() seems returning '' when null in DB
            10 => $start ?: null,
            11 => $start ?: null,
            20 => $start ?: null,
            30 => $start ?: null,
            40 => $start ?: null,
            50 => $start ?: null,
            60 => $start ?: null,
            70 => $start ?: null,
            80 => $start ?: null,
            90 => $start ?: null,
            100 => $done ?: null,
        ];
    }

}
?>