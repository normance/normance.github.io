<?php
/**
 * 2026 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

namespace Expedipro\Module\Action;

class Order
{
    use ContextCron;

    // Déclarations explicites requises pour PHP 8.2+
    protected $outputFile;
    protected $context;

	public function __construct( ?\Context $context = null ) {
        // required by $actionAdaptor =  new expediproOrder();
        $this->outputFile = dirname(__FILE__) . '/export.csv';
        $this->context = $context ?: $this->setContextCron();
    }


	/**
	 * Extract orders and output them to html
	 *
     * @param array $data
     *
	 * @return array
	 */
	public function process( array $data ) :array
	{
		// avoid using string from client side without basic checks
		return $this->getOrder(
            ( \Validate::isDate( $data['from'] ?? null ) ? $data['from'] : "2019-10-12" ),
            ( \Validate::isDate( $data['to'] ?? null ) ? $data['to'] : null ),
			(bool) ( $data['debug'] ?? false )
        );
	}


	/**
	 * Extract orders and output them (to file AND to html)
	 *
	 * @param string	$from mysql date	inclusive start time interval
	 * @param string	$to					inclusive end time interval
	 * @param boolean	$debug				true just ignore previous parameters (debug purpose)
	 *
	 * @return array
	 */
	protected function getOrder( string $from, ?string $to = null, bool $debug = false ) :array
	{
		// extract orders from DB
        try {
		    $orders = ( new Mapper( $this->context ) )
                            ->getOrder(
		                        explode('|', \Configuration::get('EXPEDIPRO_ORDERSTATE') ),
                                explode('|', \Configuration::get('EXPEDIPRO_ORDERCARRIER') ),
                                $from,
                                $to,
                                $debug );

        } catch ( \Exception $e ) {
            // L'adaptateur DbPDO (qui hérite de Db) qui exécute la requête executeS()
            echo 'l\'extraction des commandes de votre base Prestashop est impossible : ' . $e->getMessage() ;
			return [];
        }

        // Remove control, formatting, surrogate characters, UTF-8 opening and closing quotes(except ' and "), and convert all kind of spaces to spaces
        $cleanupRegexp = "/[\p{Cf}\p{Cs}\p{Cn}\p{Co}\p{Pi}\p{Pf}\p{Z}\p{Xsp}]+/u";
        // preg_replace [ [] ] returns [ "array' ]
        array_walk_recursive( $orders, function( &$value ) use( $cleanupRegexp ) {
            if ( $value )
                $value = preg_replace( $cleanupRegexp, ' ', $value );
        }); // only walk through leaves, not the nodes, but fine here

//		$file = fopen($this->outputFile, "w" );	// not required, but it might be useful one day
        echo json_encode( $orders, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR, 20 ); // . PHP_EOL;
        return $orders; // unused returned array
//		fwrite($file, $line . PHP_EOL);
//		fclose($file);
	}
}