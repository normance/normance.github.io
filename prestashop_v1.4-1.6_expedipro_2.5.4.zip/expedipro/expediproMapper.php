<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

class ExpediproMapper
{
/** 
Expedipro steps
1	dépôt
10	Chargé
11	Chargé
20	Transport
30	Douane
40	Problème
50	Transport
60	Imminent
70	Attente
80	Relivraison
90	Retour
100	Livré
*/
	protected $context; 	// instead of using Context:: which is 1.5+ specific, we rely on this context variable
	protected $statusMapping;

	// DI of context
	public function __construct( $context = null)
	{
//        var_dump( $context );
        if ( $context ) {
            $this->context = $context;
        } else {
            include_once(_PS_MODULE_DIR_.'expedipro/expediproFunctions.php');
            $this->context = prestashop_initContext();
        }

//        print_r( $this->context);
        $this->statusMapping = expedipro_deliveryMapping( $this->context->expedipro->deliveryStart, $this->context->expedipro->deliveryDone );

	}

	/**
	 * Get order that has just moved in a state within a time period
	 *
	 * @param number|array	$state
	 * @param number|array	$carrier
	 * @param string 		$from 	php DateTime compatible
	 * @param string 		$to 	php DateTime compatible
	 * @param boolean 		$debug to ignore previous parameters
	 *
	 * @return false|array()
	 */
	public function getOrder($state = null, $carrier = null,  $from = null, $to = null, $debug = false)
    {
        if ($debug) {
            print_r($this->context->expedipro);
            print_r($this->context->language);
        }

        // since even 2014-07-01 99:30:00 trigger a fatal error
        try {
            $pointInTime = new DateTime ($from);
        } catch (Exception $e) {
            $pointInTime = new DateTime ();
        }
        $whereFrom = $pointInTime->format('Y-m-d H:i:s');

        try {
            $pointInTime = new DateTime ($to);
        } catch (Exception $e) {
            $pointInTime = new DateTime ();
        }
        $whereTo = $pointInTime->format('Y-m-d H:i:s');

        if (!$state) {
            $whereOrder = ' ( 1 = 1 )';
        } elseif (is_array($state)) {
            $whereOrder = ' ("' . implode('","', $state) . '")';
        } else {
            $whereOrder = ' (' . $this->quote($state) . ')';
        }

        if (!$carrier) {
            $whereCarrier = ' ( 1 = 1 )';
        } elseif (is_array($carrier)) {
            $whereCarrier = ' ("' . implode('","', $carrier) . '")';
        } else {
            $whereCarrier = ' (' . $this->quote($carrier) . ')';
        }

        $sql = ( version_compare(_PS_VERSION_, '1.5', '>')
                ? $this->getOrder15($whereFrom, $whereTo, $whereOrder, $whereCarrier, $debug)
                : $this->getOrder14($whereFrom, $whereTo, $whereOrder, $whereCarrier, $debug) );

        if ($debug)
            var_dump($sql);

        //die;
        return ($sql ? Db::getInstance()->ExecuteS($sql) : false);
    }



    protected function getOrder14($whereFrom, $whereTo, $whereOrder, $whereCarrier, $debug) {

		/*
		 * contenu could be very long
		 * get phone AND mobile
		 * get autre or message ? into instruction
		 * manage company name in adress 3 ?
		 *
		 * To enable the VAT management you need to install a core module and then set the vat field (in the address page list in BO) as required.
		 * dni stands for Documento Nacional de Identidad, for Spanish citizens
		 */

		/*
			SUM( od.`product_weight`) AS "poids",
			o.`total_products_wt` 	AS "valeurTtc",
			SUM( od.`product_quantity`) AS "quantite",
			o.`total_products_wt` 	AS "valeur",
		*/

		$sql = 'SELECT c1.`id_gender` AS "civilite",
				a1.`lastname` 		AS "nom",
				a1.`firstname` 		AS "prenom",
				if ( LENGTH(a1.`vat_number`) > 1 , 1, 0 ) AS "entreprise",
				if ( LENGTH(a1.`vat_number`) > 1 ,a1.`lastname` , "" )	AS "entrepriseNom",
				a1.`vat_number`		AS "entrepriseTva",
				a1.`address1` 		AS "adresse1",
				a1.`address2` 		AS "adresse2",
				IF ( LENGTH(a1.`company`) > 1 , UPPER( a1.`company` ), "" )	  AS "adresse3",
				a1.`postcode` 		AS "cp",
				a1.`city` 			AS "ville",
				n.`iso_code` 		AS "pays",
				a1.`phone`			AS "telephone",
				a1.`phone_mobile` 	AS "mobile",
				c1.`email` 			AS "email",
				IF( a1.`other` > "", a1.other, IF( m1.`message` > "", m1.`message`, "") ) AS "instruction",
				c1.`optin`			AS "optin",
				a1.`id_address` 	AS "client",
				o.`id_order` 		AS "reference",
				o.`date_add` 		AS "dateComm",
				"" 		            AS "boutique",
                -- can not use p.`reference`
                -- null > "" is also false
				GROUP_CONCAT( IF( od.`product_reference` > "", concat(od.`product_reference`," : "),""), CONVERT(pl.`name` USING utf8) SEPARATOR "ǁ")  AS "panierDesc",
				GROUP_CONCAT( ROUND(od.`product_price`,2)	SEPARATOR "ǁ" ) AS "panierPrix",
				GROUP_CONCAT( od.`product_quantity` 		SEPARATOR "ǁ" ) AS "panierQte",
				GROUP_CONCAT( od.`product_weight` 			SEPARATOR "ǁ" ) AS "panierPoids",

				MAX( p.`depth`)  		AS "longueur",
				MAX( p.`width`)  		AS "largeur",
				MAX( p.`height`) 		AS "hauteur",
				"" 						AS "allotir",
				oh.`id_order_state` 	AS "state",
				c.`name` 				AS "transporteur"
				FROM `'._DB_PREFIX_.'orders`		AS o
				LEFT JOIN `'._DB_PREFIX_.'address`		AS a1	ON  o.`id_address_delivery` = a1.`id_address`
				LEFT JOIN `'._DB_PREFIX_.'customer`		AS c1	ON a1.`id_customer`			= c1.`id_customer`
				LEFT JOIN `'._DB_PREFIX_.'country_lang`	AS y1	ON a1.`id_country` 			= y1.`id_country`
				                            AND y1.`id_lang`= '. (int) $this->context->language->id .'
				LEFT JOIN `'._DB_PREFIX_.'country` 		AS n	ON a1.`id_country` 			=  n.`id_country`
				LEFT JOIN `'._DB_PREFIX_.'order_detail` AS od	ON  o.`id_order` 			= od.`id_order`
				LEFT JOIN `'._DB_PREFIX_.'product`  	AS p	ON od.`product_id` 			=  p.`id_product`
				LEFT JOIN `'._DB_PREFIX_.'product_lang` AS pl	ON od.`product_id` 			= pl.`id_product`
				                            AND  pl.`id_lang`= '. (int) $this->context->language->id .'
				LEFT JOIN `'._DB_PREFIX_.'carrier` 	    AS c 	ON o.`id_carrier` = c.`id_carrier` 
				LEFT JOIN (SELECT `id_order`, `id_customer`, `message` 
					 		FROM `'._DB_PREFIX_.'message`
					 		WHERE `private` =  0
							    AND ( `id_employee` =  0 OR `id_employee` IS NULL )
							    ORDER BY `date_add` DESC limit 1) AS m1 
							        ON o.`id_order` = m1.`id_order` AND  o.`id_customer` =  m1.`id_customer`';


//--			GROUP_CONCAT( IF( LENGTH(pl.`name`) > 30, SUBSTRING(pl.`name`, 1, 30), pl.`name` ) SEPARATOR "ǁ") AS "produitDesc",
//				GROUP_CONCAT( CONCAT(od.`product_id`, "=", CONVERT(pl.`name` USING utf8)) SEPARATOR "ǁ")  AS "produitDesc",
//--				AND o.valid=1

		if ( $debug ) {
			// this allows to see all orders states, but limit to avoid having full dump of orders * order_history !
			$sql .= ' JOIN `'._DB_PREFIX_.'order_history` AS oh ON o.`id_order` = oh.`id_order`

	                    GROUP BY o.`id_order`, oh.`id_order_state`
    					ORDER BY o.`id_order` DESC, oh.`id_order_state` ASC
						LIMIT 0, 500';
		}
		else
		{
			$sql .= ' JOIN (SELECT `id_order`, MAX(`id_order_history`) AS "maxOrderHistory"
						FROM `'._DB_PREFIX_.'order_history`
						WHERE  `date_add` >= "'.$whereFrom.'" AND `date_add` <= "'.$whereTo.'"
						GROUP BY `id_order` ) 	AS oh2  ON o.`id_order` = oh2.`id_order`

					  JOIN `'._DB_PREFIX_.'order_history` AS oh  ON o.`id_order` = oh.`id_order`
					                AND oh.`id_order_history` = oh2.`maxOrderHistory`

			         WHERE oh.`id_order_state` IN '. $whereOrder .'
					                AND o.`id_carrier` IN '. $whereCarrier .'

					GROUP BY o.`id_order`
					ORDER BY o.`id_order` ASC';
		}

        return $sql;

	}



    protected function getOrder15($whereFrom, $whereTo, $whereOrder, $whereCarrier, $debug) {

        /*
         * contenu could be very long ! while expedipro db is 255 and view should be around 70. watchout commandes drag !
         * get phone AND mobile
         * get autre or message ? into instruction
         * manage company name in adress 3 ?
         *
         * To enable the VAT management you need to install a core module and then set the vat field (in the address page list in BO) as required.
         * dni stands for Documento Nacional de Identidad, for Spanish citizens
         */

        /*
            SUM( od.`product_weight`) AS "poids",
            o.`total_products_wt` 	AS "valeurTtc",
            SUM( od.`product_quantity`) AS "quantite",
            o.`total_products_wt` 	AS "valeur",
        */

        /* Note : as of 1.5 p.depth,width... are not related to the product size but rather to the packaged product */


        $sql = 'SELECT c1.`id_gender` AS "civilite",
				a1.`lastname` 		AS "nom",
				a1.`firstname` 		AS "prenom",
				if ( LENGTH(c1.`company`) > 1 , 1, 0 ) 	AS "entreprise",
                c1.`company` 							AS "entrepriseNom",
				a1.`vat_number`		AS "entrepriseTva",
				a1.`address1` 		AS "adresse1",
				a1.`address2` 		AS "adresse2",
				IF ( LENGTH(a1.`company`) > 1 , UPPER( a1.`company` ), "" )	  AS "adresse3",
				a1.`postcode` 		AS "cp",
				a1.`city` 			AS "ville",
				n.`iso_code` 		AS "pays",
				a1.`phone`			AS "telephone",
				a1.`phone_mobile` 	AS "mobile",
				c1.`email` 			AS "email",
                IF( a1.`other` > "", a1.other, IF( m1.`message` > "", m1.`message`, "") ) AS "instruction",
				c1.`optin`			AS "optin",
				a1.`id_address` 	AS "client",

				o.`id_order` 		AS "reference",
				o.`date_add` 		AS "dateComm",
				REPLACE(s.`name`, " ", "") 	AS "boutique",

				GROUP_CONCAT( IF( od.`product_reference` > "", concat(od.`product_reference`," : "),""), CONVERT(pl.`name` USING utf8) SEPARATOR "ǁ")  AS "panierDesc",
				GROUP_CONCAT( ROUND(od.`product_price`,2)	SEPARATOR "ǁ" ) AS "panierPrix",
				GROUP_CONCAT( od.`product_quantity` 		SEPARATOR "ǁ" ) AS "panierQte",
				GROUP_CONCAT( od.`product_weight` 			SEPARATOR "ǁ" ) AS "panierPoids",

				MAX( p.`depth`)  		AS "longueur",
				MAX( p.`width`)  		AS "largeur",
				MAX( p.`height`) 		AS "hauteur",
				"" 						AS "allotir",
				oh.`id_order_state` 	AS "state",
				c.`name` 				AS "transporteur"
				FROM `'._DB_PREFIX_.'orders`		AS o
				LEFT JOIN `'._DB_PREFIX_.'address`		AS a1	ON  o.`id_address_delivery` = a1.`id_address`
				LEFT JOIN `'._DB_PREFIX_.'customer`		AS c1	ON a1.`id_customer`			= c1.`id_customer`
				LEFT JOIN `'._DB_PREFIX_.'country_lang`	AS y1	ON a1.`id_country` 			= y1.`id_country`
				                            AND y1.`id_lang`= '. (int) $this->context->language->id .'
				LEFT JOIN `'._DB_PREFIX_.'country` 		AS n	ON a1.`id_country` 			=  n.`id_country`
				LEFT JOIN `'._DB_PREFIX_.'order_detail` AS od	ON  o.`id_order` 			= od.`id_order`
				LEFT JOIN `'._DB_PREFIX_.'product`  	AS p	ON od.`product_id` 			=  p.`id_product`
				LEFT JOIN `'._DB_PREFIX_.'product_lang` AS pl	ON od.`product_id` 			= pl.`id_product`
				                            AND  pl.`id_lang`= '. (int) $this->context->language->id .'
   				                            AND  o.`id_shop` = pl.`id_shop`
                LEFT JOIN `'._DB_PREFIX_.'carrier` 	AS c 	ON o.`id_carrier` = c.`id_carrier`
                
                LEFT JOIN (SELECT `id_order`, `id_customer`, `message` 
					 		FROM `'._DB_PREFIX_.'message`
					 		WHERE `private` =  0
							    AND ( `id_employee` =  0 OR `id_employee` IS NULL )
							    ORDER BY `date_add` DESC limit 1) AS m1 
							        ON o.`id_order` = m1.`id_order` AND  o.`id_customer` =  m1.`id_customer`
                
                JOIN `'._DB_PREFIX_.'shop` 	AS s	ON  o.`id_shop` 			=  s.`id_shop` ';

        if ( $debug ) {
            // this allows to see all orders states, but limit to avoid having full dump of orders * order_history !
            $sql .= ' JOIN `'._DB_PREFIX_.'order_history` AS oh ON o.`id_order` = oh.`id_order`

	                    GROUP BY o.`id_order`, oh.`id_order_state`
    					ORDER BY o.`id_order` DESC, oh.`id_order_state` ASC
						LIMIT 0, 500';
        }
        else
        {
            $sql .= ' JOIN (SELECT `id_order`, MAX(`id_order_history`) AS "maxOrderHistory"
						FROM `'._DB_PREFIX_.'order_history`
						WHERE  `date_add` >= "'.$whereFrom.'" AND `date_add` <= "'.$whereTo.'"
						GROUP BY `id_order` ) 	AS oh2  ON o.`id_order` = oh2.`id_order`

					  JOIN `'._DB_PREFIX_.'order_history` AS oh  ON o.`id_order` = oh.`id_order`
					                AND oh.`id_order_history` = oh2.`maxOrderHistory`

			         WHERE oh.`id_order_state` IN '. $whereOrder .'
					                AND o.`id_carrier` IN ( SELECT `id_carrier` FROM `'._DB_PREFIX_.'carrier` WHERE `id_reference` IN '. $whereCarrier .' )

					GROUP BY o.`id_order`
					ORDER BY o.`id_order` ASC';
        }

        return $sql;
    }



	/**
	 * Circumvent EmployeeCore->add() or save() which fail for unknown reasons
	 * Note the fake password that would never allows login
	 *
	 */
	public function setExpediproEmployee($email ='',$lang = 2  )
	{
		include_once(_PS_MODULE_DIR_.'expedipro/expediproFunctions.php');
		$profile = new ProfileCore();
		$allProfile = array_column_54($profile->getProfiles($lang), 'name', 'id_profile');
		//var_dump( $profile->getProfiles($this->context->language->id) );
//var_dump( $allProfile );
//die;
		//var_dump( array_search('logisticien',array_map('strtolower',$allProfile)) );
		//die;
		//var_dump( $employee->id_profile );
		if ( ! $logisticien = array_search('logisticien',array_map('strtolower',$allProfile)) )
			$logisticien = 2;

		$sql =  'INSERT INTO `'._DB_PREFIX_.'employee`
				(`lastname`,`firstname`,`id_profile`,`id_lang`,`email`,`passwd`,`active`)
				VALUES 	(
					"EXPEDIPRO",
					"",'.
					$logisticien .','.
					$lang .',"'.
					$email .'",
					"_____________________________",
					0)';

		Db::getInstance()->Execute($sql);
		return Db::getInstance()->Insert_ID();
	}


	/**
	 * Circumvent EmployeeCore->getByEmail() which required employee to be active
	 *
	 * @param string $email
	 *
	 * @param
	 */
	public  function isEmployeeExpediproExist($email ='')
	{
		$sql = 'SELECT `id_employee`
				FROM `'._DB_PREFIX_.'employee`
				WHERE `email` = "'. pSQL($email) .'"';

		if ( ! $result = Db::getInstance()->ExecuteS($sql) )
			return false;

		$result = array_pop( $result );
		return $result['id_employee'];
	}


	public function updateOrder($orderId = 0, $trackingNumber = null, $status = null)
	{
		if ( ! $orderId OR ! ( $trackingNumber OR $status ) ) return false;
		$sql = '';

		// better to rely on native methods, eventhough less efficient
		$order = new Order($orderId);
		if ( $trackingNumber )
		{
			$order->shipping_number = $trackingNumber;	// supposed to becomes deprecated in 1.6
			// Db::pSQL() or pSQL() ?
			$sql = 'UPDATE `'._DB_PREFIX_.'order_carrier`
					SET `tracking_number` = "'. pSQL( $trackingNumber ) .'"
					WHERE `id_order` = '. (int) $orderId;
		}

		if ( $status )
			$order->setCurrent_state( $this->statusMapping($status), /* EXPEDIPRO_EMPLOYEE */ null );
//			$order->current_state = $this->statusMapping($status);


		$order->update();

		if ( $sql )
			Db::getInstance()->Execute($sql);


		return true;
	}

    protected function quote($value)
    {
        if (is_int($value)) {
            return $value;
        } elseif (is_float($value)) {
            return sprintf('%F', $value);
        } elseif (is_array($value)) {
            foreach ($value as &$val) {
                $val = $this->quote($val);
            }
            return implode(', ', $value);
        }
        return "'" . addcslashes($value, "\000\n\r\\'\"\032") . "'";
    }


}
?>