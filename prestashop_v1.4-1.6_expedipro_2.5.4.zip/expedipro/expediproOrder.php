<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

/**
 * Called outside of Prestashop context
 *
 */

include_once dirname(__FILE__).'/expediproMapper.php';

class expediproOrder
{
	protected $outputFile;

	public function __construct() {	// required by $actionAdaptor =  new expediproOrder();
		$this->outputFile = dirname(__FILE__).'/export.csv';
	}


	/**
	 * Extract orders and output them to html
	 *
	 * @return boolean
	 */
	public function process( $data )
	{
		$this->getOrder( ( isset( $data['orderFrom'] )	? $data['orderFrom']: "2038-01-01" ),
						 ( isset( $data['orderTo'] )	? $data['orderTo']	: null ),
						 ( isset($data['debug']) ? (bool) $data['debug'] : false ) );
	}


	/**
	 * Extract orders and output them (to file AND to html)
	 *
	 * @param string	$from mysql date	inclusive start time interval
	 * @param string	$to					inclusive end time interval
	 * @param boolean	$debug				true just ignore previous parameters (debug purpose)
	 *
	 * @return false|void
	 */
	protected function getOrder($from = '', $to = '', $debug = false )
	{
		// avoid using string from client side without basic checks
		$from = ( Validate::isDate($from) ? $from : null);
		$to = ( Validate::isDate($to) ? $to : null);

		// extract orders from DB
//		global $cookie;
		$mapper = new ExpediproMapper();
		$orderlist = $mapper->getOrder(	explode('|', Configuration::get('EXPEDIPRO_ORDERSTATE') ),
										explode('|', Configuration::get('EXPEDIPRO_ORDERCARRIER') ),
										$from,
										$to,
										$debug );
//		if ( $debug )
//			var_dump($orderlist);

		if ( $orderlist === false ) {
			echo 'l\'extraction des commandes de votre base Prestashop semble impossible';	// means /classes/MySQLCore (extends Db) ->ExecuteS() return false
			return false;
		}
// new
		$definition = array( // keys are mapper key
				'client'		=> array('api' => 'client',		'asSuch' => true),
				'civilite'		=> array('api' => 'civilite',	'asSuch' => false),
				'prenom' 		=> array('api' => 'prenom',		'asSuch' => true),
				'nom' 			=> array('api' => 'nom', 		'asSuch' => true),
				'entreprise' 	=> array('api' => 'entreprise',	'asSuch' => true),
				'entrepriseNom'	=> array('api' => 'entrepriseNom','asSuch'=>true),
				'entrepriseTva'	=> array('api' => 'entrepriseTva','asSuch'=>true),
				'optin'			=> array('api' => 'optin',		'asSuch' => true),
				'adresse1'		=> array('api' => 'adresse1',	'asSuch' => true),
				'adresse2'		=> array('api' => 'adresse2',	'asSuch' => true),
				'adresse3'		=> array('api' => 'adresse3',	'asSuch' => true),
				'cp'			=> array('api' => 'cp',			'asSuch' => true),
				'ville'			=> array('api' => 'ville',		'asSuch' => true),
				'pays'			=> array('api' => 'pays',		'asSuch' => true),
				'instruction'	=> array('api' => 'instruction','asSuch' => true),
				'telephone'		=> array('api' => 'telephoneF',	'asSuch' => true),
				'mobile'		=> array('api' => 'telephoneM',	'asSuch' => true),
				'email'			=> array('api' => 'email',		'asSuch' => true),
				'boutique'		=> array('api' => 'boutique',	'asSuch' => false),
				'reference'		=> array('api' => 'reference',	'asSuch' => true),
				'dateStatus'	=> array('api' => 'iteration',	'asSuch' => true),
				'dateComm'		=> array('api' => 'date',		'asSuch' => true),
				'panierDesc'	=> array('api' => 'pDesc',		'asSuch' => false),	//group_concat	force encoding
				'panierQte'		=> array('api' => 'pQte',  		'asSuch' => true),	//group_concat
				'panierPoids'	=> array('api' => 'pPoids',		'asSuch' => true),	//group_concat
				'panierPrix'	=> array('api' => 'pVal',		'asSuch' => true),	//group_concat
				'longueur'		=> array('api' => 'long',		'asSuch' => true),
				'largeur'		=> array('api' => 'larg',		'asSuch' => true),
				'hauteur'		=> array('api' => 'haut',		'asSuch' => true),
				'state'			=> array('api' => 'processState','asSuch'=> true),
				'transporteur'	=> array('api' => 'transporteur','asSuch'=> true),
				'allotir'		=> array('api' => 'allotir',	'asSuch' => true),
		);

//		$file = fopen($this->outputFile, "w" );	// not required, but it might be useful one day

		$sep = Configuration::get('EXPEDIPRO_SEPARATOR');
//		$orderWeight = Configuration::get('EXPEDIPRO_ORDERWEIGHT') / 1000;	// products are in kg while orderWeight is in grammes

		$firstline = '';
		foreach ($definition as $mapper => $csv)
			$firstline .= $csv['api'] .	$sep;

		//$line = mb_convert_encoding( $firstline, 'UTF-8' );
		$firstline = substr_replace( $firstline, '', - 1 ); // remove last $sep

		echo $firstline . PHP_EOL;
//		fwrite($file, $firstline . PHP_EOL);

		if ($orderlist)
		{
			$boutiqueDefault = str_replace(' ', '', Configuration::get('PS_SHOP_NAME') );	// removing spaces help using this as an id


			foreach($orderlist AS $order)
			{
//print_r($order);
				if ( ! ( $order['prenom'] AND $order['nom'] ) )
					continue;	// empty commande but get a line with sql constants

				$order = str_replace($sep, "-", $order);// remove inner $sep
				$line = $csv = '';
				foreach ($definition as $mapper => $csv) {

//echo "name=>".$mapper. "<- value=>". ( null === $order[ $mapper ] ? 'null' : $order[ $mapper ])."<-".PHP_EOL;
					if ( !( isset($order[ $mapper ]) || array_key_exists($mapper, $order ) ) ) {
						$line .= '' .$sep;
						continue;
					}

					if ( $csv['asSuch'] ) {
						$line .= ( null === $order[ $mapper ] ? '' : $order[ $mapper ] ) .$sep;
//echo $line. PHP_EOL;
						continue;
					}

					$value = '';
					// any data transformation from the mapper must be handled here
					switch ( $mapper ) {
						case 'boutique' :
							$value = ( $order[ $mapper ] ? $order[ $mapper ] : $boutiqueDefault );
							break;
						case 'civilite' :
								if ( $order[ $mapper ] === '1' )
									$value = 'H';
								elseif ($order[ $mapper ] === '2' )
									$value = 'F';
								else
									$value = '';
								break;
						case 'panierQte' :
							$value = ( $value ? $value : 1 );
							break;
						case 'panierPoids' :
							$value = ( $value ? $value : 0.001 );
							break;
						case 'panierPrix' :
							$value = ( $value ? $value : 0.01 );
							break;
						case 'panierDesc' :
//echo '$order[ $mapper ]=>'.$order[ $mapper ]."<-".PHP_EOL;
							if ( ! mb_detect_encoding($order[ $mapper ], 'UTF-8', true ) ) // mb_detect_encoding('áéóú' /*ISO-8859-1*/ , 'UTF-8'); // 'UTF-8'
								$order[ $mapper ] =  mb_convert_encoding($order[ $mapper ], "UTF-8", mb_detect_encoding($order[ $mapper ]) );
//						case 'panierQte'  :
//						case 'panierPoids':	// unit weight
							// expected output is ["392.14","124.58"]
							//  json_encode( JSON_UNESCAPED_UNICODE ) require PHP > 5.4.0
//							$value = json_encode( explode('ǁ', $order[ $mapper ]),JSON_UNESCAPED_UNICODE );
							$value = $order[ $mapper ];	// keep group_concat string until no more PHP 5.3.* in the field
							break;
//						case 'panierPrix' : // unit price
//							$value = floatval($value) * ( intval( $order['panierQte'] ) ? intval( $order['panierQte'] ) : 1 );
//							break;
						default :
							$value = ''; // avoid misalignment with header
					}
					$line .= ( null === $value ? '' : $value ) .$sep;
//echo $line. PHP_EOL;
				}

				$line = preg_replace('/\r\n?/', " ", substr_replace( $line, '', - 1 ) );	// remove last $sep and avoid inner line break
				$line = str_replace('"', "'", $line );	// replace inner " and ; that might has impact for csv importation
				$line = str_replace(';', ',', $line );
				//$line = mb_convert_encoding( $line, 'UTF-8' );
				//$line = mb_convert_encoding( $line, 'iso-8859-15' );
				echo $line . PHP_EOL;
//				fwrite($file, $line . PHP_EOL);
			}
		}

//		fclose($file);
/*
		if ( ! $debug ) {	// let the config at it is during debug
			// prepare next export start date (exclude the end of the time interval)
			$pointInTime = new DateTime ( $to );
			$pointInTime->modify('+1 sec');
			Configuration::updateValue('EXPEDIPRO_ORDERFROM', $pointInTime->format('Y-m-d H:i:s') ); // prior to PHP 5.3, we can not chain modify and format
		}
*/
//		$this->redirect($this->outputUrl);
	}
}
?>