<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

/**
 * Called outside of Prestashop context
 *
 */

//$currentDir = dirname(__FILE__);

// beware : do not use

//require_once $currentDir.'/../../classes/Link.php';
// can not use Configuration because of ObjectModel
//include(dirname(__FILE__).'/../../classes/Configuration.php');
//require_once '';(dirname(__FILE__).'/../../classes/ObjectModel.php');

class Action
{
//	protected $currentDir;
//	protected $context; 	// instead of using Context:: which is 1.5+ specific, we rely on this context variable


	public function __construct()
	{
		$currentDir = dirname(__FILE__);
		$path 		= explode('/modules',$currentDir);

		include($path[0].'/config/settings.inc.php');

		include($path[0].'/config/config.inc.php');
		if (version_compare(_PS_VERSION_,'1.5','>')
			AND file_exists ($path[0].'/init.php') )
			include($path[0].'/init.php'); // @removed in 1.6 ?, required by 1.5 for sending email

//var_dump("ok");

		//error_reporting(0);
		ini_set('memory_limit', '512M');
		set_time_limit(60*5);

		// instanciate module just to get access to Tools::, Configuration:: etc.
//		include($this->currentDir.'/expedipro.php');
//		if ( ! $this->context = new Expedipro() ) {	// DI like
//			include_once(_PS_MODULE_DIR_.'expedipro/expediproFunctions.php');
//			$this->context = prestashop_initContext();
//		}
		// thanks to Expedipro(), we can now rely on prestashop constants and classes
//include_once(_PS_MODULE_DIR_.'expedipro/expediproFunctions.php');
//		 prestashop_initContext();

	}



	/**
	 * Transform the unsafe request in a safe container, then process the requested action
	 *
	 * @return boolean
	 */
	public function processRequest( )	/* called from the end of this file */
	{
/*
var_dump(Configuration::get('EXPEDIPRO_TOKEN'));
print_r("<br>");
var_dump(Tools::getValue('token'));
print_r("<br>");
var_dump(Tools::checkPhpVersion());
die;
*/
		// https://developer.mozilla.org/en-US/docs/Web/HTTP/Server-Side_Access_Control
		header('Content-Type: text/plain; charset=utf-8');
		header('Access-Control-Allow-Origin: *');
        $token = Configuration::get('EXPEDIPRO_TOKEN');

		if ( Tools::getIsset('tellMe') )
		{
//			if ( substr($_GET['tellMe'], 0, 5) !==  substr(Configuration::get('EXPEDIPRO_TOKEN'), 0, 5) ) {
			if ( $_GET['tellMe'] ===  hash('sha256', $token ) ) {
                error_reporting(1);
                $this->tellMe();
                die;
			}

            if(  Tools::getIsset('debug') )
                echo substr( hash('sha256', $token), 0, 2 ); // don't talk too much but help checking with url
            else
			    echo 'how? ';
			die;
		}
		elseif  ( ! Tools::getIsset('request') ) // Tools::getValue() filter while getIsset does not provide value :(
		{
			echo 'why?';
			die;
		}
//var_dump($this->validateContainer( $_GET['container'] ));
		// Can not rely on Tools::getValue() because it use urldecode(preg_replace
		// Can not rely on Tools::Isset()

//debug without encryption
/*
		include(_PS_MODULE_DIR_.'expedipro/expediproOrder.php');
		$actionAdaptor =  new expediproOrder();
		$actionAdaptor->process( array('orderFrom' => "2014-07-01 00:56:01") );
*/
		if ( ! $container = $this->validateContainer( ( isset($_POST['request']) ? $_POST['request']
																				 : $_GET['request'] ) ) )
		{
            if ( Tools::getIsset('debug') AND $_GET['debug'] ===  hash('sha256', $token ) )
                $this->containerDebug( ( isset($_POST['request']) ? $_POST['request']: $_GET['request'] ), $token );
            else
			    echo 'how?';
            // help debug but avoid that any false attempt talk too much
			die;
		}

		//
		// from now on, we can safely use $container['action'=>...,'data'=>...,'expire'=>... ]

//var_dump($this->validateContainer( $_GET['container'] ));
		switch ( $container['action'] ) {
			case 'setDeliveryStatus' :
				include(_PS_MODULE_DIR_.'expedipro/expediproDelivery.php');
				$actionAdaptor =  new expediproDelivery();
				break;
			case 'getOrder' :
				include(_PS_MODULE_DIR_.'expedipro/expediproOrder.php');
				$actionAdaptor =  new expediproOrder();
				break;
			default :
				echo 'what?';
				die;
		}

		set_time_limit( 15*60 );
		$actionAdaptor->process( $container['data'] );
	}


	/**
	 * Decrypt the container from request and check it comply with expected format
	 * Note : the array has been rawurlencode(   base64encode(mcrypt(json_encode()))	)
	 *
	 * @param string	encrypted array
	 *
	 * @return false|array
	 */
	protected function validateContainer ($container = null)
	{
		if ( ! $container )
			return false;

		if ( ! $assoc = $this->expediproDecrypt( $container , Configuration::get('EXPEDIPRO_TOKEN') ) )
			return false;
//var_dump( $assoc );

		// caller decides how long its encrypted request is valid (UTC timestamp)
		if ( ! isset($assoc['data']) OR $assoc['expire'] < time() )
        	return false;

		return $assoc;
	}


	/**
	 * Helps remote debuging
	 *
	 */
	protected function tellMe()
	{
		// instanciate the main module to be sure expedipro version is up to date
		include( dirname(__FILE__).'/expedipro.php');
		$main = new Expedipro();

		echo 'app=','ps,',	_PS_VERSION_ ,'|',
			 'expedipro=', 	Configuration::get('EXPEDIPRO_VERSION'),'|',
			 'orderState='	 , 	str_replace('|',',', Configuration::get('EXPEDIPRO_ORDERSTATE')),'|',
			 'orderCarrier='	 , 	str_replace('|',',',Configuration::get('EXPEDIPRO_ORDERCARRIER')),'|',
             'deliveryStart='	 , 	str_replace('|',',', Configuration::get('EXPEDIPRO_DELIVERYSTART')),'|',
             'deliveryDone='	 , 	str_replace('|',',', Configuration::get('EXPEDIPRO_DELIVERYDONE')),'|',
			 'separator=',  urlencode( Configuration::get('EXPEDIPRO_SEPARATOR') ),'|'; 	/* avoid == of base64 */
		try {
			$version = Db::getInstance()->ExecuteS('SELECT VERSION() AS "dbversion"');
			$version = array_pop($version);
			echo 'dbVersion='.$version['dbversion'].'|';
		} catch (Exception $e) {
			echo 'dbVersion=inconnue'.'|';
		}
		echo 'phpVersion='.	Tools::checkPhpVersion().'|';	// not always provided by phpInfoArray
        // validate mcrypt for later container decrypt
        $module = mcrypt_module_self_test(MCRYPT_RIJNDAEL_128);
        echo 'mcryptModule='.  ( $module ? 'ok' : 'error' ) .'|';
        if ( $module ) {
            $module = mcrypt_module_open ( MCRYPT_RIJNDAEL_128, "" , MCRYPT_MODE_CBC,""  );
            echo 'mcryptKey='.	print_r( mcrypt_enc_get_key_size( $module ),true ) .'|';
            echo 'mcryptIv='.	print_r( mcrypt_enc_get_iv_size( $module ),true ) .'|';
        }
		echo 'phpInfo='. print_r( str_replace( Configuration::get('EXPEDIPRO_SEPARATOR'),',',$this->phpInfoArray( ) ),true ) .'|';


		//PHP_EOL

		$currentDir = dirname(__FILE__);
		$path 		= explode('/modules',$currentDir);

		echo 'currentDir='. $currentDir.'|';
		echo 'currentScandir='. print_r( scandir( $currentDir ), true ).'|';
		echo 'configScandir='. $path[0].'/config   '.print_r( scandir( $path[0].'/config' ), true ).'|';
		echo 'included=' . print_r(get_included_files(),true);
/*
		echo 'infoConf=' . print_r(phpinfo(4),true).'|';
		echo 'infoMod=' . print_r(phpinfo(8),true).'|';
		echo 'infoEnv=' . print_r(phpinfo(16),true).'|';
		echo 'infoVar=' . print_r(phpinfo(32),true);
*/
	}

	protected function phpInfoArray( $level = null )
	{
		if ( $level === null )
			$level = 4|8|32;
		ob_start();
		phpinfo( $level );
		$info_arr = array();
		$info_lines = explode("\n", strip_tags(ob_get_clean(), "<tr><td><h2>"));
		$cat = "General";
		foreach($info_lines as $line)
		{
			// new cat?
			preg_match("~<h2>(.*)</h2>~", $line, $title) ? $cat = $title[1] : null;
			if( preg_match("~<tr><td[^>]+>([^<]*)</td><td[^>]+>([^<]*)</td></tr>~", $line, $val))
			{
				$info_arr[$cat][$val[1]] = trim($val[2]);
			}
			elseif(preg_match("~<tr><td[^>]+>([^<]*)</td><td[^>]+>([^<]*)</td><td[^>]+>([^<]*)</td></tr>~", $line, $val))
			{
				$info_arr[$cat][$val[1]] = array( "local" => trim($val[2]), "master" => trim($val[3]) );
			}
		}
		return $info_arr;
	}

	/**
	 * Decrypt a string encrypted with MCRYPT_RIJNDAEL_128
	 *
	 * @param string $encrypted       	that must be decrypted
	 * @param string $key				encryption key must be 32 for MCRYPT_RIJNDAEL_128
	 *
	 * @return false|string
	 */
	protected function expediproDecrypt($encrypted, $token = '')
	{
		/**
			not sure mcrypt_get_iv_size and mcrypt_decrypt is allowed by all providers
		 */
        $encrypted = rawurldecode( $encrypted );

		$key = hash( 'SHA256', $token . $token, true );	//done also on expedipro size, produce 32 binary
		$iv = base64_decode( Tools::substr( $encrypted, 0, 22 ) . '==' );
        if (strlen($iv) !== 16 )
            $iv = '\0\0\0\0\0\0\0==';

        $encrypted = Tools::substr( $encrypted, 22 );
		$decrypted = rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_128, $key, base64_decode( $encrypted ), MCRYPT_MODE_CBC, $iv ), "\0\4" );
		$hash = Tools::substr( $decrypted, - 32 );
		$decrypted = Tools::substr( $decrypted, 0, - 32 );
		// Integrity check. If this fails, either the data is corrupted, or the password/salt was incorrect.

        // prior PHP 5.3 rawurlencode was based on RFC1738 a-while after (expedipro side) it use RFC3986
        if ( version_compare(PHP_VERSION, '5.3.4', '>') AND md5( $decrypted ) !== $hash )  // bypass md5 check prior to 5.3.4, explore string json
            return false;

        // basic checks of right decrypt and consistency : means caller knows token + method + structure
        if ( false === stristr( $decrypted, '{"action":' ) OR false === stristr( $decrypted, '"expire":' ) )
            return false;

        return Tools::jsonDecode( $decrypted, true );	// associative array
	}


    protected function containerDebug($encrypted = null, $key = '')
    {
        if ( ! $encrypted) {
            echo "empty container";
            return false;
        }
        /*
          SDZy8%2BLrWCH7Y4q%2FvZ0%2BpgXGySD3sgj7iwP0TKF2T3YZaZdTQbZ1fZG%2B6Sytzg19ey0KNpOGvJQ%2BYAMKMasvhCjnGJTFchB4IP5Jhi0qnNrU0D87gqWekA3Zuje5XEUZKPbHhobzWyGTG%2BNoW5V%2FU5xtq%2BX4RQGGB0trLlyuF8sjrv3ECYqqd4FM8ZnrfTg9w%3D"
        */

        $encrypted = rawurldecode($encrypted);
        $key = hash( 'SHA256', $key . $key, true );
        $iv = base64_decode( Tools::substr( $encrypted, 0, 22 ) . '==' );

        if (strlen($iv) !== 16 ) {
            $iv = '\0\0\0\0\0\0\0==';
            print_r("iv, \0 filled:");
        } else
            print_r("iv:");

var_dump( $iv);
        $encrypted = Tools::substr( $encrypted, 22 );
        $decrypted = rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_128, $key, base64_decode( $encrypted ), MCRYPT_MODE_CBC, $iv ), "\0\4" );

print_r("decrypted:");var_dump( $decrypted);
print_r("md5 expedipro:");var_dump( Tools::substr( $decrypted, - 32 ) );
print_r("md5 prestashop:");var_dump( md5( $decrypted ) );
        return false;
    }
}

$action = new Action();
$action->processRequest();

?>