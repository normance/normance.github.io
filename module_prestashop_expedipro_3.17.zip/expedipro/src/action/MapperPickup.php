<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014-2019 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

namespace Expedipro\Module\Action;


class MapperPickup
{

    /**
     * Get pickup (Colissimo, Dpd, Chronopost, Mondial Relay) info for all carts
     *
     * @param array $cartIds to look for
     * @param array $orderIds to look for (for Boxtal module)
     *
     * @return array from getSiteLivraison()
     */
    public function getPickupServiceId( array $cartIds = [], array $orderIds = [] ) :array
    {
        $cartInList  = ' ("' . implode('","', $cartIds) . '")';
        $orderInList = ' ("' . implode('","', $orderIds) . '")';

        $allPickup = [];
        // array_merge() reindex numerics keys, + keep them. Note: in case of duplicate array_merge keeps last value, + the first one
        $allPickup += $this->getMondialRelaySiteLivraison( $cartInList, $orderInList );
        $allPickup += $this->getDpdSiteLivraison( $cartInList );
        $allPickup += $this->getColissimoSiteLivraison( $cartInList );
        $allPickup += $this->getChronopostSiteLivraison( $cartInList );

        return $allPickup;
    }


    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array from getSiteLivraison()
     */
    private function getColissimoSiteLivraison( string $cartInList= "" ) :array
    {
        if ( ! $this->getModuleVersion('colissimo%') )  // colissimo
            return [];

        // 2021-03: So Colissimo module from la Poste evolve: id_colissimo_pickup_point is now just un sql id, use colissimo_id to get the pickup id
        return $this->getSiteLivraison(
            'SELECT CPP.`id_cart` AS "cartId", PP.`product_code` AS "type", IF( LENGTH( PP.`id_colissimo_pickup_point`) > 5, PP.`id_colissimo_pickup_point`, PP.`colissimo_id` ) AS "id"
                FROM  `' . _DB_PREFIX_ . 'colissimo_cart_pickup_point` AS CPP
                LEFT JOIN `' . _DB_PREFIX_ . 'colissimo_pickup_point` AS PP ON PP.id_colissimo_pickup_point = CPP.id_colissimo_pickup_point
                WHERE CPP.`id_cart` IN ' . $cartInList );
    }

    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array from getSiteLivraison()
     */
    private function getDpdSiteLivraison( string $cartInList= "" ) :array
    {
        if ( ! $this->getModuleVersion('dpd%') ) // dpdfrance
            return [];

        return $this->getSiteLivraison(
            'SELECT `id_cart` AS "cartId", `relay_id` AS "id", `service` AS "type"
            FROM  `' . _DB_PREFIX_ . 'dpdfrance_shipping`
            WHERE `id_cart` IN ' . $cartInList );
    }

    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array from getSiteLivraison()
     */
    private function getChronopostSiteLivraison( string $cartInList = "" ) :array
    {
        if ( ! $this->getModuleVersion('chronopost%') ) // chronopost
            return [];

        return $this->getSiteLivraison(
            'SELECT `id_cart` AS "cartId",`id_pr` AS "id", null AS "type"
            FROM  `' . _DB_PREFIX_ . 'chrono_cart_relais`
            WHERE `id_cart` IN ' . $cartInList );
    }


    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     * @param string $orderInList
     *
     * @return array from getSiteLivraison()
     */
    private function getMondialRelaySiteLivraison( string $cartInList = "", string $orderInList ="" ) : array
    {
        // if Boxtal is active, ignore Mondial Relay
        if ( $this->getModuleVersion('boxtal%' ) ) // 1.2.*
        {   // from https://github.com/PrestaShopCorp/envoimoinscher/blob/master/envoimoinscher.php
            $sql = 'SELECT `orders_id_order` AS "orderId", `point_ep` AS "id", `emc_operators_code_eo` AS "type"
                    FROM `' . _DB_PREFIX_ . 'emc_points` 
                    WHERE `orders_id_order` IN ' . $orderInList;
        }
        elseif( $version = $this->getModuleVersion('mondial%' ) )
        {
            if( version_compare($version, '3.0', '<') ) {
                $sql = 'SELECT S.`id_cart` AS "cartId", S.`MR_Selected_Num` AS "id", S.`MR_insurance` AS "ass", M.`dlv_mode` AS "type"
                    FROM `' . _DB_PREFIX_ . 'mr_selected` AS S
                    JOIN `' . _DB_PREFIX_ . 'mr_method` AS M  ON M.`id_mr_method` = S.`id_method` 
    
                     WHERE M.`is_deleted` = 0
                       AND S.`id_cart` IN ' . $cartInList;
            } else {
                $sql = 'SELECT S.`id_cart` AS "cartId", S.`selected_relay_num` AS "id", S.`insurance_level` AS "ass", M.`delivery_mode` AS "type"
                    FROM `' . _DB_PREFIX_ . 'mondialrelay_selected_relay` AS S
                    JOIN `' . _DB_PREFIX_ . 'mondialrelay_carrier_method` AS M ON M.`id_mondialrelay_carrier_method` = S.`id_mondialrelay_carrier_method` 
    
                     WHERE M.`is_deleted` = 0
                       AND S.`id_cart` IN ' . $cartInList;
            }
        }
        else
            return [];

        return $this->getSiteLivraison( $sql );
    }

    /**
     *
     * @param string $sqlLike LIKE parameter, including %
     * @return false|mixed
     */
    private function getModuleVersion( string $sqlLike ="" ) {
        try {
            if (!$result = \Db::getInstance()->ExecuteS( 'SELECT name, active, version FROM `'._DB_PREFIX_.'module` WHERE name LIKE "'.$sqlLike.'" ' ))
                return false;
        } catch ( Exception $e ) {
            return false;
        }

        if ( ! isset( $result[0] ) OR ! (int) $result[0]['active'] )
            return false;

        return $result[0]['version'];
    }


    /**
     *
     * Important, $sql must provides SELECT cartId, id, type
     *
     * @param string $sql
     *
     * @return array ['cartId'|'orderId' => [ <cartId|orderId> => ['id' => <id_pickup>, 'type' => ... ] ] ]
     */
    private function getSiteLivraison( string $sql ) : array
    {
        $cartSite = [];
        try {
            if (!$result = \Db::getInstance()->ExecuteS($sql))
                return $cartSite;
        } catch (\Exception $e) {
            return $cartSite;
        }

        foreach ($result as $one) {
//            $cartSite[ $one['cartId'] ] = ['id' => $one['id'], 'type' => $one['type']];
            if ( isset( $one['cartId'] ) )
                $cartSite['cartId'][ $one['cartId'] ] = ['id' => $one['id'], 'type' => $one['type'] ];
            else
                $cartSite['orderId'][ $one['orderId']]= ['id' => $one['id'], 'type' => $one['type'] ];
        }

        return $cartSite;
    }

}
?>