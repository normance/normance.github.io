<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

/**
 * Called outside Prestashop context
 *
 */
require_once( dirname(__FILE__) . '../../../config/config.inc.php');

// load PSR-4 namespaces
require_once( dirname(__FILE__) . '/vendor/autoload.php');
use Expedipro\Module\Action,
    Emarref\Jwt,
    Emarref\Jwt\Verification,
    Emarref\Jwt\Algorithm\Hs256,
//    Emarref\Jwt\Algorithm\None,
    Emarref\Jwt\Encryption;


class controller
{
	public function __construct() {
        //error_reporting(0);
	}



	/**
	 * Transform the unsafe request in a safe container, then process the requested action
	 *
	 */
	public function processRequest( )	/* called from the end of this file */
	{
// Authorization : Bearer cn389ncoiwuencr

		// https://developer.mozilla.org/en-US/docs/Web/HTTP/Server-Side_Access_Control
		header('Content-Type: application/json; charset=utf-8');
		header('Access-Control-Allow-Origin: *');
        $secret = Configuration::get('EXPEDIPRO_TOKEN');

		if ( Tools::getIsset('tellMe') )
		{
//			if ( substr($_GET['tellMe'], 0, 5) !==  substr(Configuration::get('EXPEDIPRO_TOKEN'), 0, 5) ) {
			if ( $_GET['tellMe'] ===  hash('sha256', $secret ) ) {
                error_reporting(1);
                echo json_encode( $this->tellMe(), JSON_PARTIAL_OUTPUT_ON_ERROR |  JSON_UNESCAPED_SLASHES | JSON_NUMERIC_CHECK);
                die;
			}
            else
                $this->stopHere( 400 );
		}
		// Can not rely on Tools::getValue() because it use urldecode(preg_replace
		// Can not rely on Tools::Isset
        // Note: jwt is three Base64-URL strings separated by dots
        $container = $this->validateToken( $_POST['jwt'] ?? ( $_GET['jwt'] ?? '' ), $secret );
		if ( isset( $container['error'] ) )
            $this->stopHere( 401, $container['error']);

		// from now on, we can safely use $container['action'=>...,'data'=>...,'expire'=>... ]
		switch ( $container['action'] ?? null ) {
			case 'setDelivery' :
				$actionAdaptor =  new Action\Delivery();
				break;
			case 'getOrder' :
				$actionAdaptor =  new Action\Order();
				break;
			default :
                $this->stopHere( 404 );
		}

        ini_set('memory_limit', '512M');
		set_time_limit( 15*60 );

        $data = $_POST['data'] ?? ( $_GET['data'] ?? null );
        if ( ! $data = json_decode( base64_decode( $data ), true, 20, JSON_PARTIAL_OUTPUT_ON_ERROR |  JSON_UNESCAPED_SLASHES ) )
            $this->stopHere(417, $_POST['data'] ?? ( $_GET['data'] ?? null ));

		$actionAdaptor->process( $data );
	}


	/**
	 * Decrypt the JWTsigned from request and check it comply with expected format
	 * Note : the array has been rawurlencode(   base64encode(mcrypt(json_encode()))	)
	 *
	 * @param string	$serializedJwt from unsafe source
     * @param string    $secret
	 *
	 * @return array
	 */
	protected function validateToken (string $serializedJwt, string $secret) :array
    {
/*
        $json = '{"exp":1581205852,"iat":1580202252,"iss":"expedipro","action":"setDelivery","data":{"product":{"LFE":"Colissimo Expert Fr","LFA":"Colissimo Access Fr","LOE":"Colissimo Expert OM"},"carrier":[],"distribution":{"PCHCFM":"Votre colis est pris en charge par l\'op\u00e9rateur. Il est en cours d\'acheminement"},"delivery":[{"order":"35086","track":"9V31179785344","product":"LFE","insurance":0,"cost":14.66,"costWt":0,"weight":8,"step":20,"stepLib":"PCHCFM"}]}}';
        var_dump ( hash_hmac("sha256", $json, "y2v4x252AKCYxIiWnkSHNX-JuqrmfWeW",true ) );
        die;
*/
        try {
            $jwt = new Jwt\Jwt();
            $token = $jwt->deserialize($serializedJwt);
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }

        $context =
            ( new Verification\Context(
                Encryption\Factory::create(
                    // new None()
                    // security: ne pas extraire l'algorithme du payload. Imposer l'algorithme côté serveur
                    new Hs256( $secret ) // symmetric encryption
                )
                )
            )->setIssuer('expedipro');
                // null !== "aud" means verification must be set to avoid rejection
//                ->setAudience(['getOrder','setDelivery']);

        try {
            // Important: verify parse ALL PROVIDED payload (even if no set<Claim> defined) and thus reject any (optional) not null value :(
            $jwt->verify($token, $context); // ExpirationVerifier() is always done
        } catch ( Exception $e) {
            return ['error' => $e->getMessage()];
        }

        return $this->getClaimsArray( $token );
	}


    protected function getClaimsArray( Jwt\Token $token ) :array
    {
        $claims = $token->getPayload()->getClaims();
        $array = [];

        foreach ($claims as $property) {
            if ( ! $name = $property->getName() )
                continue;
            $array[ $name ] = $property->getValue();
        }

        // note: "aud" can not be used since it must be a not null constant string
        return ( isset( $array['action'] ) ? $array : [] );
    }


    private function stopHere( int $httpCode, string $reason = null ) {
        http_response_code($httpCode);
        if ($reason)
            echo $reason;
        die;
    }

	/**
	 * Helps remote debuging
	 *
	 */
	protected function tellMe() :array
	{
		// instantiate the main module to be sure expedipro version is up to date
//		include( dirname(__FILE__).'/expedipro.php');
//		$main = new Expedipro();
        $currentDir = dirname(__FILE__);
//        $path 		= explode('/modules',$currentDir);


        require_once( dirname(__FILE__) . '/Config.php');
        $config = new Config();

        try {
			$version = Db::getInstance()->ExecuteS('SELECT VERSION() AS "dbversion"');
			$version = array_pop($version);
		} catch ( \Exception $e) {
            $version = 'Exception when getting it from db';
        }

		$audit = [
		    'app'=>[
		        'name' => 'prestashop',
                'version'=> _PS_VERSION_,
                'modules'=> $config->getModulesVersionInstalled(),
                'dbPrefix'=> _DB_PREFIX_
//              'config' => [
//                  'path'  => $path[0].'/config',
//                  'files' => scandir( $path[0].'/config' )
//                ]
            ],
		    'module'=>[
		        'version'       => round(Configuration::get('EXPEDIPRO_VERSION'),2, PHP_ROUND_HALF_DOWN),
                'orderCarrier'	=> Configuration::get('EXPEDIPRO_ORDERCARRIER'),
                'orderState'	=> Configuration::get('EXPEDIPRO_ORDERSTATE'),
                'deliveryBefore'=> Configuration::get('EXPEDIPRO_DELIVERYBEFORE'),
                'deliveryStart' => Configuration::get('EXPEDIPRO_DELIVERYSTART'),
                'deliveryDone'  => Configuration::get('EXPEDIPRO_DELIVERYDONE'),
                'deliveryMessage'=>Configuration::get('EXPEDIPRO_DELIVERYMESSAGE'),
                'deliveryCost'  => Configuration::get('EXPEDIPRO_DELIVERYCOST'),
                'carrierList'   => $config->filterCarrierList(),
                'stateList'     => $config->filterStateList(),
                'url'           => _PS_BASE_URL_SSL_. __PS_BASE_URI__. 'modules/expedipro/controller.php',
                'path'          => $currentDir,
                'hook'          => $config->diagnoseHook(),
                'files'         => scandir( $currentDir ),
                'vendor'        => [
                    'jwt'       => is_dir( $currentDir.'/vendor/emarref/jwt/src' ),
//                    'nanoid'    => is_dir( $currentDir.'/vendor/hidehalo/nanoid-php/src' ),
                    ]
                ],
            'system' => [
                'time'  => date("c").' '. date_default_timezone_get(),
                'db'    => $version['dbversion'] ?? null,
                'php'   => Tools::checkPhpVersion(),
                'php-ext' => get_loaded_extensions(), // shows json, pdo*
                'include' => array_filter( get_included_files(),
                    function($value){
                        return strpos($value,'expedipro'); // works because no path start by expedipro (pos 0)

                    }
                ),
                'error_log_path' => ini_get('error_log'), // often empty in shared env
                'error_log_size' => 0,
                'error_log' => null    // means no access (or to big) to error_log
            ]
        ];

        if ( $audit['system']['error_log_path'] )  // absolute path + exact filename
        {
            $audit['system']['error_log'] = [];
            $reader = new ErrorLog( $audit['system']['error_log_path'] );

            $audit['system']['error_log_size'] = $reader->getSizeLogFile();

            if ( $reader->isLogCanBeParsed() ) {
                foreach ($reader->getParsedLogFile() ?? [] as $one)
                    $audit['system']['error_log'] += $one; // extract lines related to Expedipro from the error_log
            }
        }
        else
            $audit['system']['error_log'] = error_get_last(); // better something than nothing

		return $audit;
	}
}

class ErrorLog
{
    /**
     * ErrorLog constructor.
     *
     * @param string $logFilePath
     */
    public function __construct(string $logFilePath) {
        $this->logFilePath = $logFilePath;
    }


    public function isLogCanBeParsed() {
        if ( ! file_exists( $this->logFilePath ) OR ! $bytes = filesize( $this->logFilePath ) )
            return false;
        return ( $bytes > 15*1024*1024 ); // 15 MB
    }


    public function getSizeLogFile() {
        if ( ! file_exists( $this->logFilePath ) OR ! $bytes = filesize( $this->logFilePath ) )
            return 0;

        $sz = 'BKMGTP';
        $factor = floor((strlen($bytes) - 1) / 3);
        return sprintf("%.2f", $bytes / pow(1024, $factor)) . @$sz[$factor];
    }

    /**
     * Parses the PHP error log to an array.
     *
     * @return \Generator
     */
    public function getParsedLogFile() : \Generator
    {
        $now = new DateTime();
        $parsedLogs = [];
        $logFileHandle = fopen($this->logFilePath, 'rb');

        while (!feof($logFileHandle)) {
            $currentLine = str_replace(PHP_EOL, '', fgets($logFileHandle));
            // filter only empty $parsedLog to capture related stacktrace without 'expedipro'
            if ( ! $parsedLogs AND ! stripos( $currentLine, 'expedipro') )
                continue;

            // Normal error log line starts with the date & time in []
            if ('[' === $currentLine[0]) {
                if (10000 === \count($parsedLogs)) {
                    yield $parsedLogs;
                    $parsedLogs = [];
                }

                // Get the datetime when the error occurred and convert it to berlin timezone
                try {
                    $dateArr = [];
                    preg_match('~^\[(.*?)\]~', $currentLine, $dateArr);
                    $currentLine = str_replace($dateArr[0], '', $currentLine);
                    $currentLine = trim($currentLine);
                    $errorDateTime = new DateTime($dateArr[1]);
                    if ( $ago = $now->diff($errorDateTime) ) {
                        // only focus on the last 5 days
                       if ( $ago->format('%a') > 5 ) // diff are always in the past compare to now, %R would always be '-'
                            continue;
                    }
                    $errorDateTime->setTimezone(new DateTimeZone('Europe/Berlin'));
                    $errorDateTime = $errorDateTime->format('Y-m-d H:i:s');
                } catch (\Exception $e) {
                    $errorDateTime = '';
                }

                // Get the type of the error
                if (false !== strpos($currentLine, 'PHP Warning')) {
                    $currentLine = str_replace('PHP Warning:', '', $currentLine);
                    $currentLine = trim($currentLine);
                    $errorType = 'WARNING';
                } else if (false !== strpos($currentLine, 'PHP Notice')) {
                    $currentLine = str_replace('PHP Notice:', '', $currentLine);
                    $currentLine = trim($currentLine);
                    $errorType = 'NOTICE';
                } else if (false !== strpos($currentLine, 'PHP Fatal error')) {
                    $currentLine = str_replace('PHP Fatal error:', '', $currentLine);
                    $currentLine = trim($currentLine);
                    $errorType = 'FATAL';
                } else if (false !== strpos($currentLine, 'PHP Parse error')) {
                    $currentLine = str_replace('PHP Parse error:', '', $currentLine);
                    $currentLine = trim($currentLine);
                    $errorType = 'SYNTAX';
                } else if (false !== strpos($currentLine, 'PHP Exception')) {
                    $currentLine = str_replace('PHP Exception:', '', $currentLine);
                    $currentLine = trim($currentLine);
                    $errorType = 'EXCEPTION';
                } else {
                    $errorType = 'UNKNOWN';
                }

                if (false !== strpos($currentLine, ' on line ')) {
                    $errorLine = explode(' on line ', $currentLine);
                    $errorLine = trim($errorLine[1]);
                    $currentLine = str_replace(' on line ' . $errorLine, '', $currentLine);
                } else {
                    $errorLine = substr($currentLine, strrpos($currentLine, ':') + 1);
                    $currentLine = str_replace(':' . $errorLine, '', $currentLine);
                }

                $errorFile = explode(' in /', $currentLine);
                $errorFile = '/' . trim($errorFile[1]);
                $currentLine = str_replace(' in ' . $errorFile, '', $currentLine);

                // The message of the error
                $errorMessage = trim($currentLine);

                $parsedLogs[] = [
                    'dateTime' => $errorDateTime,
                    'type' => $errorType,
                    'file' => $errorFile,
                    'line' => (int)$errorLine,
                    'message' => $errorMessage,
                    'stackTrace' => []
                ];
            } // Stack trace beginning line
            else if ('Stack trace:' === $currentLine) {
                $stackTraceLineNumber = 0;

                while (!feof($logFileHandle)) {
                    $currentLine = str_replace(PHP_EOL, '', fgets($logFileHandle));

                    // If the current line is a stack trace line
                    if ('#' === $currentLine[0]) {
                        $parsedLogsLastKey = key($parsedLogs);
                        $currentLine = str_replace('#' . $stackTraceLineNumber, '', $currentLine);
                        $parsedLogs[$parsedLogsLastKey]['stackTrace'][] = trim($currentLine);

                        $stackTraceLineNumber++;
                    } // If the current line is the last stack trace ('thrown in...')
                    else {
                        break;
                    }
                }
            }
        }

        yield $parsedLogs;
    }

}





( new controller() )->processRequest();

?>