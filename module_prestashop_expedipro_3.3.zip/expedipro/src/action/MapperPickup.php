<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014-2019 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

namespace Expedipro\Module\Action;


class MapperPickup
{
    /**
     * Get pickup (Colissimo, Dpd, Chronopost, Mondial Relay) info for all carts in once
     *
     * @param array $cartIds
     *
     * @return array
     */
    public function getPickupServiceId(array $cartIds ) :array
    {
        $cartInList = ' ("' . implode ( '","', $cartIds ) . '")';
        $allPickup =[];
        if ( $this->isColissimoInstalled() )
            $allPickup = $this->getColissimoSiteLivraison( $cartInList );
        // array_merge() reindex numerics keys, + keep them. Note: in case of duplicate array_merge keeps last value, + the first one
        if ( $this->isDpdInstalled() )
            $allPickup += $this->getDpdSiteLivraison( $cartInList );
        if ( $this->isChronoInstalled() )
            $allPickup += $this->getChronoSiteLivraison( $cartInList );
        if ( $this->isMRInstalled() )
            $allPickup += $this->getMRSiteLivraison( $cartInList );

        return $allPickup;
    }


    private function isColissimoInstalled() :bool
    {
        $sql = 'SELECT COUNT(*) AS "exist"
                FROM information_schema.TABLES
                WHERE TABLE_NAME = "'._DB_PREFIX_.'colissimo_cart_pickup_point"';

        if ( ! $result = \Db::getInstance()->ExecuteS( $sql ) )
            return false;

        return (bool) ( $result[0]['exist'] ?? null);
    }

    private function isDpdInstalled() :bool
    {
        $sql = 'SELECT COUNT(*) AS "exist"
                FROM information_schema.TABLES
                WHERE TABLE_NAME = "'._DB_PREFIX_.'dpdfrance_shipping"';

        if ( ! $result = \Db::getInstance()->ExecuteS( $sql ) )
            return false;

        return (bool) ( $result[0]['exist'] ?? null);
    }

    private function isChronoInstalled() :bool
    {
        $sql = 'SELECT COUNT(*) AS "exist"
                FROM information_schema.TABLES
                WHERE TABLE_NAME = "'._DB_PREFIX_.'chrono_cart_relais"';

        if ( ! $result = \Db::getInstance()->ExecuteS( $sql ) )
            return false;

        return (bool) ( $result[0]['exist'] ?? null);
    }

    private function isMRInstalled() :bool
    {
        $sql = 'SELECT COUNT(*) AS "exist"
                FROM information_schema.TABLES
                WHERE TABLE_NAME = "'._DB_PREFIX_.'mondialrelay_selected_relay"';

        if ( ! $result = \Db::getInstance()->ExecuteS( $sql ) )
            return false;

        return (bool) ( $result[0]['exist'] ?? null);
    }


    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getColissimoSiteLivraison( string $cartInList ) :array
    {
        $cartSite = [];
        $sql = 'SELECT CPP.`id_cart`, CPP.`id_colissimo_pickup_point`, PP.`product_code`
                FROM  `'._DB_PREFIX_.'colissimo_cart_pickup_point` AS CPP
                LEFT JOIN `'._DB_PREFIX_.'colissimo_pickup_point` AS PP ON PP.id_colissimo_pickup_point = CPP.id_colissimo_pickup_point
                WHERE CPP.`id_cart` IN '. $cartInList;
        try {
            if ( ! $result = \Db::getInstance()->ExecuteS( $sql ) )
                return $cartSite;
        } catch( \Exception $e) {
            return $cartSite;
        }
        foreach ( $result as $one )
            $cartSite[ $one['id_cart'] ] = ['id' => $one['id_colissimo_pickup_point'], 'type' => $one['product_code'] ];

        return $cartSite;
    }

    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getDpdSiteLivraison( string $cartInList ) :array
    {
        $cartSite = [];
        $sql = 'SELECT `id_cart`,`relay_id`
                FROM  `'._DB_PREFIX_.'dpdfrance_shipping`
                WHERE `id_cart` IN '. $cartInList;
        try{
            if ( ! $result = \Db::getInstance()->ExecuteS( $sql ) )
                return $cartSite;
        } catch( \Exception $e) {
            return $cartSite;
        }
        foreach ( $result as $one )
            $cartSite[ $one['id_cart'] ] = $one['relay_id'];

        return $cartSite;
    }

    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getChronoSiteLivraison( string $cartInList ) :array
    {
        $cartSite = [];
        $sql = 'SELECT `id_cart`,`id_pr`
                FROM  `'._DB_PREFIX_.'chrono_cart_relais`
                WHERE `id_cart` IN '. $cartInList;
        try{
            if ( ! $result = \Db::getInstance()->ExecuteS( $sql ) )
                return $cartSite;
        } catch( \Exception $e) {
            return $cartSite;
        }
        foreach ( $result as $one )
            $cartSite[ $one['id_cart'] ] = $one['id_pr'];

        return $cartSite;
    }


    /**
     * Search for pickup id for cart id
     * Not TESTED
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getMRSiteLivraison( string $cartInList ) :array
    {
        $cartSite = [];
        $sql = 'SELECT mr_sr.`selected_relay_num`, mr_sr.`insurance_level`, mr_cm.`delivery_mode`
                FROM `'._DB_PREFIX_.'mondialrelay_selected_relay` AS mr_sr
                JOIN `'._DB_PREFIX_.'mondialrelay_carrier_method` AS mr_cm ON mr_cm.`id_mondialrelay_carrier_method` = mr_sr.`id_mondialrelay_carrier_method` 

                 WHERE mr_cm.`is_deleted` = 0
                   AND mr_sr.`id_cart` IN '. $cartInList;
        try{
            if ( ! $result = \Db::getInstance()->ExecuteS( $sql ) )
                return $cartSite;
        } catch( \Exception $e) {
            return $cartSite;
        }
        foreach ( $result as $one )
            $cartSite[ $one['id_cart'] ] = ['id'=> $one['selected_relay_num'], 'type' => $one['delivery_mode'] ];

        return $cartSite;
    }

}
?>