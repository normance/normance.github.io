<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014-2019 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

namespace Expedipro\Module\Action;

// use Prestashop\Module\Expedipro\Mapper;

class Order
{
	protected $outputFile;

	public function __construct() {	// required by $actionAdaptor =  new expediproOrder();
		$this->outputFile = dirname(__FILE__).'/export.csv';
	}


	/**
	 * Extract orders and output them to html
	 *
     * @param array $data
     *
	 * @return array
	 */
	public function process( array $data ) :array
	{
		// avoid using string from client side without basic checks
		return $this->getOrder(
            ( \Validate::isDate( $data['from'] ?? null ) ? $data['from'] : "2019-10-12" ),
            ( \Validate::isDate( $data['to'] ?? null ) ? $data['to'] : null ),
			(bool) ( $data['debug'] ?? false )
        );
	}


	/**
	 * Extract orders and output them (to file AND to html)
	 *
	 * @param string	$from mysql date	inclusive start time interval
	 * @param string	$to					inclusive end time interval
	 * @param boolean	$debug				true just ignore previous parameters (debug purpose)
	 *
	 * @return array
	 */
	protected function getOrder( string $from, string $to = null, bool $debug = false ) :array
	{
		// extract orders from DB
        try {
		    $orders = ( new Mapper() )
                            ->getOrder(
		                        explode('|', \Configuration::get('EXPEDIPRO_ORDERSTATE') ),
                                explode('|', \Configuration::get('EXPEDIPRO_ORDERCARRIER') ),
                                $from,
                                $to,
                                $debug );

        } catch ( \Exception $e ) {
            // means /classes/MySQLCore (extends Db) ->ExecuteS() return false
            echo 'l\'extraction des commandes de votre base Prestashop est impossible : ' . $e->getMessage() ;
			return [];
        }

//		$file = fopen($this->outputFile, "w" );	// not required, but it might be useful one day
        echo json_encode( $orders, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR ); // . PHP_EOL;
        return $orders; // unused returned array
//		fwrite($file, $line . PHP_EOL);
//		fclose($file);
	}
}
?>