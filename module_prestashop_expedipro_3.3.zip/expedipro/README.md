# prestashop
Prestashop module

This module enable exchanges between Expedipro.com and Prestashop as of 1.6.
Requirement : PHP 7+ core features and *composer* for Java Web Token lib.

This module act like a web service using JWT and json standards.
Methods available are:
- tellMe
- getOrder
- setDelivery


### How to develop
 cd ~/webdev/code/module/prestashop/expedipro
 
 git clone https://github.com/normance/prestashop.git
 
 **do the modifications**

 update code/module/prestashop/expedipro/*package.json* with the new module version
 
 **when ready to commit**
 
 cd ~/webdev/code/module/prestashop/deployment
 
 ./publish.sh

 > This create .tar and .tgz in ~/webdev/code/module/prestashop/dist

 > IMPORTANT: .tgz generated in docker devilbox image can not be renamed in .zip : it failed when installing on Prestashop. 
 > IMPORTANT: uncompress .tar on Mac then compress the expedipro dir created into .zip 
 
 > Upload .zip on dropbox/modules/Prestashop XX

 > Note: for major version, create a new dropbox/modules/Prestashop XX directory and share it
 > Then update https://medium.com/@expedipro/relier-expedipro-à-votre-cms-e-commerce-bebf6fff9e52 story with new link   


