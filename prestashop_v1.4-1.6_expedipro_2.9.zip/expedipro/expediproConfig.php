<?php
/**
* 2014 Expedipro
*
*  @author Expedipro SAS <contact@expedipro.com>
*  @copyright  2014 Expedipro SAS
*  International Registered Trademark & Property of Expedipro SAS
*/

class ExpediproConfig  extends Module
{
	protected	$context; 	// instead of using Context:: which is 1.5+ specific, we rely on this context variable
	protected	$carrierList = array();	// avoid several db access
    protected   $carrierDbName;         // since db change given version
    protected	$stateList = array();	// avoid several db access

	// DI of context
	public function __construct( $context = null)
	{
		if ( $context ) {
			$this->context = $context;
		} else {
			include_once(_PS_MODULE_DIR_.'expedipro/expediproFunctions.php');
			$this->context = prestashop_initContext();
		}
        include_once dirname(__FILE__).'/expediproMapper.php'; // for  diagnoseOrder()
	}



	/**
	 * Handle the validation of config <form>
	 *
	 * @return	string	error messages
	 */
	public function configPost()
	{
		$output = ''; // local avoid confusion with caller $this->_output
		/**
		 *Do not named submit button "configure" otherwise submit would trigger "module not found"
		 */

		// POST processing using submit name
		if( Tools::isSubmit('submitConfigUrl') ) {
			Configuration::updateValue('EXPEDIPRO_TOKEN', expedipro_randomString(32) );
		}


		if ( Tools::isSubmit('submitConfigCarrier') )
		{
/*
			if( $orderWeight = Tools::getValue('orderWeight') )	// in grammes
			{
//				$orderWeight = (float) str_replace ( ',', '.', $orderWeight );	// Allows decimal separator comma or dot
//				Configuration::updateValue('EXPEDIPRO_ORDERWEIGHT', ( Validate::isOptFloat($orderWeight) ? $orderWeight : 0 ) );
				Configuration::updateValue('EXPEDIPRO_ORDERWEIGHT', (int) $orderWeight );
			}
*/
//ppp($_POST);
//ppp( Tools::getValue('orderCarrier') );
			// Because of html constraints, orderCarrier must always be handled
			if ( ! $orderCarrier = Tools::getValue('orderCarrier') ) {													// unchecked box need to be delete
				Configuration::updateValue('EXPEDIPRO_ORDERCARRIER', null );
			} else {
				//ppp( var_dump(Validate::isUnsignedInt($orderCarrier)) );
				Configuration::updateValue('EXPEDIPRO_ORDERCARRIER', $this->transformCheckbox('carrier', $orderCarrier ) );
			}
		}


		if ( Tools::isSubmit('submitConfigOrder') ) {
//ppp( Tools::getValue('orderState') );
            // Because of html constraints, orderState must always be handled
            if ( ! $state = Tools::getValue('orderState') ) {
                Configuration::updateValue('EXPEDIPRO_ORDERSTATE', null);                           // unchecked box (multi choice) need to be delete
            } else {
                //ppp( var_dump(Validate::isUnsignedInt($orderState)) );
                Configuration::updateValue('EXPEDIPRO_ORDERSTATE', $this->transformCheckbox('state', $state));
            }
        }


        if ( Tools::isSubmit('submitConfigDelivery') ) {
            // no ?: before php 5.3
            // no need to uncheck previous value since radio button , single choice
            if ( ! $state = Tools::getValue('deliveryStart') )
                $state = 4 ; // transport

            Configuration::updateValue('EXPEDIPRO_DELIVERYSTART', $this->transformCheckbox('state', $state ) );

            if ( ! $state = Tools::getValue('deliveryDone') )
                $state = 5 ; // livré

            Configuration::updateValue('EXPEDIPRO_DELIVERYDONE', $this->transformCheckbox('state', $state ) );

        }
		return $output;
	}


	/**
	 * Transform int|array POST checkbox|radio into int|string (single or multi values)
	 *
	 * @param string	$scope	'carrier' | 'state'
	 * @param int|array $input
	 *
     * @return null|int|string with int separated by |
     **/
	private function transformCheckbox( $scope= '' , $input= null)
	{
		if ( ! $scope OR ! $input )
            return null;
//ppp( "/debug carrier:" );
//ppp( $input );
        if  ( is_array($input) )										// multi select
		{
			$list ='';
			foreach ( $input as $row )
			{
				if ($scope === 'carrier') {
					if (! $this->isValidCarrierId( $row ) ) continue;
				} else {
					if (! $this->isValidStateId( $row ) ) continue;
				}

				$list .= (int) $row . '|';
			}

			if ( $list ) {
				$list = Tools::substr($list, 0, -1 );
			}
			//$list = implode( '|' , array_map('intval', $input ) ); // can not check ids existence
//ppp( var_dump($list) );
			return $list;
		}
		elseif ( Validate::isUnsignedInt( $input ) )                    // singleton
        {
			if ($scope === 'carrier') {
				return ( $this->isValidCarrierId( $input ) ? (int) $input : null );
			} else {
				return ( $this->isValidStateId( $input ) ? (int) $input : null );
			}
		}
	}


	/**
	 * Get order state from Prestashop config (sendable ones) along with expedipro_orderState status
	 * Note : filter only default Prestashop, not the user specifics ones
     *
     * @param string	$currentList of state from db like "<val>|<val>"
	 * @param string	$filter name
	 *
	 * @return array:
	 */
	public function getStateList( $currentList = "", $filter= '' )
	{
		/**
		 * 9		reappro
		 * 1,10,11	attente chèque,virement,paypal
		 * 8  erreur paiement
		 * 12 paiement ok
		 * 2 payé
		 * 3 prépa
		 * 4 transport
		 * 5 Livré
		 * 6, 7	annulé , remboursé
		 */
        $currentArray = explode( '|', $currentList );
		switch ( $filter ) {
			case 'sendable':
                // 9: reappro allows sending half of the order
				$filterState = array( 1,        5, 6, 7, 8, 10, 11 );
				break;
            case 'deliveryStart':
                $filterState = array( 1, 2,        6, 7, 8, 10, 11, 12 );
                break;
            case 'deliveryDone':
                $filterState = array( 1, 2, 3,     6, 7, 8, 10, 11, 12 );
                break;
/*
            case 'deliveryFail':
                $filterState = array( 1, 2, 3,  5, 6, 7, 8, 10, 11 );
                $currentlySelected = explode( '|', Configuration::get('EXPEDIPRO_DELIVERYFAIL') );
                break;
*/
            default:
                $filterState = array();
		}

//        if ( ! $filteredState = $this->filterStateList( $filterState ) )
//            return array();

		$result = array();
		foreach ( $this->filterStateList( $filterState ) AS $id => $name)
        {
			$result[ $id ] = array(
                'name'		=> $name,
				'selected'	=> ( in_array( $id, $currentArray ) ? 1 : 0 )
			);
		}

		//var_dump($result);
		return $result;
	}


    /**
     * Extract all order states defined in Prestashop
     *  Usage : provide an simple array of keys to remove from the reference list of states
     *
     * @param array		$filter (negative)
     *
     * @return array [ (int) id => (string) name ]
     */
    private function filterStateList( $filter = array() )
    {
        if ( ! $this->stateList )
        {
            $order = new OrderStateCore();
            if (! $this->stateList = $order->getOrderStates( (int) $this->context->language->id ) ) {
                return array();
            }
        }

        $result = array();
        foreach ($this->stateList AS $state)
        {
            if ( $filter AND in_array( $state['id_order_state'], $filter) )
                continue;

            $result[ $state['id_order_state'] ] = $state['name'];
        }

        return $result;
    }


	/**
	 *
	 * @param int		$state
	 *
	 * @return boolean:
	 */
	public function isValidStateId( $stateId = null)
	{
        if ( ! $filteredState = $this->filterStateList( ) )
            return false;

        return isset( $filteredState[ (int) $stateId ] );	// for input check
	}


    private function filterCarrierList( $filter = array() )
    {
        // we only active carriers
        if (!$this->carrierList)
        {
            $this->carrierDbName = ( version_compare(_PS_VERSION_,'1.5','>') ? 'id_reference' : 'id_carrier' );
            // $carrier = new Carrier();
            if (!$this->carrierList = Carrier::getCarriers($this->context->language->id, false, false, false, NULL, ALL_CARRIERS)) // from defines.inc.php
                return array();
        }

        /**
         * Any change in carrier deprecated it and duplicate as new one
         * As of PS 1.5, id_reference give a way to chain id_carrier changes
         */
        $result = array();
        foreach ($this->carrierList as $carrier)
        {
            if ( $filter AND in_array($carrier[ $this->carrierDbName ], $filter))
                continue;

            $result[ $carrier[ $this->carrierDbName ] ] = $carrier['name'];
        }

//var_dump($result);
        return $result;
    }


    /**
	 * Get order state from Prestashop config (sendable ones) along with expedipro_orderState status
	 *
	 * @return array:
	 */
	public function getCarrierList($currentList = "",  $filter= '' )
	{
		$currentArray  = explode( '|', $currentList );

//        if ( ! $filteredCarrier = $this->filterCarrierList( $filter ) )
//            return array();
        $filterCarrier = array();

        $result = array();
        foreach ( $this->filterCarrierList( $filterCarrier ) AS $id => $name )
        {
            $result[ $id ] = array(
                'name'		=> $name,
                'selected'	=> ( in_array( $id, $currentArray ) ? 1 : 0 )
            );
        }

//var_dump($result);
		return $result;
	}


	/**
	 *
	 * @param int		$carrierId
	 *
	 * @return boolean:
	 */
	public function isValidCarrierId( $carrierId = null)
	{

        if ( ! $filteredCarrier = $this->filterCarrierList( ) )
            return false;

        return isset( $filteredCarrier[ (int) $carrierId ] );
	}


    public function diagnoseUrl( $actionUrl, $token )
    {
        // approx 5 when telleMe fail, and 70K when tellMe is ok
        if ( mb_strlen( file_get_contents($actionUrl.'?tellMe='.  hash('sha256', $token )) ) < 200 )
            return 'ERREUR : '.$actionUrl. 'semble inaccessible';

        return 'OK';
/*
        // avoid the CURL dependency
        $keywords = array();
        $domain = array( $actionUrl );
        $doc = new DOMDocument;
        $doc->preserveWhiteSpace = FALSE;
        foreach ($domain as $key => $value) {
            @$doc->loadHTMLFile($value);
            $anchor_tags = $doc->getElementsByTagName('a');
            foreach ($anchor_tags as $tag) {
                $keywords[] = strtolower($tag->nodeValue);
            }
        }
*/
    }

    public function diagnoseCurl( ){
        if ( version_compare(PHP_VERSION, '5.3','<') )
            return 'PHP too old for testing';
        try {
            if ( $assoc = curl_version() AND isset( $assoc['version'] ) )
                return 'OK';
        } catch (Exception $e) {
            return 'RESTRICTION : autoriser la librairie curl dans Apache/PHP';
        }
    }


    public function diagnoseOrder( $pastDay = 7){
        $from = new DateTime();
        $from->modify("-$pastDay day");

        $mapper = new ExpediproMapper();
        if ( ! $orderlist = $mapper->getOrder( $this->context->expedipro->orderState,
                                                $this->context->expedipro->carrier,
                                                $from->format('Y-m-d') ) )
            return "AUCUNE commande trouvée (période $pastDay jours)";
//			var_dump($orderlist);
        return count( $orderlist ) . " commandes trouvées (période $pastDay jours)";
    }


    public function diagnoseCrypt( )
    {
        if ( ! $module = mcrypt_module_self_test(MCRYPT_RIJNDAEL_128) )
            return " ERREUR : module MCRYPT_RIJNDAEL_128 indisponible !";

        $module = mcrypt_module_open(MCRYPT_RIJNDAEL_128, "", MCRYPT_MODE_CBC, "");
        if ( mcrypt_enc_get_key_size($module) !== 32 )
            return " ERREUR : RIJNDAEL_128 mode CBC -> key_size = ".mcrypt_enc_get_key_size($module)." au lieu de 32";

        if ( mcrypt_enc_get_iv_size($module) !== 16 )
            return " ERREUR : RIJNDAEL_128 mode CBC -> iv_size = ".mcrypt_enc_get_iv_size($module)." au lieu de 16";

        return 'OK';
    }
}
?>