<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

/**
 * Called outside of Prestashop context
 *
 */

//require_once dirname(__FILE__).'/expediproAction.php';

class expediproDelivery /* extends Action */
{
	protected $products;

	protected $employee;
	protected $statusMapping;


	public function __construct()
	{
//		parent::__construct();	// required by  $import = new Import();
		$this->employee = Configuration::get('EXPEDIPRO_EMPLOYEE');

        include_once(_PS_MODULE_DIR_.'expedipro/expediproFunctions.php');
        $this->statusMapping = expedipro_deliveryMapping( Configuration::get('EXPEDIPRO_DELIVERYSTART'), Configuration::get('EXPEDIPRO_DELIVERYDONE') );
	}


	/**
	 * Handle the get or post request before main action
	 *
	 * @return boolean
	 */

	public function process( $data )
	{
//		parent::processRequest('import');	// return a ready to use $this->container
		if ( ! $this->setDeliveryStatus( $data ) )
			echo '0';
	}



	/**
	 * Extract orders and output them (to file AND to html)
	 * Note: the result page is like a log where every orderId should appears once and no more.
	 *
	 * @param string	$from mysql date	inclusive start time interval
	 * @param string	$to					inclusive end time interval
	 *
	 * @return false|void
	 */
	protected function setDeliveryStatus( $data )
	{
		if ( ! isset ($data['delivery']) )
			return false;

		$result = array(
			'stepNew'		=> null,
			'stepSame'		=> null,
			'trackingNew'	=> null,
			'trackingSame'	=> null,
			'trackingGrouped'=> null,
			'unknown'		=> null,
			'exception'		=> null
		);

		// product is the effective supplier along its product used for the expedition
		$this->products = ( isset ($data['product']) ? $data['product'] : array() );

//		$allCarrier = $adapter->getCarrierList( );
//echo '<br> $allCarrier =';
//		$allCarrier = array_column_54($adapter->getCarrierList( ), 'name', 'id_carrier');
//var_dump($allCarrier );
/*
echo '<br> data products =';
var_dump($this->products );

echo '<br> data deliveries =';
var_dump($data['delivery'] );
echo '<br>________________________';
var_dump(_PS_VERSION_ );
*/
/*
	array(	'product' =>
			array(	'R00' => 'Colissimo Access France',
					'R01' => 'Colissimo Expert France',
				 ),
			'distribution' =>
			array(	'AVX' => 'Votre colis ....',
					'REN' => 'Livraison effective',
				 ),
			'carrier' =>		// not implemented
			array(	0 => 'MyCarrier',
					1 => 'Colissimo',
				 ),
			'delivery' =>
			array(	0 => array('order'=> '1', 'track'=> 'ABCDEF12', 'step' => '60', 'stepLib' => 'AVX', 'carrier' => '0', 'product' => 'R01', 'insurance' => 234, 'cost' => 15.99),
					1 => array('order'=> '2', 'track'=> 'ZDF543A2', 'step' => '100','stepLib' => 'REN', 'carrier' => '1', 'product' => 'R00','insurance' => 0, 'cost' => 8.22),
			     )
		)
*/
		$max = count( $data['delivery'] );
		for($i=0; $i < $max; $i++ )
		{
			try {
				$orderDetail = $data['delivery'][$i];
				$orderDetail['order'] = (int) $orderDetail['order'];

// debug				throw new Exception("Could not be so bad");

				// better to rely on native methods because of hook::updateOrderStatus and hook::postUpdateOrderStatus
				$orderObject = new Order( $orderDetail['order'] );
				if (! Validate::isLoadedObject($orderObject) ) {
					$result['unknown'][] = $orderDetail['order'];
					$orderObject = null;
					continue;
				}

	/*
	echo '<br> orderDetail =';
	var_dump($orderDetail );
	//echo '<br> currentState =';
	//var_dump($orderObject->currentState );
	echo '<br> getCurrentState =';
	var_dump($orderObject->getCurrentState() );
	echo '<br> stateMapping = ';
	var_dump($state );
	//echo '<br> setCurrentState = ';
	//var_dump( $orderObject->setCurrentState( $this->getStatusMapping($orderDetail['step']), $this->employee ) );
	*/
				$primaryOrder = true;
				// if shipping number is already there, then we have nothing to do
				// either this is not the first feedback for this order, either employee has forced an tracking number
				// this also avoid spamming message for every feedback
				if ( ! $orderObject->shipping_number ) {
					$this->setTrackingNumber( $orderDetail, $orderObject );
					$this->setMessage( $orderDetail, $orderObject );
					$result['trackingNew'][] = $orderDetail['order'];
				}
				elseif ( $orderObject->shipping_number != $orderDetail['track']  )
				{
					$primaryOrder = false; 					// UseCase : splitted order
					if ( (int) $orderDetail['step'] <= 11 ) // not efficient, but at least limit spamming message for splitted order until this stage
					{
						$this->setMessage( $orderDetail, $orderObject );
						$result['trackingGrouped'][] = $orderDetail['order'];
					}
				} else {
					$result['trackingSame'][] = $orderDetail['order'];
				}

				if ( $primaryOrder )
				{
					// Avoid creating order history events when state does not change
					if ( $state = $this->getStatusMapping( $orderDetail['step'] )
						AND $state == (int) $orderObject->getCurrentState() ) // prefer loose comparaison rather than strict
					{
						$result['stepSame'][] = $orderDetail['order'];
					}
					else
					{
						// 1.5 only (at least 1.5.2), has this bug : currentState is updated only if shipping_number is also provided
						// this means setCurrentState() does nothing
						// low priority because orderHistory is updated with correct currentState
						// user see twice (but not more) orderHistory for state 'transport'.
			//			if (version_compare(_PS_VERSION_,'1.5','='))
			//				$orderObject->currentState = $state;
						$orderObject->setCurrentState( $state, $this->employee );
						$result['stepNew'][] = $orderDetail['order'];
					}
				}

	/*
				if ( $orderDetail['carrier'] )
				{
					// ensure that carrier effectively used in Expedipro was the one chose in the order
					$carrierObject = new CarrierCore( $orderObject->id_carrier );
					if ( $carrierObject->name == $orderDetail['carrier']) continue;
					$carrierObject = $message = null;
				}
	*/
                set_time_limit( 20 );
			} catch (Exception $e) {
				$result['exception'][] = $e->getFile().':'.$e->getLine().' '.$e->getMessage().' for '.print_r($orderDetail,true);
			}
		}


		// feedback to Expedipro
		echo	'stepNew=',			( $result['stepNew'] 		? implode( ',', $result['stepNew']) 		: '') ,'|',
				'stepSame=',		( $result['stepSame'] 		? implode( ',', $result['stepSame']) 		: '') ,'|',
				'trackingNew=', 	( $result['trackingNew'] 	? implode( ',', $result['trackingNew']) 	: '') ,'|',
				'trackingGrouped=', ( $result['trackingGrouped']? implode( ',', $result['trackingGrouped'])	: '') ,'|',
				'trackingSame=', 	( $result['trackingSame'] 	? implode( ',', $result['trackingSame']) 	: '') ,'|',
				'unknown=',			( $result['unknown'] 		? implode( ',', $result['unknown']) 		: '') ,'|',
				'exception=',		( $result['exception'] 		? implode( ',', $result['exception']) 		: '');

		return count( $data );
	}


	/**
	 * Add a private message for this Order to display parcel details on the order back office page
	 */
	private function setMessage( $orderDetail = array(), Order $orderObject )
	{
		if ( ! isset($this->products[ $orderDetail['product'] ]) )
			return false;

		$messageObject = new Message();	// OrderMessage if for predefined messages
		$messageObject->message = $this->products[ $orderDetail['product'] ] .
								( $orderDetail['insurance'] ? ', assuré pour ' . str_replace('.', ',',$orderDetail['insurance']) . '€' : '') .
								( $orderDetail['cost'] ? ', coût ht = ' . str_replace('.', ',',$orderDetail['cost']) : '') .
								PHP_EOL .
								'Suivi sur ' . Configuration::get('EXPEDIPRO_DELIVERYTRACKING') . $orderDetail['track'];
								$messageObject->id_order 	= $orderDetail['order'];
								$messageObject->id_cart		= $orderObject->id_cart;
								$messageObject->id_customer	= $orderObject->id_customer;
								$messageObject->id_employee	= $this->employee;
								$messageObject->private		= 1;

		return (bool) $messageObject->add();
//		$messageObject = null; // reduce mem footprint
	}


	/**
	 * Update the Order object with tracking number and Object orderCarrier (PS > 1.5)
	 *
	 * @param array	$orderDetail
	 * @param Order $orderObject
	 *
	 * @return boolean
	 */
	private function setTrackingNumber( $orderDetail = array(), Order $orderObject )
	{
		if ( ! $orderDetail['track'] )
			return false;

		// shipping_number 1.4 type isUrl but DB is only 32char long !
		// shipping_number 1.6 type isTrackingNumber, supposed to becomes deprecated in 1.6 but still used
		$orderObject->shipping_number = $orderDetail['track'];
		$orderObject->update();

		// orderCarrier does not exist before 1.5.0.6
		if (version_compare(_PS_VERSION_,'1.5','>'))
		{
			if ( method_exists($orderObject,'getIdOrderCarrier') ) {
				$idOrderCarrier = $orderObject->getIdOrderCarrier();	//  @since 1.5.5.0
			} else{
				$idOrderCarrier = (int)Db::getInstance()->getValue('
									SELECT `id_order_carrier`
									FROM `'._DB_PREFIX_.'order_carrier`
									WHERE `id_order` = '. $orderDetail['order'] );
			}

			if ( $idOrderCarrier ) {
				$orderCarrierObject = new OrderCarrier( $idOrderCarrier );
				$orderCarrierObject->tracking_number = $orderDetail['track'];
				$orderCarrierObject->weight = $orderDetail['weight'];
				$orderCarrierObject->shipping_cost_tax_excl= $orderDetail['cost'];
				$orderCarrierObject->shipping_cost_tax_incl= ( $orderDetail['costWt'] ? $orderDetail['costWt'] : $orderDetail['cost'] );
				$orderCarrierObject->update();
//				print_r( $orderCarrierObject->getFields() );
				$orderCarrierObject = null;	// reduce mem footprint
			}
		}
		return true;
	}


	private function getStatusMapping( $expediproStatus= 0)
	{
		if ( ! $expediproStatus )
			return null;

		$previous = null;
		foreach ($this->statusMapping AS $expedipro => $prestashop )
		{
			if ( (int) $expediproStatus === $expedipro ) return $prestashop;
			if ( (int) $expediproStatus <  $expedipro ) return $previous;	// if expedipro send a unknown code, don't break and send the closest one
			$previous = $prestashop;
		}
	}
}
?>