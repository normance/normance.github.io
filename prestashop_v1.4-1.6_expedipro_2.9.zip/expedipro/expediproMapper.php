<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

class ExpediproMapper
{
/** 
Expedipro steps
1	dépôt
10	Chargé
11	Chargé
20	Transport
30	Douane
40	Problème
50	Transport
60	Imminent
70	Attente
80	Relivraison
90	Retour
100	Livré
*/
	protected $context; 	// instead of using Context:: which is 1.5+ specific, we rely on this context variable
	protected $statusMapping;

	// DI of context
	public function __construct( $context = null)
	{
//        var_dump( $context );
        if ( $context ) {
            $this->context = $context;
        } else {
            include_once(_PS_MODULE_DIR_.'expedipro/expediproFunctions.php');
            $this->context = prestashop_initContext();
        }

//        print_r( $this->context);
        $this->statusMapping = expedipro_deliveryMapping( $this->context->expedipro->deliveryStart, $this->context->expedipro->deliveryDone );

	}

    /**
     * Hook for specific need on a particular installation
     *
     * @param array $oneOrder
     * @return array
     */
	public function hookForSpecificNeed( $oneOrder ) {
	    return $oneOrder;
    }



    /**
	 * Get order that has just moved in a state within a time period
	 *
	 * @param number|array	$state
	 * @param number|array	$carrier
	 * @param string 		$from 	php DateTime compatible
	 * @param string 		$to 	php DateTime compatible
	 * @param boolean 		$debug to ignore previous parameters
	 *
	 * @return false|array()
	 */
	public function getOrder($state = null, $carrier = null,  $from = null, $to = null, $debug = false)
    {
        if ($debug) {
            print_r($this->context->expedipro);
            print_r($this->context->language);
        }

        // since even 2014-07-01 99:30:00 trigger a fatal error
        try {
            $pointInTime = new DateTime ($from);
        } catch (Exception $e) {
            $pointInTime = new DateTime ();
        }
        $whereFrom = $pointInTime->format('Y-m-d H:i:s');

        try {
            $pointInTime = new DateTime ($to);
        } catch (Exception $e) {
            $pointInTime = new DateTime ();
        }
        $whereTo = $pointInTime->format('Y-m-d H:i:s');

        if (!$state) {
            $whereOrder = ' ( 1 = 1 )';
        } elseif (is_array($state)) {
            $whereOrder = ' ("' . implode('","', $state) . '")';
        } else {
            $whereOrder = ' (' . $this->quote($state) . ')';
        }

        if (!$carrier) {
            $whereCarrier = ' ( 1 = 1 )';
        } elseif (is_array($carrier)) {
            $whereCarrier = ' ("' . implode('","', $carrier) . '")';
        } else {
            $whereCarrier = ' (' . $this->quote($carrier) . ')';
        }

        $sql = ( version_compare(_PS_VERSION_, '1.5', '>')
                ? $this->getOrder15($whereFrom, $whereTo, $whereOrder, $whereCarrier, $debug)
                : $this->getOrder14($whereFrom, $whereTo, $whereOrder, $whereCarrier, $debug) );

        if ($debug)
            var_dump($sql);

        // 2.7 change
        return $this->addPickup( $sql );
    }



    protected function getOrder14($whereFrom, $whereTo, $whereOrder, $whereCarrier, $debug) {

		/*
		 * contenu could be very long
		 * get phone AND mobile
		 * get autre or message ? into instruction
		 * manage company name in adress 3 ?
		 *
		 * To enable the VAT management you need to install a core module and then set the vat field (in the address page list in BO) as required.
		 * dni stands for Documento Nacional de Identidad, for Spanish citizens
		 */

		/*
			SUM( od.`product_weight`) AS "poids",
			o.`total_products_wt` 	AS "valeurTtc",
			SUM( od.`product_quantity`) AS "quantite",
			o.`total_products_wt` 	AS "valeur",
		*/
        /* can not use p.`reference`
           null > "" is also false */

		$sql = 'SELECT c1.`id_gender` AS "civilite",
				a1.`lastname` 		AS "nom",
				a1.`firstname` 		AS "prenom",
				if ( LENGTH(a1.`vat_number`) > 1 , 1, 0 ) AS "entreprise",
				if ( LENGTH(a1.`vat_number`) > 1 ,a1.`lastname` , "" )	AS "entrepriseNom",
				a1.`vat_number`		AS "entrepriseTva",
				a1.`address1` 		AS "adresse1",
				a1.`address2` 		AS "adresse2",
				IF ( LENGTH(a1.`company`) > 1 , UPPER( a1.`company` ), "" )	  AS "adresse3",
				a1.`postcode` 		AS "cp",
				a1.`city` 			AS "ville",
				n.`iso_code` 		AS "pays",
				a1.`phone`			AS "telephone",
				a1.`phone_mobile` 	AS "mobile",
				c1.`email` 			AS "email",
				IF( a1.`other` > "", a1.other, IF( m1.`message` > "", m1.`message`, "") ) AS "instruction",
				c1.`optin`			AS "optin",
				a1.`id_address` 	AS "client",
				o.`id_order` 		AS "reference",
				o.`date_add` 		AS "dateComm",
				"" 		            AS "boutique",
                -- can not use p.`reference`
                -- null > "" is also false
				GROUP_CONCAT( IF( od.`product_reference` > "", concat(od.`product_reference`," : "),""), CONVERT(pl.`name` USING utf8) SEPARATOR "ǁ")  AS "panierDesc",
				GROUP_CONCAT( ROUND(od.`product_price`,2)	SEPARATOR "ǁ" ) AS "panierPrix",
				GROUP_CONCAT( od.`product_quantity` 		SEPARATOR "ǁ" ) AS "panierQte",
				GROUP_CONCAT( od.`product_weight` 			SEPARATOR "ǁ" ) AS "panierPoids",

				MAX( p.`depth`)  		AS "longueur",
				MAX( p.`width`)  		AS "largeur",
				MAX( p.`height`) 		AS "hauteur",
				"" 						AS "allotir",
				oh.`id_order_state` 	AS "state",
				c.`name` 				AS "transporteur"
				FROM `'._DB_PREFIX_.'orders`		AS o
				LEFT JOIN `'._DB_PREFIX_.'address`		AS a1	ON  o.`id_address_delivery` = a1.`id_address`
				LEFT JOIN `'._DB_PREFIX_.'customer`		AS c1	ON a1.`id_customer`			= c1.`id_customer`
				LEFT JOIN `'._DB_PREFIX_.'country_lang`	AS y1	ON a1.`id_country` 			= y1.`id_country`
				                            AND y1.`id_lang`= '. (int) $this->context->language->id .'
				LEFT JOIN `'._DB_PREFIX_.'country` 		AS n	ON a1.`id_country` 			=  n.`id_country`
				LEFT JOIN `'._DB_PREFIX_.'order_detail` AS od	ON  o.`id_order` 			= od.`id_order`
				LEFT JOIN `'._DB_PREFIX_.'product`  	AS p	ON od.`product_id` 			=  p.`id_product`
				LEFT JOIN `'._DB_PREFIX_.'product_lang` AS pl	ON od.`product_id` 			= pl.`id_product`
				                            AND  pl.`id_lang`= '. (int) $this->context->language->id .'
				LEFT JOIN `'._DB_PREFIX_.'carrier` 	    AS c 	ON o.`id_carrier` = c.`id_carrier` 
				LEFT JOIN (SELECT `id_order`, `id_customer`, `message` 
					 		FROM `'._DB_PREFIX_.'message`
					 		WHERE `private` =  0
							    AND ( `id_employee` =  0 OR `id_employee` IS NULL )
							    ORDER BY `date_add` DESC limit 1) AS m1 
							        ON o.`id_order` = m1.`id_order` AND  o.`id_customer` =  m1.`id_customer`';

		/*
		 * od.product_price is the unit price while od.total_price_excl_tax provide unit_price * qte * discount (if any)
		 * but od.* does not provides total weight
		 */

//--			GROUP_CONCAT( IF( LENGTH(pl.`name`) > 30, SUBSTRING(pl.`name`, 1, 30), pl.`name` ) SEPARATOR "ǁ") AS "produitDesc",
//				GROUP_CONCAT( CONCAT(od.`product_id`, "=", CONVERT(pl.`name` USING utf8)) SEPARATOR "ǁ")  AS "produitDesc",
//--				AND o.valid=1

		if ( $debug ) {
			// this allows to see all orders states, but limit to avoid having full dump of orders * order_history !
			$sql .= ' JOIN `'._DB_PREFIX_.'order_history` AS oh ON o.`id_order` = oh.`id_order`

	                    GROUP BY o.`id_order`, oh.`id_order_state`
    					ORDER BY o.`id_order` DESC, oh.`id_order_state` ASC
						LIMIT 0, 500';
		}
		else
		{
			$sql .= ' JOIN (SELECT `id_order`, MAX(`id_order_history`) AS "maxOrderHistory"
						FROM `'._DB_PREFIX_.'order_history`
						WHERE  `date_add` >= "'.$whereFrom.'" AND `date_add` <= "'.$whereTo.'"
						GROUP BY `id_order` ) 	AS oh2  ON o.`id_order` = oh2.`id_order`

					  JOIN `'._DB_PREFIX_.'order_history` AS oh  ON o.`id_order` = oh.`id_order`
					                AND oh.`id_order_history` = oh2.`maxOrderHistory`

			         WHERE oh.`id_order_state` IN '. $whereOrder .'
					                AND o.`id_carrier` IN '. $whereCarrier .'

					GROUP BY o.`id_order`
					ORDER BY o.`id_order` ASC';
		}

        return $sql;

	}



    protected function getOrder15($whereFrom, $whereTo, $whereOrder, $whereCarrier, $debug) {

        /*
         * contenu could be very long ! while expedipro db is 255 and view should be around 70. watchout commandes drag !
         * get phone AND mobile
         * get autre or message ? into instruction
         * manage company name in adress 3 ?
         *
         * To enable the VAT management you need to install a core module and then set the vat field (in the address page list in BO) as required.
         * dni stands for Documento Nacional de Identidad, for Spanish citizens
         */

        /*
            SUM( od.`product_weight`) AS "poids",
            o.`total_products_wt` 	AS "valeurTtc",
            SUM( od.`product_quantity`) AS "quantite",
            o.`total_products_wt` 	AS "valeur",
        */

        /* Note : as of 1.5 p.depth,width... are not related to the product size but rather to the packaged product */


        $sql = 'SELECT c1.`id_gender` AS "civilite",
				a1.`lastname` 		AS "nom",
				a1.`firstname` 		AS "prenom",
				if ( LENGTH(c1.`company`) > 1 , 1, 0 ) 	AS "entreprise",
                c1.`company` 							AS "entrepriseNom",
				a1.`vat_number`		AS "entrepriseTva",
				a1.`address1` 		AS "adresse1",
				a1.`address2` 		AS "adresse2",
				IF ( LENGTH(a1.`company`) > 1 , UPPER( a1.`company` ), "" )	  AS "adresse3",
				a1.`postcode` 		AS "cp",
				a1.`city` 			AS "ville",
				n.`iso_code` 		AS "pays",
				a1.`phone`			AS "telephone",
				a1.`phone_mobile` 	AS "mobile",
				c1.`email` 			AS "email",
                IF( a1.`other` > "", a1.other, IF( m1.`message` > "", m1.`message`, "") ) AS "instruction",
				c1.`optin`			AS "optin",
				a1.`id_address` 	AS "client",

				o.`id_order` 		AS "reference",
				o.`date_add` 		AS "dateComm",
				REPLACE(s.`name`, " ", "") 	AS "boutique",

				GROUP_CONCAT( IF( od.`product_reference` > "", concat(od.`product_reference`," : "),""), CONVERT(pl.`name` USING utf8) SEPARATOR "ǁ")  AS "panierDesc",
				GROUP_CONCAT( ROUND(od.`product_price`,2)	SEPARATOR "ǁ" ) AS "panierPrix",
				GROUP_CONCAT( od.`product_quantity` 		SEPARATOR "ǁ" ) AS "panierQte",
				GROUP_CONCAT( od.`product_weight` 			SEPARATOR "ǁ" ) AS "panierPoids",

				MAX( p.`depth`)  		AS "longueur",
				MAX( p.`width`)  		AS "largeur",
				MAX( p.`height`) 		AS "hauteur",
				"" 						AS "allotir",
				oh.`id_order_state` 	AS "state",
				c.`name` 				AS "transporteur"
				FROM `'._DB_PREFIX_.'orders`		AS o
				LEFT JOIN `'._DB_PREFIX_.'address`		AS a1	ON  o.`id_address_delivery` = a1.`id_address`
				LEFT JOIN `'._DB_PREFIX_.'customer`		AS c1	ON a1.`id_customer`			= c1.`id_customer`
				LEFT JOIN `'._DB_PREFIX_.'country_lang`	AS y1	ON a1.`id_country` 			= y1.`id_country`
				                            AND y1.`id_lang`= '. (int) $this->context->language->id .'
				LEFT JOIN `'._DB_PREFIX_.'country` 		AS n	ON a1.`id_country` 			=  n.`id_country`
				LEFT JOIN `'._DB_PREFIX_.'order_detail` AS od	ON  o.`id_order` 			= od.`id_order`
				LEFT JOIN `'._DB_PREFIX_.'product`  	AS p	ON od.`product_id` 			=  p.`id_product`
				LEFT JOIN `'._DB_PREFIX_.'product_lang` AS pl	ON od.`product_id` 			= pl.`id_product`
				                            AND  pl.`id_lang`= '. (int) $this->context->language->id .'
   				                            AND  o.`id_shop` = pl.`id_shop`
                LEFT JOIN `'._DB_PREFIX_.'carrier` 	AS c 	ON o.`id_carrier` = c.`id_carrier`
                
                LEFT JOIN (SELECT `id_order`, `id_customer`, `message` 
					 		FROM `'._DB_PREFIX_.'message`
					 		WHERE `private` =  0
							    AND ( `id_employee` =  0 OR `id_employee` IS NULL )
							    ORDER BY `date_add` DESC limit 1) AS m1 
							        ON o.`id_order` = m1.`id_order` AND  o.`id_customer` =  m1.`id_customer`
                
                JOIN `'._DB_PREFIX_.'shop` 	AS s	ON  o.`id_shop` 			=  s.`id_shop` ';

        if ( $debug ) {
            // this allows to see all orders states, but limit to avoid having full dump of orders * order_history !
            $sql .= ' JOIN `'._DB_PREFIX_.'order_history` AS oh ON o.`id_order` = oh.`id_order`

	                    GROUP BY o.`id_order`, oh.`id_order_state`
    					ORDER BY o.`id_order` DESC, oh.`id_order_state` ASC
						LIMIT 0, 500';
        }
        else
        {
            $sql .= ' JOIN (SELECT `id_order`, MAX(`id_order_history`) AS "maxOrderHistory"
						FROM `'._DB_PREFIX_.'order_history`
						WHERE  `date_add` >= "'.$whereFrom.'" AND `date_add` <= "'.$whereTo.'"
						GROUP BY `id_order` ) 	AS oh2  ON o.`id_order` = oh2.`id_order`

					  JOIN `'._DB_PREFIX_.'order_history` AS oh  ON o.`id_order` = oh.`id_order`
					                AND oh.`id_order_history` = oh2.`maxOrderHistory`

			         WHERE oh.`id_order_state` IN '. $whereOrder .'
					                AND o.`id_carrier` IN ( SELECT `id_carrier` FROM `'._DB_PREFIX_.'carrier` WHERE `id_reference` IN '. $whereCarrier .' )

					GROUP BY o.`id_order`
					ORDER BY o.`id_order` ASC';
        }

        return $sql;
    }



	/**
	 * Circumvent EmployeeCore->add() or save() which fail for unknown reasons
	 * Note the fake password that would never allows login
	 *
	 */
	public function setExpediproEmployee($email ='',$lang = 2  )
	{
		include_once(_PS_MODULE_DIR_.'expedipro/expediproFunctions.php');
		$profile = new ProfileCore();
		$allProfile = array_column_54($profile->getProfiles($lang), 'name', 'id_profile');
		//var_dump( $profile->getProfiles($this->context->language->id) );
//var_dump( $allProfile );
//die;
		//var_dump( array_search('logisticien',array_map('strtolower',$allProfile)) );
		//die;
		//var_dump( $employee->id_profile );
		if ( ! $logisticien = array_search('logisticien',array_map('strtolower',$allProfile)) )
			$logisticien = 2;

		$sql =  'INSERT INTO `'._DB_PREFIX_.'employee`
				(`lastname`,`firstname`,`id_profile`,`id_lang`,`email`,`passwd`,`active`)
				VALUES 	(
					"EXPEDIPRO",
					"",'.
					$logisticien .','.
					$lang .',"'.
					$email .'",
					"_____________________________",
					0)';

		Db::getInstance()->Execute($sql);
		return Db::getInstance()->Insert_ID();
	}


	/**
	 * Circumvent EmployeeCore->getByEmail() which required employee to be active
	 *
	 * @param string $email
	 *
	 * @return boolean
	 */
	public  function isEmployeeExpediproExist($email ='')
	{
		$sql = 'SELECT `id_employee`
				FROM `'._DB_PREFIX_.'employee`
				WHERE `email` = "'. pSQL($email) .'"';

		if ( ! $result = Db::getInstance()->ExecuteS($sql) )
			return false;

		$result = array_pop( $result );
		return $result['id_employee'];
	}

    /**
     * Update the order status in db
     *
     * @param int $orderId
     * @param null $trackingNumber
     * @param null $status
     *
     * @return bool
     */
	public function updateOrder($orderId = 0, $trackingNumber = null, $status = null)
	{
		if ( ! $orderId OR ! ( $trackingNumber OR $status ) ) return false;
		$sql = '';

		// better to rely on native methods, eventhough less efficient
		$order = new Order($orderId);
		if ( $trackingNumber )
		{
			$order->shipping_number = $trackingNumber;	// supposed to becomes deprecated in 1.6
			// Db::pSQL() or pSQL() ?
			$sql = 'UPDATE `'._DB_PREFIX_.'order_carrier`
					SET `tracking_number` = "'. pSQL( $trackingNumber ) .'"
					WHERE `id_order` = '. (int) $orderId;
		}

		if ( $status )
			$order->setCurrent_state( $this->statusMapping($status), /* EXPEDIPRO_EMPLOYEE */ null );
//			$order->current_state = $this->statusMapping($status);


		$order->update();

		if ( $sql )
			Db::getInstance()->Execute($sql);


		return true;
	}


    protected function quote($value)
    {
        if (is_int($value)) {
            return $value;
        } elseif (is_float($value)) {
            return sprintf('%F', $value);
        } elseif (is_array($value)) {
            foreach ($value as &$val) {
                $val = $this->quote($val);
            }
            return implode(', ', $value);
        }
        return "'" . addcslashes($value, "\000\n\r\\'\"\032") . "'";
    }


    // porting from 3.3 version, IMPORTANT : PHP 5.4 SYNTAX !!


    /**
     * Execute main sql request and other to get siteLivraison id
     *
     * @param $orderRequest
     * @return array
     */
    protected function addPickup( $orderRequest )
    {

        if ( ! $order = Db::getInstance()->ExecuteS( $orderRequest ) )
            return [];

        // get pickup info for all carts in once
        // not all carts becomes orders (cancelled before payment)
        $allPickup = $this->getPickupServiceId( array_column_54($order, 'cartId' ) );

        //foreach using reference has been improved in 7.0, better to avoid before that version
        $updatedOrder = array();
        // PDO::FETCH_ASSOC
        foreach ( $order as $one )
        {
            $one['siteLivraison'] = ( isset( $allPickup[ $one['cartId'] ] ) ? $allPickup[ $one['cartId'] ] : null ); //  (string) | [id: ,type:]
            // If you want to add an id, replace values, etc
            $one = $this->hookForSpecificNeed( $one );
            $updatedOrder[] = $one;
        }
        $order = null; // reduce mem footprint
        return $updatedOrder;
    }



    /**
     * Get pickup (Colissimo, Dpd, Chronopost, Mondial Relay) info for all carts
     *
     * @param array $cartIds to look for
     *
     * @return array
     */
    public function getPickupServiceId( $cartIds = [])
    {
        $cartInList = ' ("' . implode('","', $cartIds) . '")';
        $allPickup = [];
        // array_merge() reindex numerics keys, + keep them. Note: in case of duplicate array_merge keeps last value, + the first one
        $allPickup += $this->getMondialRelaySiteLivraison( $cartInList );
        $allPickup += $this->getDpdSiteLivraison( $cartInList );
        $allPickup += $this->getColissimoSiteLivraison( $cartInList );
        $allPickup += $this->getChronopostSiteLivraison( $cartInList );

        return $allPickup;
    }


    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getColissimoSiteLivraison( $cartInList= "" )
    {
        if ( ! $version = $this->getModuleVersion('colissimo%') )  // colissimo
            return [];

        // 2021-03: So Colissimo module from la Poste evolve: id_colissimo_pickup_point is now just un sql id, use colissimo_id to get the pickup id
        return $this->getSiteLivraison(
            'SELECT CPP.`id_cart` AS "idCart", PP.`product_code` AS "type", IF( LENGTH( PP.`id_colissimo_pickup_point`) > 5, PP.`id_colissimo_pickup_point`, PP.`colissimo_id` ) AS "id"
                FROM  `' . _DB_PREFIX_ . 'colissimo_cart_pickup_point` AS CPP
                LEFT JOIN `' . _DB_PREFIX_ . 'colissimo_pickup_point` AS PP ON PP.id_colissimo_pickup_point = CPP.id_colissimo_pickup_point
                WHERE CPP.`id_cart` IN ' . $cartInList );
    }

    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getDpdSiteLivraison( $cartInList= "" )
    {
        if ( ! $version = $this->getModuleVersion('dpd%') ) // dpdfrance
            return [];

        return $this->getSiteLivraison(
            'SELECT `id_cart` AS "idCart", `relay_id` AS "id", `service` AS "type"
            FROM  `' . _DB_PREFIX_ . 'dpdfrance_shipping`
            WHERE `id_cart` IN ' . $cartInList );
    }

    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getChronopostSiteLivraison( $cartInList = "" )
    {
        if ( ! $version = $this->getModuleVersion('chronopost%') ) // chronopost
            return [];

        return $this->getSiteLivraison(
            'SELECT `id_cart` AS "idCart",`id_pr` AS "id", null AS "type"
            FROM  `' . _DB_PREFIX_ . 'chrono_cart_relais`
            WHERE `id_cart` IN ' . $cartInList );
    }


    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getMondialRelaySiteLivraison( $cartInList = "" )
    {
        if ( ! $version = $this->getModuleVersion('mondial%' ) )
            return [];

        if ( version_compare($version,'3.0','<') ) {
            $sql = 'SELECT S.`id_cart` AS "idCart", S.`MR_Selected_Num` AS "id", S.`MR_insurance` AS "ass", M.`dlv_mode` AS "type"
                FROM `' . _DB_PREFIX_ . 'mr_selected` AS S
                JOIN `' . _DB_PREFIX_ . 'mr_method` AS M  ON M.`id_mr_method` = S.`id_method` 

                 WHERE M.`is_deleted` = 0
                   AND S.`id_cart` IN ' . $cartInList;
        }
        else
        {
            $sql = 'SELECT S.`id_cart` AS "idCart", S.`selected_relay_num` AS "id", S.`insurance_level` AS "ass", M.`delivery_mode` AS "type"
                FROM `' . _DB_PREFIX_ . 'mondialrelay_selected_relay` AS S
                JOIN `' . _DB_PREFIX_ . 'mondialrelay_carrier_method` AS M ON M.`id_mondialrelay_carrier_method` = S.`id_mondialrelay_carrier_method` 

                 WHERE M.`is_deleted` = 0
                   AND S.`id_cart` IN ' . $cartInList;
        }

        return $this->getSiteLivraison( $sql );
    }

    /**
     *
     * @param string $sqlLike LIKE parameter, including %
     * @return false|mixed
     */
    private function getModuleVersion( $sqlLike ="" ) {
        try {
            if (!$result = \Db::getInstance()->ExecuteS( 'SELECT name, active, version FROM `'._DB_PREFIX_.'module` WHERE name LIKE "'.$sqlLike.'" ' ))
                return false;
        } catch ( Exception $e ) {
            return false;
        }

        if ( ! isset( $result[0] ) OR ! (int) $result[0]['active'] )
            return false;

        return $result[0]['version'];
    }


    /**
     *
     * Important, $sql must provides SELECT idCart, id, type
     *
     * @param $sql
     * @return array
     */
    private function getSiteLivraison( $sql )
    {
        $cartSite = [];
        try {
            if (!$result = \Db::getInstance()->ExecuteS($sql))
                return $cartSite;
        } catch (\Exception $e) {
            return $cartSite;
        }

        foreach ($result as $one)
            $cartSite[ $one['idCart'] ] = ['id' => $one['id'], 'type' => $one['type']];

        return $cartSite;
    }
}
?>