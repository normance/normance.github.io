<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

if (!defined('_PS_VERSION_'))
	exit;

class Expedipro extends Module
{
	protected	$context; // instead of using Context:: which is 1.5+ specific, we rely on this context variable
	private		$_output ='';

	public function __construct()
	{
		$this->name = 'expedipro';
		$this->tab  = 'shipping_logistics';
		$this->author  = 'Expedipro (officiel)';
		$this->version = '2.7'; // only two not three digits
		$this->need_instance = 0;
//		$this->limited_countries = 'fr';

		if (version_compare(_PS_VERSION_,'1.5','>')) {
			$this->ps_versions_compliancy = array('min' => '1.4', 'max' => '99');
			$this->dependencies = array('blockcart');
		}


		include_once(_PS_MODULE_DIR_.'expedipro/expediproFunctions.php');
		expedipro_checkDir();
		$this->context = prestashop_initContext();

		parent::__construct();
		//
		if (version_compare(_PS_VERSION_,'1.6','>')) {
			$this->displayName = ' Expedipro.com : simplifiez-vous l\'expédition';
			$this->description = $this->l('L\'expédition de vos colis aux tarifs pro, en quelques clics, avec synchronisation automatique de l\'état de livraison.');
		} else {
			$this->displayName = '&nbsp;&diams;&nbsp; Expedipro.com : simplifiez-vous l\'expédition';
			$this->description = $this->l('<p><span style="border:2px dotted blue !important;"> <b>L\'expédition de vos colis</b> aux tarifs pro, en quelques clics, avec synchronisation automatique de l\'état de livraison.</span></p>');
		}

		// done here rather during install, since update does not required uninstall/install process
		// so even droping new files will update version at the next instanciation
		Configuration::updateValue('EXPEDIPRO_VERSION', $this->version);
		Configuration::updateValue('EXPEDIPRO_TITLE',	$this->displayName);

		if (version_compare(_PS_VERSION_,'1.6','<')) {
			$this->displayName = $this->l( $this->displayName.'<br>');
		}
		$this->confirmUninstall = $this->l('Voulez-vous désinstaller le module Expedipro ?');

		// provide content to caller and also by dependency injection (config)
		return $this->context;
	}


	public function install()
	{
		include(_PS_MODULE_DIR_.'expedipro/expediproMapper.php');

//		$pointInTime = new DateTime ( );
//		$pointInTime->modify('-4 day'); // prior to PHP 5.3, we can not chain modify and ->format('Y-m-d H:i:s')
		$mapper = new ExpediproMapper($this->context);

		// we defined a UNACTIVE employee for updating status order
		// note that password is random and not compliant with ps, so no login is possible
//var_dump($this->isEmployeeExpediproExist('support_module@expedipro.com'))	;
//var_dump($this->context);
		if ( $oldEmployee = $mapper->isEmployeeExpediproExist('support_module@expedipro.com') )
		{	// in case of delete/reinstall, employee still exists
			Configuration::updateValue('EXPEDIPRO_EMPLOYEE', $oldEmployee ) ;
		} else {
			if ( ! $newEmployee = $mapper->setExpediproEmployee('support_module@expedipro.com', $this->context->language->id) )
				$newEmployee = 1; // for sure this one exist
			Configuration::updateValue('EXPEDIPRO_EMPLOYEE', $newEmployee ) ;
		}

		return parent::install() 													AND
//			$this->registerHook('displayAdminOrder') 								AND
//			$this->psOverride('install') 											AND
//			$this->installModuleTab('export', array(1=>'Expedipro', 2=>'Expedipro'), 3) AND
			Configuration::updateValue('EXPEDIPRO_TOKEN', expedipro_randomString(32) ) AND	// this is not url?token= from prestashop
			Configuration::updateValue('EXPEDIPRO_SEPARATOR', '|')					AND
			Configuration::updateValue('EXPEDIPRO_ORDERSTATE', '2|3')   			AND // paid and preparation
			Configuration::updateValue('EXPEDIPRO_ORDERCARRIER', '')   				AND // all carriers by default
			Configuration::updateValue('EXPEDIPRO_DELIVERYSTART', '4')   			AND	// transport
			Configuration::updateValue('EXPEDIPRO_DELIVERYDONE', '5' )              AND // livré
			Configuration::updateValue('EXPEDIPRO_DELIVERYTRACKING', 'www.expedipro.com/suivi?id=');
	}


	public function uninstall()
	{
//		if ( ! parent::uninstall())
//			Db::getInstance()->Execute('DELETE FROM `'._DB_PREFIX_.'mymodule`');

		// not sure we must delete EXPEDIPRO employee in case it is just an delete/reinstall of the module
		// we would lost employee name in history status of orders

		return parent::uninstall()								AND
//			$this->registerHook('displayAdminOrder') 			AND
//			$this->psOverride('uninstall') 						AND
//			$this->uninstallModuleTab('export')					AND
			Configuration::deleteByName('EXPEDIPRO_TITLE')			AND
			Configuration::deleteByName('EXPEDIPRO_VERSION')		AND
			Configuration::deleteByName('EXPEDIPRO_TOKEN')			AND
			Configuration::deleteByName('EXPEDIPRO_SEPARATOR')		AND
			Configuration::deleteByName('EXPEDIPRO_ORDERSTATE')  	AND
			Configuration::deleteByName('EXPEDIPRO_ORDERCARRIER') 	AND
			Configuration::deleteByName('EXPEDIPRO_DELIVERYTRACKING')	AND
            Configuration::deleteByName('EXPEDIPRO_DELIVERYSTART') 	AND
            Configuration::deleteByName('EXPEDIPRO_DELIVERYDONE' )  AND
			Configuration::deleteByName('EXPEDIPRO_EMPLOYEE')       AND
            /* obsolete keys that might still exist */
            Configuration::deleteByName('EXPEDIPRO_ORDERTRACKING')	AND
            Configuration::deleteByName('EXPEDIPRO_ORDERFROM')	    AND
            Configuration::deleteByName('EXPEDIPRO_ORDERWEIGHT')
            ;

	}


	/**
	 * Display under order detail
	 *
	 * @param unknown $param
	 *
	 * @return string
	 */
/*
	public function hookAdminOrder( $param )
	{
		return '<br />
		<fieldset style="width: 300px">
			<legend><img src="../modules/'.$this->name.'/logo.png" /> '.$this->l('Exporter vers Expedipro').'</legend>
			<a href="'._PS_MODULE_DIR_.$this->name.'/export.php?token='.Configuration::get('EXPEDIPRO_TOKEN').'">'.$this->l('Exporter').'</a><br />
		</fieldset>';
	}
*/


	/**
	 * Prestashop magic: if exists, display the "configure" link
	 *
	 * @return html form
	 */
	public function getContent()
	{
		include(_PS_MODULE_DIR_.'expedipro/expediproConfig.php');
		$adapter = new ExpediproConfig($this->context);
		$this->_output .= $adapter->configPost();

//		global $smarty;
		$this->context->smarty->assign('config',
				array('expediproToken'=> Configuration::get('EXPEDIPRO_TOKEN'),
					'expediproUrl'	=> 'http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'modules/expedipro/expediproAction.php',
					'expediproCanal'=> str_replace(' ', '', Configuration::get('PS_SHOP_NAME') ) ,	// removing spaces help using this as an id
					'expediproTitle'=> Configuration::get('EXPEDIPRO_TITLE'),
                    'diagnoseUrl'   => $adapter->diagnoseUrl( 'http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'modules/expedipro/expediproAction.php', Configuration::get('EXPEDIPRO_TOKEN') ),
                    'diagnoseCrypt' => $adapter->diagnoseCrypt( ),
                    'diagnoseOrder' => $adapter->diagnoseOrder( ),
                    'diagnoseCurl'  => $adapter->diagnoseCurl( ),
					'orderState'	=> $adapter->getStateList( Configuration::get('EXPEDIPRO_ORDERSTATE'),      'sendable' ),
                    'deliveryStart'	=> $adapter->getStateList( Configuration::get('EXPEDIPRO_DELIVERYSTART'),   'deliveryStart' ),
                    'deliveryDone'	=> $adapter->getStateList( Configuration::get('EXPEDIPRO_DELIVERYDONE'),    'deliveryDone' ),
					'orderCarrier'	=> $adapter->getCarrierList( Configuration::get('EXPEDIPRO_ORDERCARRIER') )
				)		// keep array() syntax for PHP < 5.4
		);
		// PHP_VERSION (chaîne de caractères) => "major.minor.release[extra]"

		// PHP_VERSION (chaîne de caractères) => "major.minor.release[extra]"



//		if (version_compare(_PS_VERSION_,'1.4.5.1','<')) {
//var_dump('<br> v1.4.5 :: ' .__FILE__ );
//var_dump('<br> v1.4.4 :: ' ._PS_MODULE_DIR_.'expedipro/expedipro.php' );

			// __FILE__ would be more convenient as first arg, but versions prior '1.4.5.1' rely on a eval() which canot evaluate __FILE__ during parsing
			// Fixed #PSCFI-3439 - eval() call, thanks a lot to Alexandre Segura for this fix/improvement
			$this->_output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configHeader_14.tpl');
			$this->_output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configConnection_14.tpl');
			$this->_output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configCarrier_14.tpl');
			$this->_output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configOrder_14.tpl');
            $this->_output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configDelivery_14.tpl');
            $this->_output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configDiagnose_14.tpl');
        //$this->_output .= $this->display(_PS_MODULE_DIR_.'expedipro/expedipro.php','tpl/configFooter_14.tpl');

//var_dump($this->_ouput);
		return $this->_output;
	}

	/**
	 * Add a new tab under commande
	 * note : I would prefer an hook within adminOrder summary if possible.
	 *
	 * @param unknown $tabClass
	 * @param unknown $tabName
	 * @param unknown $idTabParent
	 * @return boolean
	 */
/*
	private function installModuleTab($tabClass, $tabName, $idTabParent)
	{
		@copy(_PS_MODULE_DIR_.$this->name.'/logo.gif', _PS_IMG_DIR_.'t/'.$tabClass.'.gif');
		$tab = new Tab();
		$tab->name = $tabName;
		$tab->class_name = $tabClass;
		$tab->module = $this->name;
		$tab->id_parent = $idTabParent;
		return (bool) $tab->save();
	}


	private function uninstallModuleTab($tabClass)
	{
		$idTab = Tab::getIdFromClassName($tabClass);
		if( $idTab )
		{
			$tab = new Tab($idTab);
			$tab->delete();
			return true;
		}
		return false;
	}
*/



	/**
	 * Les overrides permettent de modifier le cœur du CMS tout en gardant une évolutivité
	 * Une version 1.5+ embarque directement des méthodes de gestion des overrides !
	 *
	 * Voici une méthode permettant de gérer les overrides tant en 1.4.x qu'en 1.5.x :
	 * http://www.undernews.fr/developpement-web/prestashop-1-5-gerer-la-retro-compatibilite-des-modules-pour-les-versions-1-4.html
	 *
	 * @param string $mod
	 *
	 * @return boolean
	 */
/*
	public function psOverride($mod)
	{
		if ($mod == 'install') {
			if (version_compare(_PS_VERSION_,'1.4','>=') && version_compare(_PS_VERSION_,'1.5','<')) {
				if (!file_exists('../override/controllers/SearchController.php'))
				if (!copy('../modules/expedipro/ps_14/SearchController.php', '../override/controllers/SearchController.php'))
					return false;
				if (!file_exists('../override/classes/Search.php'))
				if (!copy('../modules/expedipro/ps_14/Search.php', '../override/classes/Search.php'))
					return false;
			}
			return true;
		}
		elseif ($mod == 'uninstall')
		{
			if (version_compare(_PS_VERSION_,'1.4','>=') && version_compare(_PS_VERSION_,'1.5','<')) {
				if (!file_exists('../override/controllers/SearchController.php'))
				if (!unlink('../override/controllers/SearchController.php'))
					return false;
				if (!file_exists('../override/classes/Search.php'))
				if (!unlink('../override/classes/Search.php'))
					return false;
			}
			return true;
		}
	}
*/

	/**
	 * http://www.undernews.fr/developpement-web/prestashop-1-5-gerer-la-retro-compatibilite-des-modules-pour-les-versions-1-4.html
	 *
	 * @param unknown $params
	 * @return boolean
	 */
/*
	private function calculHookCommon($params)
	{
		if (version_compare(_PS_VERSION_,'1.5','>')) {
			$this->context->smarty->assign(array(
			'ENT_QUOTES' =>        ENT_QUOTES,
			'search_ssl' =>        Tools::usingSecureMode(),
			'ajaxsearch' =>        Configuration::get('PS_SEARCH_AJAX'),
			'instantsearch' =>    Configuration::get('PS_INSTANT_SEARCH'),
			'ps_version' =>        _PS_VERSION_,
			));
			return true;
		}
		else
		{
			global $smarty;
			$smarty->assign(array(
					'ENT_QUOTES' =>        ENT_QUOTES,
					'search_ssl' =>        (int)Tools::usingSecureMode(),
					'ajaxsearch' =>        Configuration::get('PS_SEARCH_AJAX'),
					'instantsearch' =>    Configuration::get('PS_INSTANT_SEARCH'),
					'ps_version' =>        _PS_VERSION_,
			));
			return true;
		}
	}
*/

}
?>