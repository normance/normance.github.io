<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014-2019 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

namespace Expedipro\Module\Action;


class MapperPickup
{

    /**
     * Get pickup (Colissimo, Dpd, Chronopost, Mondial Relay) info for all carts
     *
     * @param array $cartIds to look for
     *
     * @return array
     */
    public function getPickupServiceId( $cartIds = [])
    {
        $cartInList = ' ("' . implode('","', $cartIds) . '")';
        $allPickup = [];
        // array_merge() reindex numerics keys, + keep them. Note: in case of duplicate array_merge keeps last value, + the first one
        $allPickup += $this->getMondialRelaySiteLivraison( $cartInList );
        $allPickup += $this->getDpdSiteLivraison( $cartInList );
        $allPickup += $this->getColissimoSiteLivraison( $cartInList );
        $allPickup += $this->getChronopostSiteLivraison( $cartInList );

        return $allPickup;
    }


    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getColissimoSiteLivraison( $cartInList= "" )
    {
        if ( ! $version = $this->getModuleVersion('colissimo%') )  // colissimo
            return [];

        // 2021-03: So Colissimo module from la Poste evolve: id_colissimo_pickup_point is now just un sql id, use colissimo_id to get the pickup id
        return $this->getSiteLivraison(
            'SELECT CPP.`id_cart` AS "idCart", PP.`product_code` AS "type", IF( LENGTH( PP.`id_colissimo_pickup_point`) > 5, PP.`id_colissimo_pickup_point`, PP.`colissimo_id` ) AS "id"
                FROM  `' . _DB_PREFIX_ . 'colissimo_cart_pickup_point` AS CPP
                LEFT JOIN `' . _DB_PREFIX_ . 'colissimo_pickup_point` AS PP ON PP.id_colissimo_pickup_point = CPP.id_colissimo_pickup_point
                WHERE CPP.`id_cart` IN ' . $cartInList );
    }

    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getDpdSiteLivraison( $cartInList= "" )
    {
        if ( ! $version = $this->getModuleVersion('dpd%') ) // dpdfrance
            return [];

        return $this->getSiteLivraison(
            'SELECT `id_cart` AS "idCart", `relay_id` AS "id", `service` AS "type"
            FROM  `' . _DB_PREFIX_ . 'dpdfrance_shipping`
            WHERE `id_cart` IN ' . $cartInList );
    }

    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getChronopostSiteLivraison( $cartInList = "" )
    {
        if ( ! $version = $this->getModuleVersion('chronopost%') ) // chronopost
            return [];

        return $this->getSiteLivraison(
            'SELECT `id_cart` AS "idCart",`id_pr` AS "id", null AS "type"
            FROM  `' . _DB_PREFIX_ . 'chrono_cart_relais`
            WHERE `id_cart` IN ' . $cartInList );
    }


    /**
     * Search for pickup id for cart id
     *
     * @param string $cartInList
     *
     * @return array [<id_cart> => <id_pickup>,...]
     */
    private function getMondialRelaySiteLivraison( $cartInList = "" )
    {
        if ( ! $version = $this->getModuleVersion('mondial%' ) )
            return [];

        if ( version_compare($version,'3.0','<') ) {
            $sql = 'SELECT S.`id_cart` AS "idCart", S.`MR_Selected_Num` AS "id", S.`MR_insurance` AS "ass", M.`dlv_mode` AS "type"
                FROM `' . _DB_PREFIX_ . 'mr_selected` AS S
                JOIN `' . _DB_PREFIX_ . 'mr_method` AS M  ON M.`id_mr_method` = S.`id_method` 

                 WHERE M.`is_deleted` = 0
                   AND S.`id_cart` IN ' . $cartInList;
        }
        else
        {
            $sql = 'SELECT S.`id_cart` AS "idCart", S.`selected_relay_num` AS "id", S.`insurance_level` AS "ass", M.`delivery_mode` AS "type"
                FROM `' . _DB_PREFIX_ . 'mondialrelay_selected_relay` AS S
                JOIN `' . _DB_PREFIX_ . 'mondialrelay_carrier_method` AS M ON M.`id_mondialrelay_carrier_method` = S.`id_mondialrelay_carrier_method` 

                 WHERE M.`is_deleted` = 0
                   AND S.`id_cart` IN ' . $cartInList;
        }

        return $this->getSiteLivraison( $sql );
    }

    /**
     *
     * @param string $sqlLike LIKE parameter, including %
     * @return false|mixed
     */
    private function getModuleVersion( $sqlLike ="" ) {
        try {
            if (!$result = \Db::getInstance()->ExecuteS( 'SELECT name, active, version FROM `'._DB_PREFIX_.'module` WHERE name LIKE "'.$sqlLike.'" ' ))
                return false;
        } catch ( Exception $e ) {
            return false;
        }

        if ( ! isset( $result[0] ) OR ! (int) $result[0]['active'] )
            return false;

        return $result[0]['version'];
    }


    /**
     *
     * Important, $sql must provides SELECT idCart, id, type
     *
     * @param $sql
     * @return array
     */
    private function getSiteLivraison( $sql )
    {
        $cartSite = [];
        try {
            if (!$result = \Db::getInstance()->ExecuteS($sql))
                return $cartSite;
        } catch (\Exception $e) {
            return $cartSite;
        }

        foreach ($result as $one)
            $cartSite[ $one['idCart'] ] = ['id' => $one['id'], 'type' => $one['type']];

        return $cartSite;
    }

}
?>