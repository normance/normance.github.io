<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2014 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */


trait ContextCron
{
    /**
     *  Get a singleton instance of Context object, with Employee and Language, even in cron
     *
     * @return object Context
     */
    public function setContextCron()
    {

        $context = Context::getContext();
        $langId = (int)($context->language->id ?? Configuration::get('PS_LANG_DEFAULT')) ?: 1;

        if ( ! Context::getContext()->language )
            Context::getContext()->language = new \Language($langId);

        if ( ! Context::getContext()->employee )
            Context::getContext()->employee =
                new \Employee (  //  __construct( $id, $profileId, $languageId, $firstName, ...,$defaultShopId, $associatedShopIds,$associatedShopGroupIds )
                    (int)(Configuration::get('EXPEDIPRO_EMPLOYEE') ?: Configuration::get('PS_ONSALE_RECOVERY_EMPLOYEE') ?: 1),
                    $langId,
                    $context->shop->id ?: 1
                );
        return Context::getContext();
    }

}
?>