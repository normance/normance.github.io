<?php
/**
 * 2014 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  2019 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

namespace Expedipro\Module\Action;

class Delivery // extends \ModuleAdminController
{
    use ContextCron;

    protected
        $context,
        $products,
        $statusMapping;


    public function __construct( \Context $context =null )
    {
        // PrestaShopBundle/Entity/Repository/StockManagementRepository.php:130  Determining the active language requires a contextual employee instance
        $this->context = $context ?: $this->setContextCron();

        $this->statusMapping =
            ( new Mapper( $this->context ) )->deliveryState(
                \Configuration::get('EXPEDIPRO_DELIVERYBEFORE'),
                \Configuration::get('EXPEDIPRO_DELIVERYSTART'),
                \Configuration::get('EXPEDIPRO_DELIVERYDONE') );
    }

    /**
     * Handle the get or post request before main action
     *
     * @param array $data
     *
     * @return array
     */
    public function process( array $data ) :array
    {
//		parent::processRequest('import');	// return a ready to use $this->container
        if ( ! isset ($data['delivery']) )
            return [];
//var_dump( $data['product'] );
        // product is the effective supplier along its product used for the expedition
        $this->products = $data['product'] ?? [];

        return $this->setDelivery( $data['delivery'] );
    }



    /**
     * Extract orders and output them (to file AND to html)
     * Note: the result page is like a log where every orderId should appears once and no more.
     *
     * @param array $delivery
     *
     * @return array
     */
    protected function setDelivery( array $delivery ) :array
    {
        $result = [
            'stepNew'		=> null,
            'stepSame'		=> null,
            'stepIgnored'   => null,
            'trackingNew'	=> null,
            'trackingSame'	=> null,
            'trackingGrouped'=> null,
            'unknown'		=> null,
            'exception'		=> null
        ];

        //		$allCarrier = $adapter->getCarrierList( );
        //echo '<br> $allCarrier =';
        //		$allCarrier = array_column($adapter->getCarrierList( ), 'name', 'id_carrier');
        //var_dump($allCarrier );
        /*
        echo '<br> data products =';
        var_dump($this->products );

        echo '<br> data deliveries =';
        var_dump($data['delivery'] );
        echo '<br>________________________';
        var_dump(_PS_VERSION_ );
        */
        /*
            array(	'product' =>
                    array(	'R00' => 'Colissimo Access France',
                            'R01' => 'Colissimo Expert France',
                         ),
                    'distribution' =>
                    array(	'AVX' => 'Votre colis ....',
                            'REN' => 'Livraison effective',
                         ),
                    'carrier' =>		// not implemented
                    array(	0 => 'MyCarrier',
                            1 => 'Colissimo',
                         ),
                    'delivery' =>
                    array(	0 => array('order'=> '1', 'track'=> 'ABCDEF12', 'step' => '60', 'stepLib' => 'AVX', 'carrier' => '0', 'product' => 'R01', 'insurance' => 234, 'cost' => 15.99),
                            1 => array('order'=> '2', 'track'=> 'ZDF543A2', 'step' => '100','stepLib' => 'REN', 'carrier' => '1', 'product' => 'R00','insurance' => 0, 'cost' => 8.22),
                         )
                )
        */
        foreach( $delivery as $one )
        {
            // reset limit for each iteration
            set_time_limit(22);

            try {
                $one['order'] = (int) $one['order'];

                // better to rely on native methods because of hook::updateOrderStatus and hook::postUpdateOrderStatus
                $orderObject = new \Order( $one['order'], $this->context->employee->id_lang );
                if (! \Validate::isLoadedObject($orderObject) ) {
                    $result['unknown'][] = $one['order'];
                    $orderObject = null;
                    continue;
                }

                $primaryOrder = true;
                // if shipping number is already there, then we have nothing to do
                // either this is not the first feedback for this order, either employee has forced a tracking number
                // this also avoid spamming message for every feedback

                // TODO use OrderCarrier->tracking_number starting 1.8 ? note : setTrackingNumber() already create one
                // PHP Warning: Undefined property: Order::$shipping_number in /shared/httpd/prestashop82/www/modules/expedipro/src/action/Delivery.php on line 153
                if ( ! $cab = ( method_exists($orderObject, 'getShippingNumber') ? $orderObject->getShippingNumber() : $orderObject->shipping_number ) )
                {
                    $this->setTrackingNumber( $one, $orderObject );
                    $this->setMessage( $one, $orderObject );
                    $result['trackingNew'][] = $one['order'];
                }
                elseif ( $cab != $one['track']  )
                {
                    $primaryOrder = false; 			// UseCase : split order
                    if ( (int) $one['step'] <= 11 ) // not efficient, but at least limit spamming message for split order until this stage
                    {
                        $this->setMessage( $one, $orderObject );
                        $result['trackingGrouped'][] = $one['order'];
                    }
                } else {
                    $result['trackingSame'][] = $one['order'];
                }

 //$one['step'] = 10;
                if ( $primaryOrder )
                {
                    $state = $this->getShippingStatus( intval( $one['step'] ) );
                    // UC: no synchro selected in module configuration (or wrong data from Expedipro)
                    if ( null === $state ) {
                        $result['stepIgnored'][] = $one['order'];
                        continue;
                    }
                    $currentState = $orderObject->getCurrentState();
                    // Avoid creating order history events when state does not change
                    if ( $state == (int) $currentState ) { // prefer loose comparaison rather than strict
                        $result['stepSame'][] = $one['order'];
                        continue;
                    }
                    $this->setState( $orderObject, $state, $currentState);
                    $result['stepNew'][] = $one['order'];
                }
            // since 7.2.0 : https://www.php.net/manual/fr/class.error.php
           } catch ( \Error $e) {
//var_dump( "Error".$e->getMessage());
                throw new \Exception( $e->getMessage(), $e->getCode(), $e->getPrevious() );
           } catch ( \Exception $e) {
//var_dump( "Exception".$e->getMessage());

                $result['exception'][] = $e->getFile() . ':' . $e->getLine() . ' ' . $e->getMessage() . ' ' . $e->getTraceAsString() . ' for ' . json_encode($one);
           }
        }
        // feedback to Expedipro
        echo json_encode( $result, JSON_NUMERIC_CHECK | JSON_PARTIAL_OUTPUT_ON_ERROR );
        return $result;
    }


    private function setState(\Order $orderObject, int $newState, int $oldState = null)
    {
        $history = new \OrderHistory();
        $history->id_order = (int) $orderObject->id;
        $history->id_employee = (int) $this->context->employee->id;
        $history->id_order_state =  $newState;
        // no more (int) $this->context->employee->id_lang

        // Gestion du changement d'état avec ou sans gestion des stocks
        try {
            if ( intval( \Configuration::get('EXPEDIPRO_STOCKMANAGEMENT')) ) {
                // changeIdOrderState effectue la gestion des stocks,  l'envoi d'email et l'ajout dans l'historique
                $history->changeStatus( $newState ); // appelle addWithemail() en interne (ou effectue les actions équivalentes)
                // $history->changeIdOrderState( $newState, (int) $orderObject->id);
                // $history->addWithemail(true);  change
            }
            else
            { // degraded approach, in case above one trigger fatal in log
                $history->add(); // Met à jour ps_orders.current_state et ps_order_history and Hook actionObjectOrderHistoryAddAfter mais PAS actionOrderHistoryAddAfter

                // Mode manuel pour éviter les hooks complexes ou si la gestion des stocks n'est pas requise.
                \Hook::exec('actionOrderHistoryAddAfter', [  // 'actionOrderStatusUpdate' est une autre alternative, mais avant le commit du statuts change
                    'newOrderStatus' => $newState,
                    'oldOrderStatus' => $oldState,
                    'id_order' => (int) $orderObject->id,
                ], null, false, true, false, $orderObject->id_shop);
            }
        } catch (\Throwable $t) {
            // \Throwable attrape à la fois les Exceptions et les Erreurs fatales (Error)
            throw new \Exception(
                "Erreur lors du changement d'état : " . $t->getMessage(),
                (int)$t->getCode()
            );
        }
    }



    /**
     * Add a private message for this Order to display parcel details on the order back office page
     *
     * @param array $orderDetail
     * @param \Order $orderObject
     *
     * @return bool
     */
    private function setMessage( array $orderDetail, \Order $orderObject ) :bool
    {

        if ( ! isset($this->products[ $orderDetail['product'] ]) )
            return false;

        if ( ! intval( \Configuration::get('EXPEDIPRO_DELIVERYMESSAGE') ) )
            return true;
//var_dump(  $orderDetail  );
        $messageObject = new \Message();	// OrderMessage if for predefined messages
        $messageObject->message = $this->products[ $orderDetail['product'] ] .
            ( $orderDetail['insurance'] ? ', assuré pour ' . str_replace('.', ',',$orderDetail['insurance']) . '€' : '') .
            ( $orderDetail['cost'] ? ', coût ht = ' . str_replace('.', ',',$orderDetail['cost']) : '') .
            PHP_EOL .
            'Suivi sur ' . \Configuration::get('EXPEDIPRO_DELIVERYTRACKING') . $orderDetail['track'];
        $messageObject->id_order 	= $orderDetail['order'];
        $messageObject->id_cart		= $orderObject->id_cart;
        $messageObject->id_customer	= $orderObject->id_customer;
        $messageObject->id_employee	= $this->context->employee->id;
        $messageObject->private		= 1;
//var_dump(  $messageObject  );
//var_dump(  $messageObject->add()  );
        return (bool) $messageObject->add();
//		$messageObject = null; // reduce mem footprint
    }


    /**
     * Update the Order object with tracking number and Object orderCarrier (PS > 1.5)
     *
     * @param array	$orderDetail
     * @param Order $orderObject
     *
     * @return boolean
     */
    private function setTrackingNumber( array $orderDetail, \Order $orderObject ) :bool
    {
        if ( ! $orderDetail['track'] )
            return false;

        // 8.2   shipping_number 1.6 type isTrackingNumber, supposed to becomes deprecated in 1.6 but still used
//        $orderObject->shipping_number = $orderDetail['track'];
//        $orderObject->update();

//    	if ( method_exists($orderObject,'getIdOrderCarrier') ) {
        if ( ! $idOrderCarrier = $orderObject->getIdOrderCarrier() )
            return false;

        $orderCarrierObject = new \OrderCarrier( $idOrderCarrier );
        $orderCarrierObject->tracking_number = $orderDetail['track'];
        $orderCarrierObject->weight = $orderDetail['weight'];
        if ( intval( \Configuration::get('EXPEDIPRO_DELIVERYCOST') ) ) {
            $orderCarrierObject->shipping_cost_tax_excl = $orderDetail['cost'];
            $orderCarrierObject->shipping_cost_tax_incl = $orderDetail['costWt'] ?: $orderDetail['cost'];
        }
        $orderCarrierObject->update();
//		print_r( $orderCarrierObject->getFields() );
        $orderCarrierObject = null;	// reduce mem footprint

        return true;
    }


    /**
     * @param int|null $expediproStatus
     *
     * @return int|null
     */
    private function getShippingStatus( int $expediproStatus = null)
    {
        if ( ! $expediproStatus )
            return null;

        $previous = null;
        foreach ($this->statusMapping AS $expedipro => $prestashop )
        {
            if ( (int) $expediproStatus === $expedipro )
                return $prestashop;
            if ( (int) $expediproStatus <  $expedipro )
                return $previous;	// if expedipro send a unknown code, don't break and send the closest one
            $previous = $prestashop;
        }
        return null;
    }
}