<!-- Block expediproConfigDelivery -->
<form action="" method="post" name="configDelivery">
	<fieldset style="margin: 10px 0px;">
		<legend>Synchronisation colis</legend>
		<p>
			Avant de remettre le colis au transporteur, votre Prestashop est synchronisé automatiquement.<strong> Choisissez l'état de vos commandes, selon ces 3 étapes d'acheminement</strong> :
		</p>
		<br>
		<table>
			<thead>
			<tr style="background: #d0e5f5;">
				<th>Colis préparé, bientôt remis au transporteur</th>
				<th>Colis en acheminement, suivi disponible</th>
				<th>Colis livré</th>
			</tr>
			</thead>
			<tbody>
			<tr>
				<td>
					<select name="deliveryBefore" tabindex=18 class="attribute_select">
						{foreach from=$config.deliveryBefore key=k item=state }
							<option value="{$k}" {if $state.selected == 1} selected {/if} > {$state.name|escape:'html'} </option>
						{/foreach}
					</select>
				</td>
				<td>
					<select name="deliveryStart" tabindex=18 class="attribute_select">
						{foreach from=$config.deliveryStart key=k item=state }
							<option value="{$k}" {if $state.selected == 1} selected {/if} > {$state.name|escape:'html'} </option>
						{/foreach}
					</select>
				</td>
				<td>
					<select name="deliveryDone" tabindex=18 class="attribute_select">
						{foreach from=$config.deliveryDone key=k item=state }
							<option value="{$k}" {if $state.selected == 1} selected {/if} > {$state.name|escape:'html'} </option>
						{/foreach}
					</select>
				</td>
			</tr>
			</tbody>
		</table>
		<br>
		<p>
			La fiche commande peut aussi être mise à jour avec ceci :<br><br>
			&nbsp;&nbsp;<input type="checkbox" value="1" {if $config.deliveryMessage.selected == 1} checked="checked" {/if} name="deliveryMessage"> Un message <strong>privé</strong> (non visible par votre client) avec le résumé de l'expédition (numéro de suivi, date, etc),<br>
			&nbsp;&nbsp;<input type="checkbox" value="1" {if $config.deliveryCost.selected == 1} checked="checked" {/if} name="deliveryCost"> Le coût d'expédition sera renseigné dans la commande.<br>
		</p>
		<br>
		<p>
			Prestashop bug parfois avec la gestion des stocks, lorsque l'état de la commande passe à <strong>Expédié</strong> :<br>
			&nbsp;&nbsp;<input type="checkbox" value="1" {if $config.stockManagement.selected == 1} checked="checked" {/if} name="stockManagement"> Activer la gestion des stocks par Prestashop, lors du passage à l'état <strong>Expédié</strong><br>
			Ce bug Prestashop empêche la mise à jour du statut à "Expédié"; par défaut, nous désactivons donc cette option.
		</p>
		<br>
		<input type="submit" name="submitConfigDelivery" value="&nbsp;&nbsp;&nbsp;Valider ces options&nbsp;&nbsp;&nbsp;"/><br/>
	</fieldset>
</form>
<!-- /Block expediproConfigDelivery -->
