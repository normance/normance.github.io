<!-- Block expediproConfigCarrier -->
	<form action="" method="post" name="configCarrier">
		<fieldset style="margin: 10px 0px;">
			<legend>Transport</legend>
			<p>
				<strong>Quels transporteurs voulez-vous exporter ?</strong>
			</p>		
			<p>
			{foreach from=$config.orderCarrier key=k item=carrier}
				<input type="checkbox" value="{$k}" {if $carrier.selected == 1} checked="checked" {/if} name="orderCarrier[]"> &nbsp;{$carrier.name|escape:'html'}<br/>
			{/foreach}
			</p>
			<br/>
			<input type="submit" name="submitConfigCarrier" value="&nbsp;&nbsp;&nbsp;Valider ces transporteurs&nbsp;&nbsp;&nbsp;"/><br/>
		</fieldset>
	</form>
<!-- /Block expediproConfigCarrier -->