<!-- Block diagnose -->
	<form action="" method="post" name="configDiagnose">
		<fieldset style="margin: 10px 0px;">
			<legend>Diagnostic du module </legend>
			<div style="background-color:#f7f7f7;padding:10px;border:1px solid #DDD">
                <p>Accès URL (fiabilité 50%):
                    <span {if $config.diagnoseUrl === "OK"} style="color:forestgreen" {else} style="color:darkred" {/if} > {$config.diagnoseUrl|escape:'html'} </span>
                </p>
                <p>Commandes exportables :
                    <span {if $config.diagnoseOrder === "OK"} style="color:forestgreen" {else} style="color:darkred" {/if} > {$config.diagnoseOrder|escape:'html'} </span>
                </p>
            </div>
		</fieldset>
	</form>
<!-- /Block diagnose -->