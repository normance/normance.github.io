<!-- Block expediproConfigUrl -->
	<form action="" method="post" name="configUrl">
		<fieldset style="margin: 10px 0px;">
			<legend>Paramètres pour créer une source de données dans Expedipro</legend>
			<p>
				<strong>Suggestion de description :</strong><br>
			</p>
			<div style="background-color:#f7f7f7;padding:10px;border:1px solid #DDD">
				<span style="font-family:Courier">{$config.expediproCanal}</span>
			</div>
			<div style="text-align: right;">
				<span id="canal_copy" style="background-color:#e6e8e7; padding:3px; cursor: default;">Copier cette description</span>
			</div>
			<p>
				<strong>1- Url : (adaptez avec https si besoin)</strong>
			</p>
			<div style="background-color:#f7f7f7;padding:10px;border:1px solid #DDD">
				<span style="font-family:Courier">{$config.expediproUrl}</span>
			</div>
			<div style="text-align: right;">
				<span id="url_copy" style="background-color:#e6e8e7; padding:3px; cursor: default;">Copier cette URL</span>
			</div>
			<p>
				<strong>2- Clé (ou token) :</strong><br>
			</p>
			<p>
				L'accès aux détails de vos commandes est protégé par cette clé, ne la communiquez pas à des tiers.<br>
				Si elle est compromise, vous pouvez la <input type="submit" name="submitConfigUrl" value="&nbsp;&nbsp;&nbsp;Regénérer&nbsp;&nbsp;&nbsp;"/>
				 puis la copier dans Expedipro.
			</p>
			<div style="background-color:#f7f7f7;padding:10px;border:1px solid #DDD">
				<span style="font-family:Courier">{$config.expediproToken}</span>
			</div>
			<div style="text-align: right;">
				<span id="token_copy" style="background-color:#e6e8e7; padding:3px; cursor: default;">Copier cette clé</span>
			</div>
<!--
			<p>
				<strong>3- Version :</strong>
			</p>
			<div style="background-color:#f7f7f7;padding:10px;border:1px solid #DDD">
				<span style="font-family:Courier">{$config.expediproVersion}</span>
			</div>
			<div style="text-align: right;">
				<span id="version_copy" style="background-color:#e6e8e7; padding:3px; cursor: default;">Copier cette version</span>
			</div>
-->
			<h3 style="margin: 10px 0px;">Note de confidentialité</h3>
			<p>
				Nous avons sécurisé l'accès aux commandes de votre Prestashop : les accès sont controlés par la clé ci-dessus et les échanges via internet sont chiffrés si votre site utilise httpS.<br>
				Afin de mettre à jour les statuts des commandes suite à leur expédition, le profil utilisateur logisticien "expedipro" a été créé. Cependant nul ne peut l'utiliser pour se connecter puisqu'il est inactif et que son mot de passe est inconnu (même de nous !).
			</p>
		</fieldset>
	</form>
<script type="text/javascript">
document.getElementById("canal_copy")
	.addEventListener("click", function( ) {
		window.prompt("Copier cette description dans le presse-papier avec Ctrl+C", "{$config.expediproCanal}" );
});
document.getElementById("url_copy")
	.addEventListener("click", function( ) {
  		window.prompt("Copier cette URL dans le presse-papier avec Ctrl+C", "{$config.expediproUrl}" );
	});
document.getElementById("token_copy")
.addEventListener("click", function( ) {
		window.prompt("Copier cette clé dans le presse-papier avec Ctrl+C", "{$config.expediproToken}" );
});
</script>
<!-- /Block expediproConfigUrl -->