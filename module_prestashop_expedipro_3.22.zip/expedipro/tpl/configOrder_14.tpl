<!-- Block expediproConfigOrder -->
	<form action="" method="post" name="configOrder">
		<fieldset style="margin: 10px 0px;">
			<legend>Commande</legend>
			<p>
				<strong>Sur la <em>période concernée</em>, seront exportées les commande dans l'un de ces états :</strong>
			</p>		
			<p>
			{foreach from=$config.orderState key=k item=state}
				<input type="checkbox" value="{$k}" {if $state.selected == 1} checked="checked" {/if} name="orderState[]"> &nbsp;{$state.name|escape:'html'}<br/>
			{/foreach}
			</p>
			<br/>
	
			<input type="submit" name="submitConfigOrder" value="&nbsp;&nbsp;&nbsp;Valider ces états&nbsp;&nbsp;&nbsp;"/><br/>
		</fieldset>
	</form>
<!-- /Block expediproConfigOrder -->