<!-- Block expediproConfigHeader -->
	<h2>{$config.expediproTitle}</h2> <!--  no escape because of 1.4 title -->
	<fieldset>
		<legend>Présentation</legend>
		<p>
		Expedipro est une solution SAAS dématérialisée permettant aux e-commerçants d'optimiser les expéditions de colis en France et à l'international.<br />
		Grâce à ce module, vous exportez toutes vos commandes payées vers notre solution.
		</p>
		<p>
		Depuis le site expedipro.com vous pouvez ainsi <strong>expédier immédiatement</strong> vos colis sans ressaisir les adresses de vos destinataires.<br />
		Ensuite, le numéro de suivi ainsi que l'état de livraison de vos commandes sont <strong>automatiquement mis à jour</strong>. 
		</p>
		<br/>
		<div style="background-color:#bfbfbf;text-align:center;border:1px solid #DDD">
			<a href="http://www.expedipro.com" target="_blank">
				<img src="http://www.expedipro.com/images/modPrestashop_howto.png" alt="Solution Expedipro" border="0" />
			</a>
		</div>
	</fieldset>
<!-- /Block expediproConfigHeader -->