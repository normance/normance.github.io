<?php
namespace Expedipro\Module\Action;

/**
 * 2026 Expedipro
 *
 * @author Expedipro SAS <contact@expedipro.com>
 * @copyright Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */
trait ContextCron
{
    /**
     * Initialise un Context complet (Langue, Employé, Traducteur), singleton, utilisable en CRON.
     *
     * @return \Context
     */
    public function setContextCron()
    {
        // keyword used to bind a variable from a global scope into a local scope
        global $kernel;

        $context = \Context::getContext();
        try {
            // 1. Définition de la Boutique (Shop)
            if ( ! $context->shop OR ! $context->shop->id ) {
                $idShop = (int) (\Configuration::get('PS_SHOP_DEFAULT') ?: 1);
                $context->shop = new \Shop( $idShop );
                \Shop::setContext(\Shop::CONTEXT_SHOP, $idShop);
            }

            // 2. Définition de la Langue
            if ( ! $context->language OR ! $context->language->id ) {
                $context->language = new \Language(
                    (int) ( \Configuration::get('PS_LANG_DEFAULT') ?: 1 )
                );
            }

            // 3. Initialisation de l'Employé
            if ( ! $context->employee OR ! $context->employee->id ) {
                $context->employee = new \Employee(
                    (int) ( \Configuration::get('EXPEDIPRO_EMPLOYEE') ?: \Configuration::get('PS_ONSALE_RECOVERY_EMPLOYEE') ?: 1 )
                );
            }

            // 4. Démarrage du Container Symfony (Version PrestaShop 8 & 9)
            if (!$kernel) {
                // Chemin moderne PrestaShop 9 / PrestaShop 8
                if (file_exists(_PS_ROOT_DIR_ . '/src/PrestaShop/PrestaShop/Kernel.php')) {
                    // On utilise le sélecteur de Kernel natif de PrestaShop
                    require_once _PS_ROOT_DIR_ . '/app/AppKernel.php'; // Ce fichier charge l'autoloader et l'AppKernel global
                    $kernel = new \AppKernel('prod', false);
                    $kernel->boot();
                }
                // Rétrocompatibilité très ancienne au cas où (PS 1.7)
                elseif (file_exists(_PS_ROOT_DIR_ . '/app/AppKernel.php')) {
                    require_once _PS_ROOT_DIR_ . '/app/AppKernel.php';
                    $kernel = new \AppKernel('prod', false);
                    $kernel->boot();
                }
            }

            // 5. Initialisation du Translator via le Kernel booted
            if ( $kernel instanceof \Symfony\Component\HttpKernel\KernelInterface) {
                $container = $kernel->getContainer();
                if ($container && $container->has('translator')) {
                    $translator = $container->get('translator');
                    $context = $this->setTranslator($context, $translator);
                }
            }

        } catch (\Throwable $e) {
            // "Cannot instantiate abstract class AppKernel" in PS9
            // please uncomment the following line for debug:
            // \PrestaShopLogger::addLog('Expedipro Cron Error: ' . $e->getMessage());
        }

        return $context;
    }

    private function setTranslator( \Context $context, $translator )
    {
        if (method_exists($context, 'setTranslator') ) // from 1.7.7+
            $context->setTranslator( $translator );
        else {
            // < 1.7.7 On contourne l'absence de setTranslator() via la Réflexion
            $reflection = new \ReflectionProperty(get_class($context), 'translator');
            $reflection->setAccessible(true);
            $reflection->setValue($context, $translator);

            // nice to have define locale pour que les traductions correspondent à la langue choisie à l'étape 2
            if ($context->language && method_exists($context->language, 'getLocale')) {
                $contextTranslator = $context->getTranslator();
                if ($contextTranslator && method_exists($contextTranslator, 'setLocale')) {
                    $contextTranslator->setLocale($context->language->getLocale());
                }
            }
        }
        return $context;
    }
}