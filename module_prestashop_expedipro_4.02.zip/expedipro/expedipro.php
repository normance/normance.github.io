<?php
/**
 * 2026 Expedipro
 *
 *  @author Expedipro SAS <contact@expedipro.com>
 *  @copyright  Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */

if (!defined('_PS_VERSION_'))
    exit;

// load PSR-4 namespaces
require_once dirname(__FILE__).'/vendor/autoload.php';

class Expedipro extends Module
{
    public function __construct()
    {
        $this->name = 'expedipro';
        $this->tab  = 'shipping_logistics';
        $this->author  = 'Expedipro (officiel)';
        $this->version = '4.02';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = ['min' => '8.1', 'max' => '99'];

        parent::__construct();

        $this->displayName = ' Expedipro.com : simplifiez-vous l\'expédition';
        $this->description = 'L\'expédition de vos colis aux tarifs pro, en quelques clics, avec synchronisation automatique de l\'état de livraison.';
        $this->confirmUninstall = 'Voulez-vous désinstaller le module Expedipro ?';

        $this->context = \Context::getContext(); // defined in ModuleCore
    }

    public function install()
    {
        // because of AdminModulesController->postProcessCallback()
        require_once( dirname(__FILE__) . '/vendor/autoload.php');

        // todo: at update process, DOES version is updated if done here rather than in __construct() ?
        \Configuration::updateValue('EXPEDIPRO_VERSION', $this->version);
        \Configuration::updateValue('EXPEDIPRO_TITLE',	$this->displayName);

        $mapper = new Expedipro\Module\Action\Mapper( $this->context );
        // we defined a UNACTIVE employee for updating status order
        // note that password is random and not compliant with ps, so no possible login
        if ( $oldEmployee = $mapper->getExpediproEmployee('support@expedipro.com') )
        {	// in case of delete/reinstall, employee still exists
            \Configuration::updateValue('EXPEDIPRO_EMPLOYEE', $oldEmployee ) ;
        } else {
            if ( ! $newEmployee = $mapper->setExpediproEmployee('support@expedipro.com') )
                $newEmployee = 1; // for sure this one exist
            \Configuration::updateValue('EXPEDIPRO_EMPLOYEE', $newEmployee ) ;
        }

        require_once( dirname(__FILE__) . '/Config.php');
        return parent::install()
            && \Configuration::updateValue('EXPEDIPRO_TOKEN', ( new Config( $this->context) )->randomString(32) ) // this is not url?token= from prestashop
            && \Configuration::updateValue('EXPEDIPRO_SEPARATOR', '|')
            && \Configuration::updateValue('EXPEDIPRO_ORDERSTATE', '2|3')   		// paid and preparation
            && \Configuration::updateValue('EXPEDIPRO_ORDERCARRIER', '')   			// all carriers by default
            && \Configuration::updateValue('EXPEDIPRO_DELIVERYBEFORE', '3')   	    // en cours de préparation
            && \Configuration::updateValue('EXPEDIPRO_DELIVERYSTART', '4')   	    // transport
            && \Configuration::updateValue('EXPEDIPRO_DELIVERYDONE', '5' )          // livré
            && \Configuration::updateValue('EXPEDIPRO_DELIVERYCOST', '1' )          // update shipping cost at first delivery synchronization
            && \Configuration::updateValue('EXPEDIPRO_DELIVERYMESSAGE', '1' )       // create private message at first delivery synchronization
            && \Configuration::updateValue('EXPEDIPRO_STOCKMANAGEMENT', '0' )       // use stockmanagement, 0 to bypass it
            && \Configuration::updateValue('EXPEDIPRO_DELIVERYTRACKING', 'www.expedipro.com/support/suivi?id=');
    }


    public function uninstall()
    {
//		if ( ! parent::uninstall()) {
//			Db::getInstance()->Execute('DELETE FROM `'._DB_PREFIX_.'mymodule`');
//			Db::getInstance()->Execute('DELETE FROM `'._DB_PREFIX_.'authorization_role` WHERE slug LIKE ("ROLE_MOD_MODULE_EXPEDIPRO_%")' );
//      }
        // not sure we must delete EXPEDIPRO employee in case it is just an delete/reinstall of the module
        // we would lost employee name in history status of orders

        return parent::uninstall()
            && \Configuration::deleteByName('EXPEDIPRO_TITLE')
            && \Configuration::deleteByName('EXPEDIPRO_VERSION')
            && \Configuration::deleteByName('EXPEDIPRO_TOKEN')
            && \Configuration::deleteByName('EXPEDIPRO_SEPARATOR')
            && \Configuration::deleteByName('EXPEDIPRO_ORDERSTATE')
            && \Configuration::deleteByName('EXPEDIPRO_ORDERCARRIER')
            && \Configuration::deleteByName('EXPEDIPRO_DELIVERYTRACKING')
            && \Configuration::deleteByName('EXPEDIPRO_DELIVERYCOST')
            && \Configuration::deleteByName('EXPEDIPRO_DELIVERYBEFORE')
            && \Configuration::deleteByName('EXPEDIPRO_DELIVERYSTART')
            && \Configuration::deleteByName('EXPEDIPRO_DELIVERYDONE')
            && \Configuration::deleteByName('EXPEDIPRO_DELIVERYMESSAGE')
            && \Configuration::deleteByName('EXPEDIPRO_STOCKMANAGEMENT')
            && \Configuration::deleteByName('EXPEDIPRO_EMPLOYEE')
            && \Configuration::deleteByName('EXPEDIPRO_ORDERTRACKING')
            && \Configuration::deleteByName('EXPEDIPRO_ORDERFROM')
            && \Configuration::deleteByName('EXPEDIPRO_ORDERWEIGHT') ;
    }

    /**
     * Prestashop magic: if exists, display the "configure" link
     * AdminModulesControllerCore() class look for getContent() in this class when doing ?controller=AdminModules&configure=expedipro
     *
     * @return string form
     */
    public function getContent()
    {
        // because of AdminModulesController->postProcessCallback()
        require_once( dirname(__FILE__) . '/Config.php');
        $config = new Config( );

        // Important getContent() is called TWO times :
        // to get the configuration page
        // after POST of configuration change
        $output = $config->configPost(); // first step : save change if we are in submit mode

//		global $smarty;
        $this->context->smarty->assign('config',[
            'expediproToken'=> \Configuration::get('EXPEDIPRO_TOKEN'),
            'expediproUrl'	=> _PS_BASE_URL_SSL_. __PS_BASE_URI__. 'modules/expedipro/controller.php',
            'expediproCanal'=> str_replace(' ', '', \Configuration::get('PS_SHOP_NAME') ) ,	// removing spaces help using this as an id
            'expediproTitle'=> \Configuration::get('EXPEDIPRO_TITLE'),
            'expediproVersion'=> round( \Configuration::get('EXPEDIPRO_VERSION'), 1, PHP_ROUND_HALF_DOWN),
            'deliveryCost'	=> ['selected' => intval( \Configuration::get('EXPEDIPRO_DELIVERYCOST') ) ],
            'deliveryMessage'=>['selected' => intval( \Configuration::get('EXPEDIPRO_DELIVERYMESSAGE') ) ],
            'stockManagement'=>['selected' => intval( \Configuration::get('EXPEDIPRO_STOCKMANAGEMENT') ) ],
            'orderState'	=> $config->getStateList( \Configuration::get('EXPEDIPRO_ORDERSTATE'), 'sendable' ),
            'deliveryBefore'=> $config->getStateList( \Configuration::get('EXPEDIPRO_DELIVERYBEFORE'), 'deliveryBefore' ),
            'deliveryStart'	=> $config->getStateList( \Configuration::get('EXPEDIPRO_DELIVERYSTART'), 'deliveryStart' ),
            'deliveryDone'	=> $config->getStateList( \Configuration::get('EXPEDIPRO_DELIVERYDONE'), 'deliveryDone' ),
            'orderCarrier'	=> $config->getCarrierList( \Configuration::get('EXPEDIPRO_ORDERCARRIER') ),
            'diagnoseOrder' => $config->diagnoseOrder(),
            'diagnoseUrl'   => $config->diagnoseUrl( _PS_BASE_URL_SSL_. '/modules/expedipro/controller.php' )
            ]
        );

        // PHP_VERSION (chaîne de caractères) => "major.minor.release[extra]"
        $output .= $this->display(__FILE__.'expedipro/expedipro.php','tpl/configHeader_9.tpl');
        $output .= $this->display(__FILE__.'expedipro/expedipro.php','tpl/configConnection_9.tpl');
        $output .= $this->display(__FILE__.'expedipro/expedipro.php','tpl/configCarrier_9.tpl');
        $output .= $this->display(__FILE__.'expedipro/expedipro.php','tpl/configOrder_9.tpl');
        $output .= $this->display(__FILE__.'expedipro/expedipro.php','tpl/configDelivery_9.tpl');
        $output .= $this->display(__FILE__.'expedipro/expedipro.php','tpl/configDiagnose_9.tpl');
        //$output .= $this->display(__FILE__.'expedipro/expedipro.php','tpl/configFooter_9.tpl');

        return $output;
    }
}
?>