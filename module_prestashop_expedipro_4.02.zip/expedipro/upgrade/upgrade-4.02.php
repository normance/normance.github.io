<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * fichier utilise "." alors que la function "_"
 *  les 2 doivent désigner la nouvelle version du module
 *
 * @param $module
 * @return mixed
 */
function upgrade_module_4_02($module)
{
    // Cette ligne mettra à jour la version en BDD lors de l'upgrade automatique
    return \Configuration::updateValue('EXPEDIPRO_VERSION', $module->version);
}