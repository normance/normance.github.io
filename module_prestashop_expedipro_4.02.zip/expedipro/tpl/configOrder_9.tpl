<!-- Block expediproConfigOrder -->
<form action="" method="post" name="configOrder" class="form-horizontal">
	<div class="panel">
		<div class="panel-heading">
			<i class="icon-shopping-cart"></i> Commande
		</div>

		<div class="form-wrapper">
			<div class="form-group">
				<label class="control-label font-weight-bold mb-3">
					Sur la <em>période concernée</em>, seront exportées les commandes dans l'un de ces états :
				</label>

				<div class="col-lg-12">
					<div class="row">
						{foreach from=$config.orderState key=k item=state}
							<div class="col-md-6 col-lg-4 mb-2">
								<div class="checkbox">
									<label for="state_{$k}">
										<input type="checkbox"
										       id="state_{$k}"
										       value="{$k}"
										       {if $state.selected == 1}checked="checked"{/if}
										       name="orderState[]">
										<span class="ml-2">{$state.name|escape:'html':'UTF-8'}</span>
									</label>
								</div>
							</div>
						{/foreach}
					</div>
				</div>
			</div>
		</div>

		<div class="panel-footer">
			<button type="submit" name="submitConfigOrder" class="btn btn-default button pull-right btn-primary">
				<i class="process-icon-save"></i> Valider ces états
			</button>
		</div>
	</div>
</form>
<!-- /Block expediproConfigOrder -->