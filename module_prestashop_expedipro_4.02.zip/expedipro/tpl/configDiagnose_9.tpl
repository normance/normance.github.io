<!-- Block expediproConfigDiagnose -->
<form action="" method="post" name="configDiagnose" class="form-horizontal">
    <div class="panel">
        <div class="panel-heading">
            <i class="icon-wrench"></i> Diagnostic du module
        </div>
        <div class="form-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Ligne Diagnostic 1 : Accès URL -->
                    <div class="d-flex justify-content-between align-items-center p-3 mb-2 border rounded bg-light">
                      <span>
                          <strong>Accès URL</strong>
                          <small class="text-muted block-control">(fiabilité du test : 50%)</small> :
                      </span>
                      {if $config.diagnoseUrl === "OK"} <span class="badge badge-success px-3 py-2"><i class="icon-check"></i> {$config.diagnoseUrl|escape:'html':'UTF-8'}</span>
                      {else} <span class="badge badge-danger px-3 py-2"><i class="icon-remove"></i> {$config.diagnoseUrl|escape:'html':'UTF-8'}</span>
                      {/if}
                    </div>

                    <!-- Ligne Diagnostic 2 : Commandes exportables -->
                    <div class="d-flex justify-content-between align-items-center p-3 border rounded bg-light">
                        <span><strong>Commandes exportables</strong> :</span>
                        {if $config.diagnoseOrder === "OK"}<span class="badge badge-success px-3 py-2"><i class="icon-check"></i> {$config.diagnoseOrder|escape:'html':'UTF-8'}</span>
                        {else} <span class="badge badge-danger px-3 py-2"><i class="icon-remove"></i> {$config.diagnoseOrder|escape:'html':'UTF-8'}</span>
                        {/if}
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<!-- /Block expediproConfigDiagnose -->