<!-- Block expediproConfigDelivery -->
<form action="" method="post" name="configDelivery" class="form-horizontal">
	<div class="panel">
		<div class="panel-heading">
			<i class="icon-refresh"></i> Synchronisation colis
		</div>

		<div class="form-wrapper">
			<p class="alert alert-info">
				Avant de remettre le colis au transporteur, votre PrestaShop est synchronisé automatiquement.
				<strong>Choisissez l'état de vos commandes selon ces 3 étapes d'acheminement :</strong>
			</p>

			<div class="row mt-4 mb-4">

				<div class="col-md-4 mb-3">
					<div class="form-group px-2">
						<label class="control-label font-weight-bold text-left mb-2" style="width:100%; text-align:left;">
							1. Colis préparé, bientôt remis au transporteur
						</label>
						<select name="deliveryBefore" tabindex="18" class="form-control custom-select">
							{foreach from=$config.deliveryBefore key=k item=state}
								<option value="{$k}" {if $state.selected == 1}selected{/if}>{$state.name|escape:'html':'UTF-8'}</option>
							{/foreach}
						</select>
					</div>
				</div>

				<div class="col-md-4 mb-3">
					<div class="form-group px-2">
						<label class="control-label font-weight-bold text-left mb-2" style="width:100%; text-align:left;">
							2. Colis en acheminement, suivi disponible
						</label>
						<select name="deliveryStart" tabindex="18" class="form-control custom-select">
							{foreach from=$config.deliveryStart key=k item=state}
								<option value="{$k}" {if $state.selected == 1}selected{/if}>{$state.name|escape:'html':'UTF-8'}</option>
							{/foreach}
						</select>
					</div>
				</div>

				<div class="col-md-4 mb-3">
					<div class="form-group px-2">
						<label class="control-label font-weight-bold text-left mb-2" style="width:100%; text-align:left;">
							3. Colis livré
						</label>
						<select name="deliveryDone" tabindex="18" class="form-control custom-select">
							{foreach from=$config.deliveryDone key=k item=state}
								<option value="{$k}" {if $state.selected == 1}selected{/if}>{$state.name|escape:'html':'UTF-8'}</option>
							{/foreach}
						</select>
					</div>
				</div>

			</div>

			<hr>

			<div class="form-group mt-4">
				<label class="control-label font-weight-bold mb-2">Mise à jour de la fiche commande :</label>
				<div class="col-lg-12">
					<div class="checkbox mb-2">
						<label for="deliveryMessage">
							<input type="checkbox" id="deliveryMessage" value="1" {if $config.deliveryMessage.selected == 1}checked="checked"{/if} name="deliveryMessage">
							<span class="ml-2">Ajouter un message <strong>privé</strong> (non visible par votre client) avec le résumé de l'expédition (numéro de suivi, date, etc.).</span>
						</label>
					</div>
					<div class="checkbox">
						<label for="deliveryCost">
							<input type="checkbox" id="deliveryCost" value="1" {if $config.deliveryCost.selected == 1}checked="checked"{/if} name="deliveryCost">
							<span class="ml-2">Renseigner le coût d'expédition réel dans la commande.</span>
						</label>
					</div>
				</div>
			</div>

			<hr>

			<div class="form-group">
				<label class="control-label font-weight-bold text-danger mb-2">
					<i class="icon-exclamation-triangle"></i> Gestion des stocks PrestaShop :
				</label>
				<div class="col-lg-12">
					<p class="help-block text-muted small mb-2">
						PrestaShop rencontre parfois des dysfonctionnements avec la gestion des stocks lorsque l'état de la commande passe à <strong>Expédié</strong> (ce qui peut bloquer le changement de statut). Par défaut, nous vous conseillons de laisser cette option désactivée.
					</p>
					<div class="checkbox">
						<label for="stockManagement">
							<input type="checkbox" id="stockManagement" value="1" {if $config.stockManagement.selected == 1}checked="checked"{/if} name="stockManagement">
							<span class="ml-2 font-weight-bold">Activer malgré tout la gestion des stocks par PrestaShop lors du passage à l'état "Expédié"</span>
						</label>
					</div>
				</div>
			</div>

		</div>

		<div class="panel-footer">
			<button type="submit" name="submitConfigDelivery" class="btn btn-default button pull-right btn-primary">
				<i class="process-icon-save"></i> Valider ces options
			</button>
		</div>
	</div>
</form>
<!-- /Block expediproConfigDelivery -->
