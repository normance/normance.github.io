<!-- Block expediproConfigUrl -->
<form action="" method="post" name="configUrl" class="form-horizontal">
	<div class="panel">
		<div class="panel-heading">
			<i class="icon-cogs"></i> Paramètres pour créer une source de données dans Expedipro
		</div>

		<div class="form-wrapper">

			<div class="form-group row">
				<label class="control-label col-lg-3 font-weight-bold">Suggestion de description :</label>
				<div class="col-lg-9">
					<div class="input-group">
						<input type="text" class="form-control code" readonly value="{$config.expediproCanal|escape:'html':'UTF-8'}" id="expediproCanal">
						<div class="input-group-append">
							<button type="button" class="btn btn-default btn-outline-secondary" onclick="copyToClipboard('expediproCanal')">Copier</button>
						</div>
					</div>
				</div>
			</div>

			<div class="form-group row mt-3">
				<label class="control-label col-lg-3 font-weight-bold">1- Url : (adaptez avec https si besoin)</label>
				<div class="col-lg-9">
					<div class="input-group">
						<input type="text" class="form-control code" readonly value="{$config.expediproUrl|escape:'html':'UTF-8'}" id="expediproUrl">
						<div class="input-group-append">
							<button type="button" class="btn btn-default btn-outline-secondary" onclick="copyToClipboard('expediproUrl')">Copier</button>
						</div>
					</div>
				</div>
			</div>

			<div class="form-group row mt-3">
				<label class="control-label col-lg-3 font-weight-bold">2- Clé (ou token) :</label>
				<div class="col-lg-9">
					<p class="help-block text-muted small">
						L'accès aux détails de vos commandes est protégé par cette clé, ne la communiquez pas à des tiers.<br>
						Si elle est compromise, vous pouvez la modifier ici :
						<button type="submit" name="submitConfigUrl" class="btn btn-warning btn-sm ml-2">Regénérer la clé</button>
					</p>
					<div class="input-group mt-2">
						<input type="text" class="form-control code" readonly value="{$config.expediproToken|escape:'html':'UTF-8'}" id="expediproToken">
						<div class="input-group-append">
							<button type="button" class="btn btn-default btn-outline-secondary" onclick="copyToClipboard('expediproToken')">Copier</button>
						</div>
					</div>
				</div>
			</div>

			<hr>

			<div class="alert alert-info mt-4">
				<h4 class="alert-heading"><i class="icon-shield"></i> Note de confidentialité</h4>
				<p class="mb-0 small">
					Nous avons sécurisé l'accès aux commandes de votre Prestashop : les accès sont contrôlés par la clé ci-dessus et les échanges via internet sont chiffrés si votre site utilise HTTPS.<br>
					Afin de mettre à jour les statuts des commandes suite à leur expédition, le profil utilisateur logisticien "expedipro" a été créé. Cependant nul ne peut l'utiliser pour se connecter puisqu'il est inactif et que son mot de passe est inconnu.
				</p>
			</div>

		</div>
	</div>
</form>

<script type="text/javascript">
	function copyToClipboard(elementId) {
		var copyText = document.getElementById(elementId);
		copyText.select();
		copyText.setSelectionRange(0, 99999); /* Pour les mobiles */

		if (navigator.clipboard) {
			navigator.clipboard.writeText(copyText.value).then(function() {
				alert("Copié dans le presse-papier !");
			});
		} else {
			// Fallback pour les vieux navigateurs
			document.execCommand("copy");
			alert("Copié dans le presse-papier !");
		}
	}
</script>
<!-- /Block expediproConfigUrl -->