<!-- Block expediproConfigHeader -->
<div class="page-head-tabs">
	<h2 class="page-title">{$config.expediproTitle}</h2>
</div>

<div class="panel">
	<div class="panel-heading">
		<i class="icon-info-sign"></i> Présentation
	</div>

	<div class="form-wrapper">
		<div class="row">
			<div class="col-md-7 col-lg-8">
				<p class="lead">
					Expedipro est une solution SaaS dématérialisée permettant aux e-commerçants d'optimiser les expéditions de colis en France et à l'international.
				</p>
				<p>
					Grâce à ce module, vous exportez toutes vos commandes payées vers notre solution.
				</p>
				<p>
					Depuis le site <a href="https://www.expedipro.com" target="_blank" class="text-primary font-weight-bold">expedipro.com</a>, vous pouvez ainsi <strong>expédier immédiatement</strong> vos colis sans ressaisir les adresses de vos destinataires.<br />
					Ensuite, le numéro de suivi ainsi que l'état de livraison de vos commandes sont <strong>automatiquement mis à jour</strong>.
				</p>
			</div>

			<div class="col-md-5 col-lg-4 text-center mt-3 mt-md-0">
				<div class="p-3 border rounded bg-light d-inline-block">
					<a href="https://www.expedipro.com" target="_blank">
						<img src="https://www.expedipro.com/images/modPrestashop_howto.png" alt="Solution Expedipro" class="img-fluid border-0" style="max-height: 150px; width: auto;" />
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- /Block expediproConfigHeader -->