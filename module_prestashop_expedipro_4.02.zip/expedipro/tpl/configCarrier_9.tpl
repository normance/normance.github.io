<!-- Block expediproConfigCarrier -->
<form action="" method="post" name="configCarrier" class="form-horizontal">
	<div class="panel">
		<div class="panel-heading">
			<i class="icon-truck"></i> Transport
		</div>

		<div class="form-wrapper">
			<div class="form-group">
				<label class="control-label font-weight-bold mb-3">
					Quels transporteurs voulez-vous exporter ?
				</label>

				<div class="col-lg-12">
					<div class="row">
						{foreach from=$config.orderCarrier key=k item=carrier}
							<div class="col-md-6 col-lg-4 mb-2">
								<div class="checkbox">
									<label for="carrier_{$k}">
										<input type="checkbox" id="carrier_{$k}" value="{$k}" name="orderCarrier[]"
											{if $carrier.selected == 1}checked="checked"{/if} >
										<span class="ml-2">{$carrier.name|escape:'html':'UTF-8'}</span>
									</label>
								</div>
							</div>
						{/foreach}
					</div>
				</div>
			</div>
		</div>

		<div class="panel-footer">
			<button type="submit" name="submitConfigCarrier" class="btn btn-default button pull-right btn-primary">
				<i class="process-icon-save"></i> Valider ces transporteurs
			</button>
		</div>
	</div>
</form>
<!-- /Block expediproConfigCarrier -->