<?php
/**
* 2014 Expedipro
*
*  @author Expedipro SAS <contact@expedipro.com>
*  @copyright  2014 Expedipro SAS
*  International Registered Trademark & Property of Expedipro SAS
*/

use PrestaShop\PrestaShop\Core;
use Expedipro\Module\Action;    // for diagnoseOrder(), setContextCron()

// required class for managing config/setting in the Prestashop back office (i.e. not cron)
class Config extends Module
{
    use Action\ContextCron;

    protected	$carrierList = [],	// avoid several db access
            	$stateList = [],	// avoid several db access
                $carrierDbName,     // since db change given version
                $context;

	// DI of context
	public function __construct( $context = null) {
        $this->context = $context ?? $this->setContextCron();
	}


	/**
	 * Handle the validation of config <form>
	 *
	 * @return	string	error messages
	 */
	public function configPost()
	{
		// Do NOT named submit button "configure" otherwise submit would trigger "module not found"

		// POST processing using submit name
		if( \Tools::isSubmit('submitConfigUrl') )
            $this->updateMe( 'EXPEDIPRO_TOKEN', null,  $this->randomString(32) );

    	// Because of html constraints, orderCarrier must always be handled
		if ( \Tools::isSubmit('submitConfigCarrier') )
	        $this->updateMe( 'EXPEDIPRO_ORDERCARRIER', 'carrier', \Tools::getValue('orderCarrier') ?: null ); // unchecked box (multi choice) need to be unset

        // Because of html constraints, orderState must always be handled
		if ( \Tools::isSubmit('submitConfigOrder') )
            $this->updateMe( 'EXPEDIPRO_ORDERSTATE', 'state', \Tools::getValue('orderState') ?: null ); // unchecked box (multi choice) need to be unset

        if ( \Tools::isSubmit('submitConfigDelivery') )
        {
            $this->updateMe( 'EXPEDIPRO_DELIVERYBEFORE', 'state',\Tools::getValue('deliveryBefore') ?: null );  // empty (no synchro) is changed to null
            $this->updateMe( 'EXPEDIPRO_DELIVERYSTART', 'state',\Tools::getValue('deliveryStart') ?: null );
            $this->updateMe( 'EXPEDIPRO_DELIVERYDONE', 'state',\Tools::getValue('deliveryDone') ?: null );
            $this->updateMe( 'EXPEDIPRO_DELIVERYMESSAGE', null, intval(Tools::getValue('deliveryMessage') ) );
            $this->updateMe( 'EXPEDIPRO_DELIVERYCOST', null, intval(Tools::getValue('deliveryCost') ) );
            $this->updateMe( 'EXPEDIPRO_STOCKMANAGEMENT', null, intval(Tools::getValue('stockManagement') ) );
        }

        return ''; // note: avoid confusion with caller $this->_output
	}


    /**
     * Check carrier|state values before updating Configuration property
     *
     * @param string $propertyName
     * @param string|null $type
     * @param null $value
     */
	private function updateMe( string $propertyName, string $type = null , $value = null ) {
	    if ( $type and $value )
            $value = $this->transformCheckbox($type, $value );

        \Configuration::updateValue( strtoupper( $propertyName), $value );
    }


	/**
	 * Transform int|array POST checkbox|radio into int|string (single or multi values)
	 *
	 * @param string	$scope	'carrier' | 'state'
	 * @param int|array $input
	 *
     * @return null|int|string with int separated by |
     **/
	private function transformCheckbox( $scope= '' , $input= null)
	{
		if ( ! $scope OR ! $input )
            return null;
//ppp( "/debug carrier:" );
//ppp( $input );
        if  ( is_array($input) )										// multi select
		{
			$list ='';
			foreach ( $input as $row )
			{
				if ($scope === 'carrier') {
					if (! $this->isValidCarrierId( $row ) ) continue;
				} else {
					if (! $this->isValidStateId( $row ) ) continue;
				}

				$list .= (int) $row . '|';
			}

			if ( $list ) {
				$list = \Tools::substr($list, 0, -1 );
			}
			//$list = implode( '|' , array_map('intval', $input ) ); // can not check ids existence
//ppp( var_dump($list) );
			return $list;
		}
		elseif ( \Validate::isUnsignedInt( $input ) )                    // singleton
        {
			if ($scope === 'carrier') {
				return ( $this->isValidCarrierId( $input ) ? (int) $input : null );
			} else {
				return ( $this->isValidStateId( $input ) ? (int) $input : null );
			}
		}
	}


    /**
	 * Get order state from Prestashop config (sendable ones) along with expedipro_orderState status
	 * Note : filter only default Prestashop, not the user specifics ones
     *
     * @param string|null	$currentList of state from db like "<val>|<val>"
	 * @param string|null	$filter name
	 *
	 * @return array:
	 */
	public function getStateList( string $currentList = null, string $filter= null ) : array
	{
		/**
		 * 9, 12	outofstock
		 * 1,10,11	attente chèque,virement,paypal
		 * 8  erreur paiement
         * 13 cashondelivery
		 * 2 payé
		 * 3 prépa
		 * 4 Expédié
		 * 5 Livré
		 * 6, 7	annulé , remboursé
		 */

        $currentArray = ( $currentList ? explode( '|', $currentList ) : [] );
		switch ( $filter ) {
			case 'sendable':
                // 9: reappro allows sending half of the order
				$filterState = [ 1,      5, 6, 7, 8, 10, 11 ];
				break;
            case 'deliveryStart':
                $filterState = [ 1, 2,      6, 7, 8, 10, 11 ];
                break;
            case 'deliveryDone':
                $filterState = [ 1, 2, 3,   6, 7, 8, 10, 11 ];
                break;
/*
            case 'deliveryFail':
                $filterState = array( 1, 2, 3,  5, 6, 7, 8, 10, 11 );
                $currentlySelected = explode( '|', Configuration::get('EXPEDIPRO_DELIVERYFAIL') );
                break;
*/
            default:
                $filterState = [];
		}

//        if ( ! $filteredState = $this->filterStateList( $filterState ) )
//            return [];



		$result = [];
		foreach( $this->filterStateList( $filterState ) AS $id => $name)
        {
			$result[ $id ] = [
                'name'		=> $name,
				'selected'	=> ( in_array( $id, $currentArray ) ? 1 : 0 )
			];
		}

		// Allow not synchronizing some steps (make no sense for exporting pending order to Expedipro)
		if ( $filter !== 'sendable' )
		    $result[0] = [
		        'name' => 'AUCUNE synchro !',
                'selected' => ! array_reduce( $result, function ( $final, $item ) { return $final ?: $item['selected']; }, false ) // only if none already selected
		    ];

		//var_dump($result);
		return $result;
	}


    /**
     * Extract all order states defined in Prestashop
     *  Usage : provide a simple array of keys to remove from the reference list of states
     *
     * @param array		$filter (negative)
     *
     * @return array [ (int) id => (string) name ]
     */
    public function filterStateList( array $filter = null ) :array
    {
        if ( ! $this->stateList )
        {
            $order = new \OrderStateCore();
            if (! $this->stateList = $order->getOrderStates( $this->context->employee->id_lang ) )
                return [];
        }

        $result = [];
        foreach ($this->stateList AS $state)
        {
            if ( $filter AND in_array( $state['id_order_state'], $filter) )
                continue;

            $result[ $state['id_order_state'] ] = $state['name'];
        }

        return $result;
    }


	/**
	 *
	 * @param int		$stateId
	 *
	 * @return boolean:
	 */
	public function isValidStateId( $stateId = null)
	{
        if ( ! $filteredState = $this->filterStateList( ) )
            return false;

        return isset( $filteredState[ (int) $stateId ] );	// for input check
	}


    /**
     * Extract module version table to detect conflict with modules like dpd, mondialrelay, etc
     *
     * @return array|null
     */
    public function getModulesVersionInstalled( )
    {
        try {
            if ( $mod = Db::getInstance()->ExecuteS('SELECT `name`,`active`,`version` FROM ' . _DB_PREFIX_ . 'module ORDER BY `name`') )
                return $mod;
        }catch( Exception $e ) {
            return null;
        }
    }


    /**
     * @param array|null $filter
     * @return array
     */
    public function filterCarrierList(array $filter = null ) :array
    {
        $this->carrierDbName = 'id_reference'; // keep aligned with getOrderRequest16()
        //  only active carriers (2020-07), defined as [] by default
        $this->carrierList = $this->carrierList ?: \Carrier::getCarriers($this->context->employee->id_lang, false, false, false, NULL, ALL_CARRIERS ); // from defines.inc.php

//        var_dump( \Carrier::getCarriers(1, false, false, false, NULL, ALL_CARRIERS ) );
        // TODO  in some case Carrier::getCarriers may fail because it select column from left join, without appropriate group by
        $sql = 'SELECT c.`id_carrier`, c.`id_reference`, c.`name`, c.`position`
		FROM `'._DB_PREFIX_.'carrier` c
		WHERE c.`deleted` = 0
		GROUP BY c.`id_carrier`
        ORDER BY c.`position` ASC';

        /**
         * Any change in carrier deprecated it and duplicate as new one
         * id_reference give a way to chain id_carrier changes
         */
        $result = [];
        foreach ($this->carrierList as $carrier)
        {
            if ( $filter AND in_array($carrier[ $this->carrierDbName ], $filter))
                continue;

            $result[ $carrier[ $this->carrierDbName ] ] = $carrier['name'];
        }

        return $result;
    }


    /**
	 * Get order state from Prestashop config (sendable ones) along with expedipro_orderState status
	 *
     * @param string $currentList
     *
     * @return array
     */
	public function getCarrierList( string $currentList = null ) :array
	{
		$currentArray = explode( '|', $currentList ); // null tolerant
        $result = [];
        foreach ( $this->filterCarrierList() AS $id => $name )
        {
            $result[ $id ] = [
                'name'		=> $name,
                'selected'	=> in_array( $id, $currentArray )
            ];
        }
        return $result;
	}


	/**
	 *
	 * @param int		$carrierId
	 *
	 * @return bool
	 */
	public function isValidCarrierId( $carrierId = null) :bool
	{

        if ( ! $filteredCarrier = $this->filterCarrierList( ) )
            return false;

        return isset( $filteredCarrier[ (int) $carrierId ] );
	}


    /**
     * Generate a random string
     * PHP 7+ random_int() is a PHP core function
     *
     * @param int $length (default is 32 like ebay)
     *
     * @return string
     */
    public function randomString(int $length = 32) :string
    {
        $charSetKey = str_shuffle("0123456789-abcdefghijklmnopqrstuvwxyz_ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        $charSetSize = mb_strlen($charSetKey, 'UTF-8') - 1;

        $result = [];
        for ($i = 0; $i < $length; ++$i) {
            /* safe only when $charSetKey contains single Byte chars */
            $result [] = $charSetKey[random_int(0, $charSetSize)];
        }
        return implode('', $result);
    }


    public function diagnoseUrl( $actionUrl )
    {
//        return 'non testé';
        $url = $actionUrl.'?tellMe='.  hash('sha256', \Configuration::get('EXPEDIPRO_TOKEN') );
//        var_dump( $url );
        // approx 5 when telleMe fail, and 70K when tellMe is ok
        if ( strlen( file_get_contents( $url) ) < 100 )
            return 'A vérifier : '.$actionUrl. ' semble inaccessible';

        return 'OK';
    }

/*
    public function diagnoseCurl( ){
        if ( version_compare(PHP_VERSION, '5.3','<') )
            return 'PHP too old for testing';
        try {
            if ( $assoc = curl_version() AND isset( $assoc['version'] ) )
                return 'OK';
        } catch (Exception $e) {
            return 'RESTRICTION : autoriser la librairie curl dans Apache/PHP';
        }
    }
*/

    public function diagnoseOrder(int $pastDay = 7) : string
    {
        $mapper = new Action\Mapper( $this->context );
        if ( ! $orderlist = $mapper->getOrder( \Configuration::get('EXPEDIPRO_ORDERSTATE'),
                                               \Configuration::get('EXPEDIPRO_CARRIER'),
                                                ( new \DateTime() )->modify("-$pastDay day")->format('Y-m-d') ) )
            return "aucune commande trouvée pour ces critères (période $pastDay jours)";
        return count( $orderlist ) . " commandes trouvées pour ces critères (période $pastDay jours)";
    }

    public function diagnoseHook( ) :array
    {
        $mapper = new Action\Mapper( $this->context );
        return [
            'getOrderRequest'=> $mapper->isHookFunctionExist( 'getOrderRequest' ),
            'getCartRequest' => $mapper->isHookFunctionExist( 'getCartRequest' ),
            'transformOrder' => $mapper->isHookFunctionExist( 'transformOrder' ),
            ];
    }

}
?>