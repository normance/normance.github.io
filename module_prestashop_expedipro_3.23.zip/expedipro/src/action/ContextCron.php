<?php
namespace Expedipro\Module\Action;

/**
 * 2025 Expedipro
 *
 * @author Expedipro SAS <contact@expedipro.com>
 * @copyright  2014 Expedipro SAS
 *  International Registered Trademark & Property of Expedipro SAS
 */
trait ContextCron
{
    /**
     * Initialise un Context complet (Langue, Employé, Traducteur), singleton, utilisable en CRON.
     *
     * @return \Context
     */
    public function setContextCron()
    {
        // keyword used to bind a variable from a global scope into a local scope
        global $kernel;

        $context = \Context::getContext();
        try {
            // 1. Définition de la Boutique (Shop) - Crucial avant Employee
            if ( ! $context->shop OR ! $context->shop->id ) {
                $idShop = (int) (\Configuration::get('PS_SHOP_DEFAULT') ?: 1);
                $context->shop = new \Shop( $idShop );
                \Shop::setContext(\Shop::CONTEXT_SHOP, $idShop); // Certaines requêtes SQL dans le cœur de PrestaShop utilisent Shop::getContextShopID() plutôt que l'objet dans le $context.
            }

            // 2. Définition de la Langue
            if ( ! $context->language OR ! $context->language->id )
                $context->language = new \Language(
                    (int) ( \Configuration::get('PS_LANG_DEFAULT') ?: 1 )
                );

            // 3. Initialisation de l'Employé (Requis pour l'historique des commandes et les stocks)
            if ( ! $context->employee OR ! $context->employee->id )
                $context->employee = new \Employee(
                    (int) ( \Configuration::get('EXPEDIPRO_EMPLOYEE') ?: \Configuration::get('PS_ONSALE_RECOVERY_EMPLOYEE') ?: 1 )
                );


            // 4. Symphony container doit être booté en cron
            // src/Adapter/ContainerFinder.php:77 Kernel Container is not available
            if( ! $kernel) {
                if ( file_exists(_PS_ROOT_DIR_.'/app/AppKernel.php' ) ) {
                    require_once _PS_ROOT_DIR_.'/app/AppKernel.php';    // not catchable, unlike @include_once()
                    // required when Prestashop 1.7+,
                    $kernel = new \AppKernel('prod', false); // ('prod',false) require that cron launcher has write access onto /var/cache, to boot Kernel.
                    $kernel->boot();
                }
            }

            // 5. Initialisation du Translator (Protection contre l'erreur AdminController::trans)
            if (method_exists($context, 'getTranslator'))
            { // 1.7+ objet specific Translator.trans( Shop.Theme.Actions )
                // Si on a réussi à booter le kernel juste au-dessus, on utilise son container
                if (isset($kernel) && $kernel instanceof \Symfony\Component\HttpKernel\KernelInterface) {
                    $translator = $kernel->getContainer()->get('translator');
                    // Fallback pour les versions < 1.7.7 ou si le kernel était déjà présent
                } elseif (class_exists('\PrestaShop\PrestaShop\Adapter\SymfonyContainer')) {
                    // On vérifie si getInstance() existe (plus commun sur les versions récentes que getContainer)
                    if (method_exists('\PrestaShop\PrestaShop\Adapter\SymfonyContainer', 'getInstance'))
                        $translator = \PrestaShop\PrestaShop\Adapter\SymfonyContainer::getInstance()->getContainer()->get('translator');
                }
                if ( isset( $translator ) )
                    $context = $this->setTranslator($context, $translator );
            } // else // < 1.7, methode globale l()

        } catch (\Exception $e) {
            // Fallback pour les environnements où Symfony n'est pas totalement chargé
        }

        return $context;
    }

    private function setTranslator( \Context $context, $translator )
    {
        if (method_exists($context, 'setTranslator') ) // from 1.7.7+
            $context->setTranslator( $translator );
        else {
            // < 1.7.7 On contourne l'absence de setTranslator() via la Réflexion
            $reflection = new \ReflectionProperty(get_class($context), 'translator');
            $reflection->setAccessible(true);
            $reflection->setValue($context, $translator);

            // nice to have define locale pour que les traductions correspondent à la langue choisie à l'étape 2
            if ($context->language && method_exists($context->language, 'getLocale')) {
                $contextTranslator = $context->getTranslator();
                if ($contextTranslator && method_exists($contextTranslator, 'setLocale')) {
                    $contextTranslator->setLocale($context->language->getLocale());
                }
            }
        }
        return $context;
    }
}